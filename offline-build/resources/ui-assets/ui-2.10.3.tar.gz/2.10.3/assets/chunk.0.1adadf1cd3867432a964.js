(window.webpackJsonp_ember_auto_import_=window.webpackJsonp_ember_auto_import_||[]).push([[0],Array(199).concat([function(t,e,n){n(210).__DEV__
var i=n(257),r=n(207),a=n(229),o=n(211),s=n(241),l=n(227),u=n(270),h=n(283),c=n(250),f=n(339),d=n(340),p=n(342),g=n(220),v=n(284),m=n(285),_=n(286),y=n(209),x=n(208),w=n(253).throttle,b=n(344),S=n(345),T=n(347),M=n(348),C=n(349),k=n(350)
n(351)
var D=n(352),I=r.assert,A=r.each,O=r.isFunction,P=r.isObject,L=g.parseClassType,E="__flagInMainProcess",R=/^[a-zA-Z0-9_]+$/
function B(t,e){return function(n,i,r){e||!this._disposed?(n=n&&n.toLowerCase(),l.prototype[t].call(this,n,i,r)):this.id}}function N(){l.call(this)}function F(t,e,n){n=n||{},"string"==typeof e&&(e=lt[e]),this.id,this.group,this._dom=t
var a=this._zr=i.init(t,{renderer:n.renderer||"canvas",devicePixelRatio:n.devicePixelRatio,width:n.width,height:n.height})
this._throttledZrFlush=w(r.bind(a.flush,a),17),(e=r.clone(e))&&d(e,!0),this._theme=e,this._chartsViews=[],this._chartsMap={},this._componentsViews=[],this._componentsMap={},this._coordSysMgr=new c
var o,u,f=this._api=(u=(o=this)._coordSysMgr,r.extend(new h(o),{getCoordinateSystems:r.bind(u.getCoordinateSystems,u),getComponentByElement:function(t){for(;t;){var e=t.__ecComponentInfo
if(null!=e)return o._model.getComponent(e.mainType,e.index)
t=t.parent}}}))
function p(t,e){return t.__prio-e.__prio}s(st,p),s(rt,p),this._scheduler=new M(this,f,rt,st),l.call(this,this._ecEventProcessor=new et),this._messageCenter=new N,this._initEvents(),this.resize=r.bind(this.resize,this),this._pendingActions=[],a.animation.on("frame",this._onframe,this),function(t,e){t.on("rendered",(function(){e.trigger("rendered"),!t.animation.isFinished()||e.__optionUpdated||e._scheduler.unfinished||e._pendingActions.length||e.trigger("finished")}))}(a,this),r.setAsPrimitive(this)}N.prototype.on=B("on",!0),N.prototype.off=B("off",!0),N.prototype.one=B("one",!0),r.mixin(N,l)
var z=F.prototype
function H(t,e,n){if(this._disposed)this.id
else{var i,r=this._model,a=this._coordSysMgr.getCoordinateSystems()
e=x.parseFinder(r,e)
for(var o=0;o<a.length;o++){var s=a[o]
if(s[t]&&null!=(i=s[t](r,e,n)))return i}}}z._onframe=function(){if(!this._disposed){var t=this._scheduler
if(this.__optionUpdated){var e=this.__optionUpdated.silent
this[E]=!0,V(this),W.update.call(this),this[E]=!1,this.__optionUpdated=!1,X.call(this,e),G.call(this,e)}else if(t.unfinished){var n=1,i=this._model,r=this._api
t.unfinished=!1
do{var a=+new Date
t.performSeriesTasks(i),t.performDataProcessorTasks(i),Y(this,i),t.performVisualTasks(i),K(this,this._model,r,"remain"),n-=+new Date-a}while(n>0&&t.unfinished)
t.unfinished||this._zr.flush()}}},z.getDom=function(){return this._dom},z.getZr=function(){return this._zr},z.setOption=function(t,e,n){if(this._disposed)this.id
else{var i
if(P(e)&&(n=e.lazyUpdate,i=e.silent,e=e.notMerge),this[E]=!0,!this._model||e){var r=new f(this._api),a=this._theme,o=this._model=new u
o.scheduler=this._scheduler,o.init(null,null,a,r)}this._model.setOption(t,at),n?(this.__optionUpdated={silent:i},this[E]=!1):(V(this),W.update.call(this),this._zr.flush(),this.__optionUpdated=!1,this[E]=!1,X.call(this,i),G.call(this,i))}},z.setTheme=function(){console.error("ECharts#setTheme() is DEPRECATED in ECharts 3.0")},z.getModel=function(){return this._model},z.getOption=function(){return this._model&&this._model.getOption()},z.getWidth=function(){return this._zr.getWidth()},z.getHeight=function(){return this._zr.getHeight()},z.getDevicePixelRatio=function(){return this._zr.painter.dpr||window.devicePixelRatio||1},z.getRenderedCanvas=function(t){if(o.canvasSupported)return(t=t||{}).pixelRatio=t.pixelRatio||1,t.backgroundColor=t.backgroundColor||this._model.get("backgroundColor"),this._zr.painter.getRenderedCanvas(t)},z.getSvgDataURL=function(){if(o.svgSupported){var t=this._zr,e=t.storage.getDisplayList()
return r.each(e,(function(t){t.stopAnimation(!0)})),t.painter.toDataURL()}},z.getDataURL=function(t){if(!this._disposed){var e=(t=t||{}).excludeComponents,n=this._model,i=[],r=this
A(e,(function(t){n.eachComponent({mainType:t},(function(t){var e=r._componentsMap[t.__viewId]
e.group.ignore||(i.push(e),e.group.ignore=!0)}))}))
var a="svg"===this._zr.painter.getType()?this.getSvgDataURL():this.getRenderedCanvas(t).toDataURL("image/"+(t&&t.type||"png"))
return A(i,(function(t){t.group.ignore=!1})),a}this.id},z.getConnectedDataURL=function(t){if(this._disposed)this.id
else if(o.canvasSupported){var e="svg"===t.type,n=this.group,a=Math.min,s=Math.max
if(ct[n]){var l=1/0,u=1/0,h=-1/0,c=-1/0,f=[],d=t&&t.pixelRatio||1
r.each(ht,(function(i,o){if(i.group===n){var d=e?i.getZr().painter.getSvgDom().innerHTML:i.getRenderedCanvas(r.clone(t)),p=i.getDom().getBoundingClientRect()
l=a(p.left,l),u=a(p.top,u),h=s(p.right,h),c=s(p.bottom,c),f.push({dom:d,left:p.left,top:p.top})}}))
var p=(h*=d)-(l*=d),g=(c*=d)-(u*=d),v=r.createCanvas(),m=i.init(v,{renderer:e?"svg":"canvas"})
if(m.resize({width:p,height:g}),e){var _=""
return A(f,(function(t){var e=t.left-l,n=t.top-u
_+='<g transform="translate('+e+","+n+')">'+t.dom+"</g>"})),m.painter.getSvgRoot().innerHTML=_,t.connectedBackgroundColor&&m.painter.setBackgroundColor(t.connectedBackgroundColor),m.refreshImmediately(),m.painter.toDataURL()}return t.connectedBackgroundColor&&m.add(new y.Rect({shape:{x:0,y:0,width:p,height:g},style:{fill:t.connectedBackgroundColor}})),A(f,(function(t){var e=new y.Image({style:{x:t.left*d-l,y:t.top*d-u,image:t.dom}})
m.add(e)})),m.refreshImmediately(),v.toDataURL("image/"+(t&&t.type||"png"))}return this.getDataURL(t)}},z.convertToPixel=r.curry(H,"convertToPixel"),z.convertFromPixel=r.curry(H,"convertFromPixel"),z.containPixel=function(t,e){if(!this._disposed){var n,i=this._model
return t=x.parseFinder(i,t),r.each(t,(function(t,i){i.indexOf("Models")>=0&&r.each(t,(function(t){var r=t.coordinateSystem
if(r&&r.containPoint)n|=!!r.containPoint(e)
else if("seriesModels"===i){var a=this._chartsMap[t.__viewId]
a&&a.containPoint&&(n|=a.containPoint(e,t))}}),this)}),this),!!n}this.id},z.getVisual=function(t,e){var n=this._model,i=(t=x.parseFinder(n,t,{defaultMainType:"series"})).seriesModel.getData(),r=t.hasOwnProperty("dataIndexInside")?t.dataIndexInside:t.hasOwnProperty("dataIndex")?i.indexOfRawIndex(t.dataIndex):null
return null!=r?i.getItemVisual(r,e):i.getVisual(e)},z.getViewOfComponentModel=function(t){return this._componentsMap[t.__viewId]},z.getViewOfSeriesModel=function(t){return this._chartsMap[t.__viewId]}
var W={prepareAndUpdate:function(t){V(this),W.update.call(this,t)},update:function(t){var e=this._model,n=this._api,i=this._zr,r=this._coordSysMgr,s=this._scheduler
if(e){s.restoreData(e,t),s.performSeriesTasks(e),r.create(e,n),s.performDataProcessorTasks(e,t),Y(this,e),r.update(e,n),Z(e),s.performVisualTasks(e,t),$(this,e,n,t)
var l=e.get("backgroundColor")||"transparent"
if(o.canvasSupported)i.setBackgroundColor(l)
else{var u=a.parse(l)
l=a.stringify(u,"rgb"),0===u[3]&&(l="transparent")}Q(e,n)}},updateTransform:function(t){var e=this._model,n=this,i=this._api
if(e){var a=[]
e.eachComponent((function(r,o){var s=n.getViewOfComponentModel(o)
if(s&&s.__alive)if(s.updateTransform){var l=s.updateTransform(o,e,i,t)
l&&l.update&&a.push(s)}else a.push(s)}))
var o=r.createHashMap()
e.eachSeries((function(r){var a=n._chartsMap[r.__viewId]
if(a.updateTransform){var s=a.updateTransform(r,e,i,t)
s&&s.update&&o.set(r.uid,1)}else o.set(r.uid,1)})),Z(e),this._scheduler.performVisualTasks(e,t,{setDirty:!0,dirtyMap:o}),K(n,e,i,t,o),Q(e,this._api)}},updateView:function(t){var e=this._model
e&&(_.markUpdateMethod(t,"updateView"),Z(e),this._scheduler.performVisualTasks(e,t,{setDirty:!0}),$(this,this._model,this._api,t),Q(e,this._api))},updateVisual:function(t){W.update.call(this,t)},updateLayout:function(t){W.update.call(this,t)}}
function V(t){var e=t._model,n=t._scheduler
n.restorePipelines(e),n.prepareStageTasks(),j(t,"component",e,n),j(t,"chart",e,n),n.plan()}function U(t,e,n,i,a){var o=t._model
if(i){var s={}
s[i+"Id"]=n[i+"Id"],s[i+"Index"]=n[i+"Index"],s[i+"Name"]=n[i+"Name"]
var l={mainType:i,query:s}
a&&(l.subType=a)
var u=n.excludeSeriesId
null!=u&&(u=r.createHashMap(x.normalizeToArray(u))),o&&o.eachComponent(l,(function(e){u&&null!=u.get(e.id)||h(t["series"===i?"_chartsMap":"_componentsMap"][e.__viewId])}),t)}else A(t._componentsViews.concat(t._chartsViews),h)
function h(i){i&&i.__alive&&i[e]&&i[e](i.__model,o,t._api,n)}}function Y(t,e){var n=t._chartsMap,i=t._scheduler
e.eachSeries((function(t){i.updateStreamModes(t,n[t.__viewId])}))}function q(t,e){var n=t.type,i=t.escapeConnect,a=nt[n],o=a.actionInfo,s=(o.update||"update").split(":"),l=s.pop()
s=null!=s[0]&&L(s[0]),this[E]=!0
var u=[t],h=!1
t.batch&&(h=!0,u=r.map(t.batch,(function(e){return(e=r.defaults(r.extend({},e),t)).batch=null,e})))
var c,f=[],d="highlight"===n||"downplay"===n
A(u,(function(t){(c=(c=a.action(t,this._model,this._api))||r.extend({},t)).type=o.event||c.type,f.push(c),d?U(this,l,t,"series"):s&&U(this,l,t,s.main,s.sub)}),this),"none"===l||d||s||(this.__optionUpdated?(V(this),W.update.call(this,t),this.__optionUpdated=!1):W[l].call(this,t)),c=h?{type:o.event||n,escapeConnect:i,batch:f}:f[0],this[E]=!1,!e&&this._messageCenter.trigger(c.type,c)}function X(t){for(var e=this._pendingActions;e.length;){var n=e.shift()
q.call(this,n,t)}}function G(t){!t&&this.trigger("updated")}function j(t,e,n,i){for(var r="component"===e,a=r?t._componentsViews:t._chartsViews,o=r?t._componentsMap:t._chartsMap,s=t._zr,l=t._api,u=0;u<a.length;u++)a[u].__alive=!1
function h(t){var e="_ec_"+t.id+"_"+t.type,u=o[e]
if(!u){var h=L(t.type);(u=new(r?m.getClass(h.main,h.sub):_.getClass(h.sub))).init(n,l),o[e]=u,a.push(u),s.add(u.group)}t.__viewId=u.__id=e,u.__alive=!0,u.__model=t,u.group.__ecComponentInfo={mainType:t.mainType,index:t.componentIndex},!r&&i.prepareView(u,t,n,l)}for(r?n.eachComponent((function(t,e){"series"!==t&&h(e)})):n.eachSeries(h),u=0;u<a.length;){var c=a[u]
c.__alive?u++:(!r&&c.renderTask.dispose(),s.remove(c.group),c.dispose(n,l),a.splice(u,1),delete o[c.__id],c.__id=c.group.__ecComponentInfo=null)}}function Z(t){t.clearColorPalette(),t.eachSeries((function(t){t.clearColorPalette()}))}function $(t,e,n,i){!function(t,e,n,i,r){A(t._componentsViews,(function(t){var r=t.__model
t.render(r,e,n,i),tt(r,t)}))}(t,e,n,i),A(t._chartsViews,(function(t){t.__alive=!1})),K(t,e,n,i),A(t._chartsViews,(function(t){t.__alive||t.remove(e,n)}))}function K(t,e,n,i,r){var a,s=t._scheduler
e.eachSeries((function(e){var n=t._chartsMap[e.__viewId]
n.__alive=!0
var o=n.renderTask
s.updatePayload(o,i),r&&r.get(e.uid)&&o.dirty(),a|=o.perform(s.getPerformArgs(o)),n.group.silent=!!e.get("silent"),tt(e,n),function(t,e){var n=t.get("blendMode")||null
e.group.traverse((function(t){t.isGroup||t.style.blend!==n&&t.setStyle("blend",n),t.eachPendingDisplayable&&t.eachPendingDisplayable((function(t){t.setStyle("blend",n)}))}))}(e,n)})),s.unfinished|=a,function(t,e){var n=t._zr.storage,i=0
n.traverse((function(t){i++})),i>e.get("hoverLayerThreshold")&&!o.node&&e.eachSeries((function(e){if(!e.preventUsingHoverLayer){var n=t._chartsMap[e.__viewId]
n.__alive&&n.group.traverse((function(t){t.useHoverLayer=!0}))}}))}(t,e),S(t._zr.dom,e)}function Q(t,e){A(ot,(function(n){n(t,e)}))}z.resize=function(t){if(this._disposed)this.id
else{this._zr.resize(t)
var e=this._model
if(this._loadingFX&&this._loadingFX.resize(),e){var n=e.resetOption("media"),i=t&&t.silent
this[E]=!0,n&&V(this),W.update.call(this),this[E]=!1,X.call(this,i),G.call(this,i)}}},z.showLoading=function(t,e){if(this._disposed)this.id
else if(P(t)&&(e=t,t=""),t=t||"default",this.hideLoading(),ut[t]){var n=ut[t](this._api,e),i=this._zr
this._loadingFX=n,i.add(n)}},z.hideLoading=function(){this._disposed?this.id:(this._loadingFX&&this._zr.remove(this._loadingFX),this._loadingFX=null)},z.makeActionFromEvent=function(t){var e=r.extend({},t)
return e.type=it[t.type],e},z.dispatchAction=function(t,e){this._disposed?this.id:(P(e)||(e={silent:!!e}),nt[t.type]&&this._model&&(this[E]?this._pendingActions.push(t):(q.call(this,t,e.silent),e.flush?this._zr.flush(!0):!1!==e.flush&&o.browser.weChat&&this._throttledZrFlush(),X.call(this,e.silent),G.call(this,e.silent))))},z.appendData=function(t){if(this._disposed)this.id
else{var e=t.seriesIndex
this.getModel().getSeriesByIndex(e).appendData(t),this._scheduler.unfinished=!0}},z.on=B("on",!1),z.off=B("off",!1),z.one=B("one",!1)
var J=["click","dblclick","mouseover","mouseout","mousemove","mousedown","mouseup","globalout","contextmenu"]
function tt(t,e){var n=t.get("z"),i=t.get("zlevel")
e.group.traverse((function(t){"group"!==t.type&&(null!=n&&(t.z=n),null!=i&&(t.zlevel=i))}))}function et(){this.eventInfo}z._initEvents=function(){A(J,(function(t){var e=function(e){var n,i=this.getModel(),a=e.target
if("globalout"===t)n={}
else if(a&&null!=a.dataIndex){var o=a.dataModel||i.getSeriesByIndex(a.seriesIndex)
n=o&&o.getDataParams(a.dataIndex,a.dataType,a)||{}}else a&&a.eventData&&(n=r.extend({},a.eventData))
if(n){var s=n.componentType,l=n.componentIndex
"markLine"!==s&&"markPoint"!==s&&"markArea"!==s||(s="series",l=n.seriesIndex)
var u=s&&null!=l&&i.getComponent(s,l),h=u&&this["series"===u.mainType?"_chartsMap":"_componentsMap"][u.__viewId]
n.event=e,n.type=t,this._ecEventProcessor.eventInfo={targetEl:a,packedEvent:n,model:u,view:h},this.trigger(t,n)}}
e.zrEventfulCallAtLast=!0,this._zr.on(t,e,this)}),this),A(it,(function(t,e){this._messageCenter.on(e,(function(t){this.trigger(e,t)}),this)}),this)},z.isDisposed=function(){return this._disposed},z.clear=function(){this._disposed?this.id:this.setOption({series:[]},!0)},z.dispose=function(){if(this._disposed)this.id
else{this._disposed=!0,x.setAttribute(this.getDom(),pt,"")
var t=this._api,e=this._model
A(this._componentsViews,(function(n){n.dispose(e,t)})),A(this._chartsViews,(function(n){n.dispose(e,t)})),this._zr.dispose(),delete ht[this.id]}},r.mixin(F,l),et.prototype={constructor:et,normalizeQuery:function(t){var e={},n={},i={}
if(r.isString(t)){var a=L(t)
e.mainType=a.main||null,e.subType=a.sub||null}else{var o=["Index","Name","Id"],s={name:1,dataIndex:1,dataType:1}
r.each(t,(function(t,r){for(var a=!1,l=0;l<o.length;l++){var u=o[l],h=r.lastIndexOf(u)
if(h>0&&h===r.length-u.length){var c=r.slice(0,h)
"data"!==c&&(e.mainType=c,e[u.toLowerCase()]=t,a=!0)}}s.hasOwnProperty(r)&&(n[r]=t,a=!0),a||(i[r]=t)}))}return{cptQuery:e,dataQuery:n,otherQuery:i}},filter:function(t,e,n){var i=this.eventInfo
if(!i)return!0
var r=i.targetEl,a=i.packedEvent,o=i.model,s=i.view
if(!o||!s)return!0
var l=e.cptQuery,u=e.dataQuery
return h(l,o,"mainType")&&h(l,o,"subType")&&h(l,o,"index","componentIndex")&&h(l,o,"name")&&h(l,o,"id")&&h(u,a,"name")&&h(u,a,"dataIndex")&&h(u,a,"dataType")&&(!s.filterForExposedEvent||s.filterForExposedEvent(t,e.otherQuery,r,a))
function h(t,e,n,i){return null==t[n]||e[i||n]===t[n]}},afterTrigger:function(){this.eventInfo=null}}
var nt={},it={},rt=[],at=[],ot=[],st=[],lt={},ut={},ht={},ct={},ft=new Date-0,dt=new Date-0,pt="_echarts_instance_"
function gt(t){ct[t]=!1}var vt=gt
function mt(t){return ht[x.getAttribute(t,pt)]}function _t(t,e){lt[t]=e}function yt(t){at.push(t)}function xt(t,e){St(rt,t,e,1e3)}function wt(t,e,n){"function"==typeof e&&(n=e,e="")
var i=P(t)?t.type:[t,t={event:e}][0]
t.event=(t.event||i).toLowerCase(),e=t.event,I(R.test(i)&&R.test(e)),nt[i]||(nt[i]={action:n,actionInfo:t}),it[e]=i}function bt(t,e){St(st,t,e,3e3,"visual")}function St(t,e,n,i,r){(O(e)||P(e))&&(n=e,e=i)
var a=M.wrapStageHandler(n,r)
return a.__prio=e,a.__raw=n,t.push(a),a}function Tt(t,e){ut[t]=e}bt(2e3,b),yt(d),xt(900,p),Tt("default",T),wt({type:"highlight",event:"highlight",update:"highlight"},r.noop),wt({type:"downplay",event:"downplay",update:"downplay"},r.noop),_t("light",C),_t("dark",k),e.version="4.9.0",e.dependencies={zrender:"4.3.2"},e.PRIORITY={PROCESSOR:{FILTER:1e3,SERIES_FILTER:800,STATISTIC:5e3},VISUAL:{LAYOUT:1e3,PROGRESSIVE_LAYOUT:1100,GLOBAL:2e3,CHART:3e3,POST_CHART_LAYOUT:3500,COMPONENT:4e3,BRUSH:5e3}},e.init=function(t,e,n){var i=mt(t)
if(i)return i
var r=new F(t,e,n)
return r.id="ec_"+ft++,ht[r.id]=r,x.setAttribute(t,pt,r.id),function(t){var e="__connectUpdateStatus"
function n(t,n){for(var i=0;i<t.length;i++)t[i][e]=n}A(it,(function(i,r){t._messageCenter.on(r,(function(i){if(ct[t.group]&&0!==t[e]){if(i&&i.escapeConnect)return
var r=t.makeActionFromEvent(i),a=[]
A(ht,(function(e){e!==t&&e.group===t.group&&a.push(e)})),n(a,0),A(a,(function(t){1!==t[e]&&t.dispatchAction(r)})),n(a,2)}}))}))}(r),r},e.connect=function(t){if(r.isArray(t)){var e=t
t=null,A(e,(function(e){null!=e.group&&(t=e.group)})),t=t||"g_"+dt++,A(e,(function(e){e.group=t}))}return ct[t]=!0,t},e.disConnect=gt,e.disconnect=vt,e.dispose=function(t){"string"==typeof t?t=ht[t]:t instanceof F||(t=mt(t)),t instanceof F&&!t.isDisposed()&&t.dispose()},e.getInstanceByDom=mt,e.getInstanceById=function(t){return ht[t]},e.registerTheme=_t,e.registerPreprocessor=yt,e.registerProcessor=xt,e.registerPostUpdate=function(t){ot.push(t)},e.registerAction=wt,e.registerCoordinateSystem=function(t,e){c.register(t,e)},e.getCoordinateSystemDimensions=function(t){var e=c.get(t)
if(e)return e.getDimensionsInfo?e.getDimensionsInfo():e.dimensions.slice()},e.registerLayout=function(t,e){St(st,t,e,1e3,"layout")},e.registerVisual=bt,e.registerLoading=Tt,e.extendComponentModel=function(t){return g.extend(t)},e.extendComponentView=function(t){return m.extend(t)},e.extendSeriesModel=function(t){return v.extend(t)},e.extendChartView=function(t){return _.extend(t)},e.setCanvasCreator=function(t){r.$override("createCanvas",t)},e.registerMap=function(t,e,n){D.registerMap(t,e,n)},e.getMap=function(t){var e=D.retrieveMap(t)
return e&&e[0]&&{geoJson:e[0].geoJSON,specialAreas:e[0].specialAreas}},e.dataTool={}
var Mt=n(355)
!function(){for(var t in Mt)Mt.hasOwnProperty(t)&&(e[t]=Mt[t])}()},,,,,,,,function(t,e){var n={"[object Function]":1,"[object RegExp]":1,"[object Date]":1,"[object Error]":1,"[object CanvasGradient]":1,"[object CanvasPattern]":1,"[object Image]":1,"[object Canvas]":1},i={"[object Int8Array]":1,"[object Uint8Array]":1,"[object Uint8ClampedArray]":1,"[object Int16Array]":1,"[object Uint16Array]":1,"[object Int32Array]":1,"[object Uint32Array]":1,"[object Float32Array]":1,"[object Float64Array]":1},r=Object.prototype.toString,a=Array.prototype,o=a.forEach,s=a.filter,l=a.slice,u=a.map,h=a.reduce,c={}
function f(t){if(null==t||"object"!=typeof t)return t
var e=t,a=r.call(t)
if("[object Array]"===a){if(!S(t)){e=[]
for(var o=0,s=t.length;o<s;o++)e[o]=f(t[o])}}else if(i[a]){if(!S(t)){var l=t.constructor
if(t.constructor.from)e=l.from(t)
else for(e=new l(t.length),o=0,s=t.length;o<s;o++)e[o]=f(t[o])}}else if(!n[a]&&!S(t)&&!b(t))for(var u in e={},t)t.hasOwnProperty(u)&&(e[u]=f(t[u]))
return e}function d(t,e,n){if(!x(e)||!x(t))return n?f(e):t
for(var i in e)if(e.hasOwnProperty(i)){var r=t[i],a=e[i]
!x(a)||!x(r)||y(a)||y(r)||b(a)||b(r)||w(a)||w(r)||S(a)||S(r)?!n&&i in t||(t[i]=f(e[i])):d(r,a,n)}return t}function p(t,e,n){for(var i in e)e.hasOwnProperty(i)&&(n?null!=e[i]:null==t[i])&&(t[i]=e[i])
return t}var g,v=function(){return c.createCanvas()}
function m(t,e,n){if(t&&e)if(t.forEach&&t.forEach===o)t.forEach(e,n)
else if(t.length===+t.length)for(var i=0,r=t.length;i<r;i++)e.call(n,t[i],i,t)
else for(var a in t)t.hasOwnProperty(a)&&e.call(n,t[a],a,t)}function _(t,e){var n=l.call(arguments,2)
return function(){return t.apply(e,n.concat(l.call(arguments)))}}function y(t){return"[object Array]"===r.call(t)}function x(t){var e=typeof t
return"function"===e||!!t&&"object"===e}function w(t){return!!n[r.call(t)]}function b(t){return"object"==typeof t&&"number"==typeof t.nodeType&&"object"==typeof t.ownerDocument}function S(t){return t.__ec_primitive__}function T(t){var e=y(t)
this.data={}
var n=this
function i(t,i){e?n.set(t,i):n.set(i,t)}t instanceof T?t.each(i):t&&m(t,i)}c.createCanvas=function(){return document.createElement("canvas")},T.prototype={constructor:T,get:function(t){return this.data.hasOwnProperty(t)?this.data[t]:null},set:function(t,e){return this.data[t]=e},each:function(t,e){for(var n in void 0!==e&&(t=_(t,e)),this.data)this.data.hasOwnProperty(n)&&t(this.data[n],n)},removeKey:function(t){delete this.data[t]}},e.$override=function(t,e){"createCanvas"===t&&(g=null),c[t]=e},e.clone=f,e.merge=d,e.mergeAll=function(t,e){for(var n=t[0],i=1,r=t.length;i<r;i++)n=d(n,t[i],e)
return n},e.extend=function(t,e){for(var n in e)e.hasOwnProperty(n)&&(t[n]=e[n])
return t},e.defaults=p,e.createCanvas=v,e.getContext=function(){return g||(g=v().getContext("2d")),g},e.indexOf=function(t,e){if(t){if(t.indexOf)return t.indexOf(e)
for(var n=0,i=t.length;n<i;n++)if(t[n]===e)return n}return-1},e.inherits=function(t,e){var n=t.prototype
function i(){}for(var r in i.prototype=e.prototype,t.prototype=new i,n)n.hasOwnProperty(r)&&(t.prototype[r]=n[r])
t.prototype.constructor=t,t.superClass=e},e.mixin=function(t,e,n){p(t="prototype"in t?t.prototype:t,e="prototype"in e?e.prototype:e,n)},e.isArrayLike=function(t){if(t)return"string"!=typeof t&&"number"==typeof t.length},e.each=m,e.map=function(t,e,n){if(t&&e){if(t.map&&t.map===u)return t.map(e,n)
for(var i=[],r=0,a=t.length;r<a;r++)i.push(e.call(n,t[r],r,t))
return i}},e.reduce=function(t,e,n,i){if(t&&e){if(t.reduce&&t.reduce===h)return t.reduce(e,n,i)
for(var r=0,a=t.length;r<a;r++)n=e.call(i,n,t[r],r,t)
return n}},e.filter=function(t,e,n){if(t&&e){if(t.filter&&t.filter===s)return t.filter(e,n)
for(var i=[],r=0,a=t.length;r<a;r++)e.call(n,t[r],r,t)&&i.push(t[r])
return i}},e.find=function(t,e,n){if(t&&e)for(var i=0,r=t.length;i<r;i++)if(e.call(n,t[i],i,t))return t[i]},e.bind=_,e.curry=function(t){var e=l.call(arguments,1)
return function(){return t.apply(this,e.concat(l.call(arguments)))}},e.isArray=y,e.isFunction=function(t){return"function"==typeof t},e.isString=function(t){return"[object String]"===r.call(t)},e.isObject=x,e.isBuiltInObject=w,e.isTypedArray=function(t){return!!i[r.call(t)]},e.isDom=b,e.eqNaN=function(t){return t!=t},e.retrieve=function(t){for(var e=0,n=arguments.length;e<n;e++)if(null!=arguments[e])return arguments[e]},e.retrieve2=function(t,e){return null!=t?t:e},e.retrieve3=function(t,e,n){return null!=t?t:null!=e?e:n},e.slice=function(){return Function.call.apply(l,arguments)},e.normalizeCssArray=function(t){if("number"==typeof t)return[t,t,t,t]
var e=t.length
return 2===e?[t[0],t[1],t[0],t[1]]:3===e?[t[0],t[1],t[2],t[1]]:t},e.assert=function(t,e){if(!t)throw new Error(e)},e.trim=function(t){return null==t?null:"function"==typeof t.trim?t.trim():t.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,"")},e.setAsPrimitive=function(t){t.__ec_primitive__=!0},e.isPrimitive=S,e.createHashMap=function(t){return new T(t)},e.concatArray=function(t,e){for(var n=new t.constructor(t.length+e.length),i=0;i<t.length;i++)n[i]=t[i]
var r=t.length
for(i=0;i<e.length;i++)n[i+r]=e[i]
return n},e.noop=function(){}},function(t,e,n){var i=n(207),r=n(211),a=i.each,o=i.isObject,s=i.isArray
function l(t){return t instanceof Array?t:null==t?[]:[t]}function u(t){return o(t)&&t.id&&0===(t.id+"").indexOf("\0_ec_\0")}var h=0
function c(t,e){return t&&t.hasOwnProperty(e)}e.normalizeToArray=l,e.defaultEmphasis=function(t,e,n){if(t){t[e]=t[e]||{},t.emphasis=t.emphasis||{},t.emphasis[e]=t.emphasis[e]||{}
for(var i=0,r=n.length;i<r;i++){var a=n[i]
!t.emphasis[e].hasOwnProperty(a)&&t[e].hasOwnProperty(a)&&(t.emphasis[e][a]=t[e][a])}}},e.TEXT_STYLE_OPTIONS=["fontStyle","fontWeight","fontSize","fontFamily","rich","tag","color","textBorderColor","textBorderWidth","width","height","lineHeight","align","verticalAlign","baseline","shadowColor","shadowBlur","shadowOffsetX","shadowOffsetY","textShadowColor","textShadowBlur","textShadowOffsetX","textShadowOffsetY","backgroundColor","borderColor","borderWidth","borderRadius","padding"],e.getDataItemValue=function(t){return!o(t)||s(t)||t instanceof Date?t:t.value},e.isDataItemOption=function(t){return o(t)&&!(t instanceof Array)},e.mappingToExists=function(t,e){e=(e||[]).slice()
var n=i.map(t||[],(function(t,e){return{exist:t}}))
return a(e,(function(t,i){if(o(t)){for(var r=0;r<n.length;r++)if(!n[r].option&&null!=t.id&&n[r].exist.id===t.id+"")return n[r].option=t,void(e[i]=null)
for(r=0;r<n.length;r++){var a=n[r].exist
if(!(n[r].option||null!=a.id&&null!=t.id||null==t.name||u(t)||u(a)||a.name!==t.name+""))return n[r].option=t,void(e[i]=null)}}})),a(e,(function(t,e){if(o(t)){for(var i=0;i<n.length;i++){var r=n[i].exist
if(!n[i].option&&!u(r)&&null==t.id){n[i].option=t
break}}i>=n.length&&n.push({option:t})}})),n},e.makeIdAndName=function(t){var e=i.createHashMap()
a(t,(function(t,n){var i=t.exist
i&&e.set(i.id,t)})),a(t,(function(t,n){var r=t.option
i.assert(!r||null==r.id||!e.get(r.id)||e.get(r.id)===t,"id duplicates: "+(r&&r.id)),r&&null!=r.id&&e.set(r.id,t),!t.keyInfo&&(t.keyInfo={})})),a(t,(function(t,n){var i=t.exist,r=t.option,a=t.keyInfo
if(o(r)){if(a.name=null!=r.name?r.name+"":i?i.name:"series\0"+n,i)a.id=i.id
else if(null!=r.id)a.id=r.id+""
else{var s=0
do{a.id="\0"+a.name+"\0"+s++}while(e.get(a.id))}e.set(a.id,t)}}))},e.isNameSpecified=function(t){var e=t.name
return!(!e||!e.indexOf("series\0"))},e.isIdInner=u,e.compressBatches=function(t,e){var n={},i={}
return r(t||[],n),r(e||[],i,n),[a(n),a(i)]
function r(t,e,n){for(var i=0,r=t.length;i<r;i++)for(var a=t[i].seriesId,o=l(t[i].dataIndex),s=n&&n[a],u=0,h=o.length;u<h;u++){var c=o[u]
s&&s[c]?s[c]=null:(e[a]||(e[a]={}))[c]=1}}function a(t,e){var n=[]
for(var i in t)if(t.hasOwnProperty(i)&&null!=t[i])if(e)n.push(+i)
else{var r=a(t[i],!0)
r.length&&n.push({seriesId:i,dataIndex:r})}return n}},e.queryDataIndex=function(t,e){return null!=e.dataIndexInside?e.dataIndexInside:null!=e.dataIndex?i.isArray(e.dataIndex)?i.map(e.dataIndex,(function(e){return t.indexOfRawIndex(e)})):t.indexOfRawIndex(e.dataIndex):null!=e.name?i.isArray(e.name)?i.map(e.name,(function(e){return t.indexOfName(e)})):t.indexOfName(e.name):void 0},e.makeInner=function(){var t="__\0ec_inner_"+h+++"_"+Math.random().toFixed(5)
return function(e){return e[t]||(e[t]={})}},e.parseFinder=function(t,e,n){if(i.isString(e)){var r={}
r[e+"Index"]=0,e=r}var o=n&&n.defaultMainType
!o||c(e,o+"Index")||c(e,o+"Id")||c(e,o+"Name")||(e[o+"Index"]=0)
var s={}
return a(e,(function(r,a){if(r=e[a],"dataIndex"!==a&&"dataIndexInside"!==a){var o=a.match(/^(\w+)(Index|Id|Name)$/)||[],l=o[1],u=(o[2]||"").toLowerCase()
if(!(!l||!u||null==r||"index"===u&&"none"===r||n&&n.includeMainTypes&&i.indexOf(n.includeMainTypes,l)<0)){var h={mainType:l}
"index"===u&&"all"===r||(h[u]=r)
var c=t.queryComponents(h)
s[l+"Models"]=c,s[l+"Model"]=c[0]}}else s[a]=r})),s},e.setAttribute=function(t,e,n){t.setAttribute?t.setAttribute(e,n):t[e]=n},e.getAttribute=function(t,e){return t.getAttribute?t.getAttribute(e):t[e]},e.getTooltipRenderMode=function(t){return"auto"===t?r.domSupported?"html":"richText":t||"html"},e.groupData=function(t,e){var n=i.createHashMap(),r=[]
return i.each(t,(function(t){var i=e(t);(n.get(i)||(r.push(i),n.set(i,[]))).push(t)})),{keys:r,buckets:n}}},function(t,e,n){var i=n(207),r=n(271),a=n(229),o=n(221),s=n(212),l=n(213),u=n(261),h=n(243)
e.Image=h
var c=n(228)
e.Group=c
var f=n(247)
e.Text=f
var d=n(274)
e.Circle=d
var p=n(327)
e.Sector=p
var g=n(328)
e.Ring=g
var v=n(276)
e.Polygon=v
var m=n(278)
e.Polyline=m
var _=n(279)
e.Rect=_
var y=n(280)
e.Line=y
var x=n(331)
e.BezierCurve=x
var w=n(332)
e.Arc=w
var b=n(333)
e.CompoundPath=b
var S=n(281)
e.LinearGradient=S
var T=n(334)
e.RadialGradient=T
var M=n(215)
e.BoundingRect=M
var C=n(335)
e.IncrementalDisplayable=C
var k=n(248),D=Math.max,I=Math.min,A={},O=1,P={},L={}
function E(t,e){L[t]=e}function R(t,e,n,i){var a=r.createFromString(t,e)
return n&&("center"===i&&(n=B(n,a.getBoundingRect())),F(a,n)),a}function B(t,e){var n,i=e.width/e.height,r=t.height*i
return n=r<=t.width?t.height:(r=t.width)/i,{x:t.x+t.width/2-r/2,y:t.y+t.height/2-n/2,width:r,height:n}}var N=r.mergePath
function F(t,e){if(t.applyTransform){var n=t.getBoundingRect().calculateTransform(e)
t.applyTransform(n)}}var z=k.subPixelOptimize
function H(t){return null!=t&&"none"!==t}var W=i.createHashMap(),V=0
function U(t){var e=t.__hoverStl
if(e&&!t.__highlighted){var n=t.__zr,i=t.useHoverLayer&&n&&"canvas"===n.painter.type
if(t.__highlighted=i?"layer":"plain",!(t.isGroup||!n&&t.useHoverLayer)){var r=t,a=t.style
i&&(a=(r=n.addHover(t)).style),at(a),i||function(t){if(t.__hoverStlDirty){t.__hoverStlDirty=!1
var e=t.__hoverStl
if(e){var n=t.__cachedNormalStl={}
t.__cachedNormalZ2=t.z2
var i=t.style
for(var r in e)null!=e[r]&&(n[r]=i[r])
n.fill=i.fill,n.stroke=i.stroke}else t.__cachedNormalStl=t.__cachedNormalZ2=null}}(r),a.extendFrom(e),Y(a,e,"fill"),Y(a,e,"stroke"),rt(a),i||(t.dirty(!1),t.z2+=1)}}}function Y(t,e,n){!H(e[n])&&H(t[n])&&(t[n]=function(t){if("string"!=typeof t)return t
var e=W.get(t)
return e||(e=a.lift(t,-.1),V<1e4&&(W.set(t,e),V++)),e}(t[n]))}function q(t){var e=t.__highlighted
if(e&&(t.__highlighted=!1,!t.isGroup))if("layer"===e)t.__zr&&t.__zr.removeHover(t)
else{var n=t.style,i=t.__cachedNormalStl
i&&(at(n),t.setStyle(i),rt(n))
var r=t.__cachedNormalZ2
null!=r&&t.z2-r==1&&(t.z2=r)}}function X(t,e,n){var i,r="normal",a="normal"
t.__highlighted&&(r="emphasis",i=!0),e(t,n),t.__highlighted&&(a="emphasis",i=!0),t.isGroup&&t.traverse((function(t){!t.isGroup&&e(t,n)})),i&&t.__highDownOnUpdate&&t.__highDownOnUpdate(r,a)}function G(t,e){e=t.__hoverStl=!1!==e&&(t.hoverStyle||e||{}),t.__hoverStlDirty=!0,t.__highlighted&&(t.__cachedNormalStl=null,q(t),U(t))}function j(t){!Q(this,t)&&!this.__highByOuter&&X(this,U)}function Z(t){!Q(this,t)&&!this.__highByOuter&&X(this,q)}function $(t){this.__highByOuter|=1<<(t||0),X(this,U)}function K(t){!(this.__highByOuter&=~(1<<(t||0)))&&X(this,q)}function Q(t,e){return t.__highDownSilentOnTouch&&e.zrByTouch}function J(t,e){var n=!1===e
if(t.__highDownSilentOnTouch=t.highDownSilentOnTouch,t.__highDownOnUpdate=t.highDownOnUpdate,!n||t.__highDownDispatcher){var i=n?"off":"on"
t[i]("mouseover",j)[i]("mouseout",Z),t[i]("emphasis",$)[i]("normal",K),t.__highByOuter=t.__highByOuter||0,t.__highDownDispatcher=!n}}function tt(t,e,n,r,a){return et(t,e,r,a),n&&i.extend(t,n),t}function et(t,e,n,r){if((n=n||A).isRectText){var a
n.getTextPosition?a=n.getTextPosition(e,r):"outside"===(a=e.getShallow("position")||(r?null:"inside"))&&(a="top"),t.textPosition=a,t.textOffset=e.getShallow("offset")
var o=e.getShallow("rotate")
null!=o&&(o*=Math.PI/180),t.textRotation=o,t.textDistance=i.retrieve2(e.getShallow("distance"),r?null:5)}var s,l=e.ecModel,u=l&&l.option.textStyle,h=function(t){for(var e;t&&t!==t.ecModel;){var n=(t.option||A).rich
if(n)for(var i in e=e||{},n)n.hasOwnProperty(i)&&(e[i]=1)
t=t.parentModel}return e}(e)
if(h)for(var c in s={},h)if(h.hasOwnProperty(c)){var f=e.getModel(["rich",c])
nt(s[c]={},f,u,n,r)}return t.rich=s,nt(t,e,u,n,r,!0),n.forceRich&&!n.textStyle&&(n.textStyle={}),t}function nt(t,e,n,r,a,o){n=!a&&n||A,t.textFill=it(e.getShallow("color"),r)||n.color,t.textStroke=it(e.getShallow("textBorderColor"),r)||n.textBorderColor,t.textStrokeWidth=i.retrieve2(e.getShallow("textBorderWidth"),n.textBorderWidth),a||(o&&(t.insideRollbackOpt=r,rt(t)),null==t.textFill&&(t.textFill=r.autoColor)),t.fontStyle=e.getShallow("fontStyle")||n.fontStyle,t.fontWeight=e.getShallow("fontWeight")||n.fontWeight,t.fontSize=e.getShallow("fontSize")||n.fontSize,t.fontFamily=e.getShallow("fontFamily")||n.fontFamily,t.textAlign=e.getShallow("align"),t.textVerticalAlign=e.getShallow("verticalAlign")||e.getShallow("baseline"),t.textLineHeight=e.getShallow("lineHeight"),t.textWidth=e.getShallow("width"),t.textHeight=e.getShallow("height"),t.textTag=e.getShallow("tag"),o&&r.disableBox||(t.textBackgroundColor=it(e.getShallow("backgroundColor"),r),t.textPadding=e.getShallow("padding"),t.textBorderColor=it(e.getShallow("borderColor"),r),t.textBorderWidth=e.getShallow("borderWidth"),t.textBorderRadius=e.getShallow("borderRadius"),t.textBoxShadowColor=e.getShallow("shadowColor"),t.textBoxShadowBlur=e.getShallow("shadowBlur"),t.textBoxShadowOffsetX=e.getShallow("shadowOffsetX"),t.textBoxShadowOffsetY=e.getShallow("shadowOffsetY")),t.textShadowColor=e.getShallow("textShadowColor")||n.textShadowColor,t.textShadowBlur=e.getShallow("textShadowBlur")||n.textShadowBlur,t.textShadowOffsetX=e.getShallow("textShadowOffsetX")||n.textShadowOffsetX,t.textShadowOffsetY=e.getShallow("textShadowOffsetY")||n.textShadowOffsetY}function it(t,e){return"auto"!==t?t:e&&e.autoColor?e.autoColor:null}function rt(t){var e,n=t.textPosition,i=t.insideRollbackOpt
if(i&&null==t.textFill){var r=i.autoColor,a=i.isRectText,o=i.useInsideStyle,s=!1!==o&&(!0===o||a&&n&&"string"==typeof n&&n.indexOf("inside")>=0),l=!s&&null!=r;(s||l)&&(e={textFill:t.textFill,textStroke:t.textStroke,textStrokeWidth:t.textStrokeWidth}),s&&(t.textFill="#fff",null==t.textStroke&&(t.textStroke=r,null==t.textStrokeWidth&&(t.textStrokeWidth=2))),l&&(t.textFill=r)}t.insideRollback=e}function at(t){var e=t.insideRollback
e&&(t.textFill=e.textFill,t.textStroke=e.textStroke,t.textStrokeWidth=e.textStrokeWidth,t.insideRollback=null)}function ot(t,e,n,i,r,a){if("function"==typeof r&&(a=r,r=null),i&&i.isAnimationEnabled()){var o=t?"Update":"",s=i.getShallow("animationDuration"+o),l=i.getShallow("animationEasing"+o),u=i.getShallow("animationDelay"+o)
"function"==typeof u&&(u=u(r,i.getAnimationDelayParams?i.getAnimationDelayParams(e,r):null)),"function"==typeof s&&(s=s(r)),s>0?e.animateTo(n,s,u||0,l,a,!!a):(e.stopAnimation(),e.attr(n),a&&a())}else e.stopAnimation(),e.attr(n),a&&a()}function st(t,e,n,i,r){ot(!0,t,e,n,i,r)}function lt(t,e,n){return e&&!i.isArrayLike(e)&&(e=u.getLocalTransform(e)),n&&(e=o.invert([],e)),s.applyTransform([],t,e)}function ut(t,e,n,i,r,a,o,s){var l,u=n-t,h=i-e,c=o-r,f=s-a,d=ht(c,f,u,h)
if((l=d)<=1e-6&&l>=-1e-6)return!1
var p=t-r,g=e-a,v=ht(p,g,u,h)/d
if(v<0||v>1)return!1
var m=ht(p,g,c,f)/d
return!(m<0||m>1)}function ht(t,e,n,i){return t*i-n*e}E("circle",d),E("sector",p),E("ring",g),E("polygon",v),E("polyline",m),E("rect",_),E("line",y),E("bezierCurve",x),E("arc",w),e.Z2_EMPHASIS_LIFT=1,e.CACHED_LABEL_STYLE_PROPERTIES={color:"textFill",textBorderColor:"textStroke",textBorderWidth:"textStrokeWidth"},e.extendShape=function(t){return l.extend(t)},e.extendPath=function(t,e){return r.extendFromString(t,e)},e.registerShape=E,e.getShapeClass=function(t){if(L.hasOwnProperty(t))return L[t]},e.makePath=R,e.makeImage=function(t,e,n){var i=new h({style:{image:t,x:e.x,y:e.y,width:e.width,height:e.height},onload:function(t){if("center"===n){var r={width:t.width,height:t.height}
i.setStyle(B(e,r))}}})
return i},e.mergePath=N,e.resizePath=F,e.subPixelOptimizeLine=function(t){return k.subPixelOptimizeLine(t.shape,t.shape,t.style),t},e.subPixelOptimizeRect=function(t){return k.subPixelOptimizeRect(t.shape,t.shape,t.style),t},e.subPixelOptimize=z,e.setElementHoverStyle=G,e.setHoverStyle=function(t,e){J(t,!0),X(t,G,e)},e.setAsHighDownDispatcher=J,e.isHighDownDispatcher=function(t){return!(!t||!t.__highDownDispatcher)},e.getHighlightDigit=function(t){var e=P[t]
return null==e&&O<=32&&(e=P[t]=O++),e},e.setLabelStyle=function(t,e,n,r,a,o,s){var l,u=(a=a||A).labelFetcher,h=a.labelDataIndex,c=a.labelDimIndex,f=a.labelProp,d=n.getShallow("show"),p=r.getShallow("show");(d||p)&&(u&&(l=u.getFormattedLabel(h,"normal",null,c,f)),null==l&&(l=i.isFunction(a.defaultText)?a.defaultText(h,a):a.defaultText))
var g=d?l:null,v=p?i.retrieve2(u?u.getFormattedLabel(h,"emphasis",null,c,f):null,l):null
null==g&&null==v||(tt(t,n,o,a),tt(e,r,s,a,!0)),t.text=g,e.text=v},e.modifyLabelStyle=function(t,e,n){var r=t.style
e&&(at(r),t.setStyle(e),rt(r)),r=t.__hoverStl,n&&r&&(at(r),i.extend(r,n),rt(r))},e.setTextStyle=tt,e.setText=function(t,e,n){var i,r={isRectText:!0}
!1===n?i=!0:r.autoColor=n,et(t,e,r,i)},e.getFont=function(t,e){var n=e&&e.getModel("textStyle")
return i.trim([t.fontStyle||n&&n.getShallow("fontStyle")||"",t.fontWeight||n&&n.getShallow("fontWeight")||"",(t.fontSize||n&&n.getShallow("fontSize")||12)+"px",t.fontFamily||n&&n.getShallow("fontFamily")||"sans-serif"].join(" "))},e.updateProps=st,e.initProps=function(t,e,n,i,r){ot(!1,t,e,n,i,r)},e.getTransform=function(t,e){for(var n=o.identity([]);t&&t!==e;)o.mul(n,t.getLocalTransform(),n),t=t.parent
return n},e.applyTransform=lt,e.transformDirection=function(t,e,n){var i=0===e[4]||0===e[5]||0===e[0]?1:Math.abs(2*e[4]/e[0]),r=0===e[4]||0===e[5]||0===e[2]?1:Math.abs(2*e[4]/e[2]),a=["left"===t?-i:"right"===t?i:0,"top"===t?-r:"bottom"===t?r:0]
return a=lt(a,e,n),Math.abs(a[0])>Math.abs(a[1])?a[0]>0?"right":"left":a[1]>0?"bottom":"top"},e.groupTransition=function(t,e,n,r){if(t&&e){var a,o=(a={},t.traverse((function(t){!t.isGroup&&t.anid&&(a[t.anid]=t)})),a)
e.traverse((function(t){if(!t.isGroup&&t.anid){var e=o[t.anid]
if(e){var i=l(t)
t.attr(l(e)),st(t,i,n,t.dataIndex)}}}))}function l(t){var e={position:s.clone(t.position),rotation:t.rotation}
return t.shape&&(e.shape=i.extend({},t.shape)),e}},e.clipPointsByRect=function(t,e){return i.map(t,(function(t){var n=t[0]
n=D(n,e.x),n=I(n,e.x+e.width)
var i=t[1]
return i=D(i,e.y),[n,i=I(i,e.y+e.height)]}))},e.clipRectByRect=function(t,e){var n=D(t.x,e.x),i=I(t.x+t.width,e.x+e.width),r=D(t.y,e.y),a=I(t.y+t.height,e.y+e.height)
if(i>=n&&a>=r)return{x:n,y:r,width:i-n,height:a-r}},e.createIcon=function(t,e,n){var r=(e=i.extend({rectHover:!0},e)).style={strokeNoScale:!0}
if(n=n||{x:-1,y:-1,width:2,height:2},t)return 0===t.indexOf("image://")?(r.image=t.slice(8),i.defaults(r,n),new h(e)):R(t.replace("path://",""),e,n,"center")},e.linePolygonIntersect=function(t,e,n,i,r){for(var a=0,o=r[r.length-1];a<r.length;a++){var s=r[a]
if(ut(t,e,n,i,s[0],s[1],o[0],o[1]))return!0
o=s}},e.lineLineIntersect=ut},function(t,e,n){(function(t){var n
"undefined"!=typeof window?n=window.__DEV__:void 0!==t&&(n=t.__DEV__),void 0===n&&(n=!0)
var i=n
e.__DEV__=i}).call(this,n(5))},function(t,e){var n="object"==typeof wx&&"function"==typeof wx.getSystemInfoSync?{browser:{},os:{},node:!1,wxa:!0,canvasSupported:!0,svgSupported:!1,touchEventsSupported:!0,domSupported:!1}:"undefined"==typeof document&&"undefined"!=typeof self?{browser:{},os:{},node:!1,worker:!0,canvasSupported:!0,domSupported:!1}:"undefined"==typeof navigator?{browser:{},os:{},node:!0,worker:!1,canvasSupported:!0,svgSupported:!0,domSupported:!1}:function(t){var e={},n=t.match(/Firefox\/([\d.]+)/),i=t.match(/MSIE\s([\d.]+)/)||t.match(/Trident\/.+?rv:(([\d.]+))/),r=t.match(/Edge\/([\d.]+)/),a=/micromessenger/i.test(t)
return n&&(e.firefox=!0,e.version=n[1]),i&&(e.ie=!0,e.version=i[1]),r&&(e.edge=!0,e.version=r[1]),a&&(e.weChat=!0),{browser:e,os:{},node:!1,canvasSupported:!!document.createElement("canvas").getContext,svgSupported:"undefined"!=typeof SVGRect,touchEventsSupported:"ontouchstart"in window&&!e.ie&&!e.edge,pointerEventsSupported:"onpointerdown"in window&&(e.edge||e.ie&&e.version>=11),domSupported:"undefined"!=typeof document}}(navigator.userAgent)
t.exports=n},function(t,e){var n="undefined"==typeof Float32Array?Array:Float32Array
function i(t){return Math.sqrt(a(t))}var r=i
function a(t){return t[0]*t[0]+t[1]*t[1]}var o=a
function s(t,e){return Math.sqrt((t[0]-e[0])*(t[0]-e[0])+(t[1]-e[1])*(t[1]-e[1]))}var l=s
function u(t,e){return(t[0]-e[0])*(t[0]-e[0])+(t[1]-e[1])*(t[1]-e[1])}var h=u
e.create=function(t,e){var i=new n(2)
return null==t&&(t=0),null==e&&(e=0),i[0]=t,i[1]=e,i},e.copy=function(t,e){return t[0]=e[0],t[1]=e[1],t},e.clone=function(t){var e=new n(2)
return e[0]=t[0],e[1]=t[1],e},e.set=function(t,e,n){return t[0]=e,t[1]=n,t},e.add=function(t,e,n){return t[0]=e[0]+n[0],t[1]=e[1]+n[1],t},e.scaleAndAdd=function(t,e,n,i){return t[0]=e[0]+n[0]*i,t[1]=e[1]+n[1]*i,t},e.sub=function(t,e,n){return t[0]=e[0]-n[0],t[1]=e[1]-n[1],t},e.len=i,e.length=r,e.lenSquare=a,e.lengthSquare=o,e.mul=function(t,e,n){return t[0]=e[0]*n[0],t[1]=e[1]*n[1],t},e.div=function(t,e,n){return t[0]=e[0]/n[0],t[1]=e[1]/n[1],t},e.dot=function(t,e){return t[0]*e[0]+t[1]*e[1]},e.scale=function(t,e,n){return t[0]=e[0]*n,t[1]=e[1]*n,t},e.normalize=function(t,e){var n=i(e)
return 0===n?(t[0]=0,t[1]=0):(t[0]=e[0]/n,t[1]=e[1]/n),t},e.distance=s,e.dist=l,e.distanceSquare=u,e.distSquare=h,e.negate=function(t,e){return t[0]=-e[0],t[1]=-e[1],t},e.lerp=function(t,e,n,i){return t[0]=e[0]+i*(n[0]-e[0]),t[1]=e[1]+i*(n[1]-e[1]),t},e.applyTransform=function(t,e,n){var i=e[0],r=e[1]
return t[0]=n[0]*i+n[2]*r+n[4],t[1]=n[1]*i+n[3]*r+n[5],t},e.min=function(t,e,n){return t[0]=Math.min(e[0],n[0]),t[1]=Math.min(e[1],n[1]),t},e.max=function(t,e,n){return t[0]=Math.max(e[0],n[0]),t[1]=Math.max(e[1],n[1]),t}},function(t,e,n){var i=n(236),r=n(207),a=n(237),o=n(321),s=n(266).prototype.getCanvasPattern,l=Math.abs,u=new a(!0)
function h(t){i.call(this,t),this.path=null}h.prototype={constructor:h,type:"path",__dirtyPath:!0,strokeContainThreshold:5,segmentIgnoreThreshold:0,subPixelOptimize:!1,brush:function(t,e){var n,i=this.style,r=this.path||u,a=i.hasStroke(),o=i.hasFill(),l=i.fill,h=i.stroke,c=o&&!!l.colorStops,f=a&&!!h.colorStops,d=o&&!!l.image,p=a&&!!h.image
i.bind(t,this,e),this.setTransform(t),this.__dirty&&(c&&(n=n||this.getBoundingRect(),this._fillGradient=i.getGradient(t,l,n)),f&&(n=n||this.getBoundingRect(),this._strokeGradient=i.getGradient(t,h,n))),c?t.fillStyle=this._fillGradient:d&&(t.fillStyle=s.call(l,t)),f?t.strokeStyle=this._strokeGradient:p&&(t.strokeStyle=s.call(h,t))
var g=i.lineDash,v=i.lineDashOffset,m=!!t.setLineDash,_=this.getGlobalScale()
if(r.setScale(_[0],_[1],this.segmentIgnoreThreshold),this.__dirtyPath||g&&!m&&a?(r.beginPath(t),g&&!m&&(r.setLineDash(g),r.setLineDashOffset(v)),this.buildPath(r,this.shape,!1),this.path&&(this.__dirtyPath=!1)):(t.beginPath(),this.path.rebuildPath(t)),o)if(null!=i.fillOpacity){var y=t.globalAlpha
t.globalAlpha=i.fillOpacity*i.opacity,r.fill(t),t.globalAlpha=y}else r.fill(t)
g&&m&&(t.setLineDash(g),t.lineDashOffset=v),a&&(null!=i.strokeOpacity?(y=t.globalAlpha,t.globalAlpha=i.strokeOpacity*i.opacity,r.stroke(t),t.globalAlpha=y):r.stroke(t)),g&&m&&t.setLineDash([]),null!=i.text&&(this.restoreTransform(t),this.drawRectText(t,this.getBoundingRect()))},buildPath:function(t,e,n){},createPathProxy:function(){this.path=new a},getBoundingRect:function(){var t=this._rect,e=this.style,n=!t
if(n){var i=this.path
i||(i=this.path=new a),this.__dirtyPath&&(i.beginPath(),this.buildPath(i,this.shape,!1)),t=i.getBoundingRect()}if(this._rect=t,e.hasStroke()){var r=this._rectWithStroke||(this._rectWithStroke=t.clone())
if(this.__dirty||n){r.copy(t)
var o=e.lineWidth,s=e.strokeNoScale?this.getLineScale():1
e.hasFill()||(o=Math.max(o,this.strokeContainThreshold||4)),s>1e-10&&(r.width+=o/s,r.height+=o/s,r.x-=o/s/2,r.y-=o/s/2)}return r}return t},contain:function(t,e){var n=this.transformCoordToLocal(t,e),i=this.getBoundingRect(),r=this.style
if(t=n[0],e=n[1],i.contain(t,e)){var a=this.path.data
if(r.hasStroke()){var s=r.lineWidth,l=r.strokeNoScale?this.getLineScale():1
if(l>1e-10&&(r.hasFill()||(s=Math.max(s,this.strokeContainThreshold)),o.containStroke(a,s/l,t,e)))return!0}if(r.hasFill())return o.contain(a,t,e)}return!1},dirty:function(t){null==t&&(t=!0),t&&(this.__dirtyPath=t,this._rect=null),this.__dirty=this.__dirtyText=!0,this.__zr&&this.__zr.refresh(),this.__clipTarget&&this.__clipTarget.dirty()},animateShape:function(t){return this.animate("shape",t)},attrKV:function(t,e){"shape"===t?(this.setShape(e),this.__dirtyPath=!0,this._rect=null):i.prototype.attrKV.call(this,t,e)},setShape:function(t,e){var n=this.shape
if(n){if(r.isObject(t))for(var i in t)t.hasOwnProperty(i)&&(n[i]=t[i])
else n[t]=e
this.dirty(!0)}return this},getLineScale:function(){var t=this.transform
return t&&l(t[0]-1)>1e-10&&l(t[3]-1)>1e-10?Math.sqrt(l(t[0]*t[3]-t[2]*t[1])):1}},h.extend=function(t){var e=function(e){h.call(this,e),t.style&&this.style.extendFrom(t.style,!1)
var n=t.shape
if(n){this.shape=this.shape||{}
var i=this.shape
for(var r in n)!i.hasOwnProperty(r)&&n.hasOwnProperty(r)&&(i[r]=n[r])}t.init&&t.init.call(this,e)}
for(var n in r.inherits(e,h),t)"style"!==n&&"shape"!==n&&(e.prototype[n]=t[n])
return e},r.inherits(h,i)
var c=h
t.exports=c},function(t,e,n){var i=n(207),r=/^(?:(\d{4})(?:[-\/](\d{1,2})(?:[-\/](\d{1,2})(?:[T ](\d{1,2})(?::(\d\d)(?::(\d\d)(?:[.,](\d+))?)?)?(Z|[\+\-]\d\d:?\d\d)?)?)?)?)?$/
function a(t){if(0===t)return 0
var e=Math.floor(Math.log(t)/Math.LN10)
return t/Math.pow(10,e)>=10&&e++,e}e.linearMap=function(t,e,n,i){var r=e[1]-e[0],a=n[1]-n[0]
if(0===r)return 0===a?n[0]:(n[0]+n[1])/2
if(i)if(r>0){if(t<=e[0])return n[0]
if(t>=e[1])return n[1]}else{if(t>=e[0])return n[0]
if(t<=e[1])return n[1]}else{if(t===e[0])return n[0]
if(t===e[1])return n[1]}return(t-e[0])/r*a+n[0]},e.parsePercent=function(t,e){switch(t){case"center":case"middle":t="50%"
break
case"left":case"top":t="0%"
break
case"right":case"bottom":t="100%"}return"string"==typeof t?(n=t,n.replace(/^\s+|\s+$/g,"")).match(/%$/)?parseFloat(t)/100*e:parseFloat(t):null==t?NaN:+t
var n},e.round=function(t,e,n){return null==e&&(e=10),e=Math.min(Math.max(0,e),20),t=(+t).toFixed(e),n?t:+t},e.asc=function(t){return t.sort((function(t,e){return t-e})),t},e.getPrecision=function(t){if(t=+t,isNaN(t))return 0
for(var e=1,n=0;Math.round(t*e)/e!==t;)e*=10,n++
return n},e.getPrecisionSafe=function(t){var e=t.toString(),n=e.indexOf("e")
if(n>0){var i=+e.slice(n+1)
return i<0?-i:0}var r=e.indexOf(".")
return r<0?0:e.length-1-r},e.getPixelPrecision=function(t,e){var n=Math.log,i=Math.LN10,r=Math.floor(n(t[1]-t[0])/i),a=Math.round(n(Math.abs(e[1]-e[0]))/i),o=Math.min(Math.max(-r+a,0),20)
return isFinite(o)?o:20},e.getPercentWithPrecision=function(t,e,n){if(!t[e])return 0
var r=i.reduce(t,(function(t,e){return t+(isNaN(e)?0:e)}),0)
if(0===r)return 0
for(var a=Math.pow(10,n),o=i.map(t,(function(t){return(isNaN(t)?0:t)/r*a*100})),s=100*a,l=i.map(o,(function(t){return Math.floor(t)})),u=i.reduce(l,(function(t,e){return t+e}),0),h=i.map(o,(function(t,e){return t-l[e]}));u<s;){for(var c=Number.NEGATIVE_INFINITY,f=null,d=0,p=h.length;d<p;++d)h[d]>c&&(c=h[d],f=d);++l[f],h[f]=0,++u}return l[e]/a},e.MAX_SAFE_INTEGER=9007199254740991,e.remRadian=function(t){var e=2*Math.PI
return(t%e+e)%e},e.isRadianAroundZero=function(t){return t>-1e-4&&t<1e-4},e.parseDate=function(t){if(t instanceof Date)return t
if("string"==typeof t){var e=r.exec(t)
if(!e)return new Date(NaN)
if(e[8]){var n=+e[4]||0
return"Z"!==e[8].toUpperCase()&&(n-=e[8].slice(0,3)),new Date(Date.UTC(+e[1],+(e[2]||1)-1,+e[3]||1,n,+(e[5]||0),+e[6]||0,+e[7]||0))}return new Date(+e[1],+(e[2]||1)-1,+e[3]||1,+e[4]||0,+(e[5]||0),+e[6]||0,+e[7]||0)}return null==t?new Date(NaN):new Date(Math.round(t))},e.quantity=function(t){return Math.pow(10,a(t))},e.quantityExponent=a,e.nice=function(t,e){var n=a(t),i=Math.pow(10,n),r=t/i
return t=(e?r<1.5?1:r<2.5?2:r<4?3:r<7?5:10:r<1?1:r<2?2:r<3?3:r<5?5:10)*i,n>=-20?+t.toFixed(n<0?-n:0):t},e.quantile=function(t,e){var n=(t.length-1)*e+1,i=Math.floor(n),r=+t[i-1],a=n-i
return a?r+a*(t[i]-r):r},e.reformIntervals=function(t){t.sort((function(t,e){return function t(e,n,i){return e.interval[i]<n.interval[i]||e.interval[i]===n.interval[i]&&(e.close[i]-n.close[i]==(i?-1:1)||!i&&t(e,n,1))}(t,e,0)?-1:1}))
for(var e=-1/0,n=1,i=0;i<t.length;){for(var r=t[i].interval,a=t[i].close,o=0;o<2;o++)r[o]<=e&&(r[o]=e,a[o]=o?1:1-n),e=r[o],n=a[o]
r[0]===r[1]&&a[0]*a[1]!=1?t.splice(i,1):i++}return t},e.isNumeric=function(t){return t-parseFloat(t)>=0}},function(t,e,n){var i,r,a,o,s=n(212),l=n(221),u=s.applyTransform,h=Math.min,c=Math.max
function f(t,e,n,i){n<0&&(t+=n,n=-n),i<0&&(e+=i,i=-i),this.x=t,this.y=e,this.width=n,this.height=i}f.prototype={constructor:f,union:function(t){var e=h(t.x,this.x),n=h(t.y,this.y)
this.width=c(t.x+t.width,this.x+this.width)-e,this.height=c(t.y+t.height,this.y+this.height)-n,this.x=e,this.y=n},applyTransform:(i=[],r=[],a=[],o=[],function(t){if(t){i[0]=a[0]=this.x,i[1]=o[1]=this.y,r[0]=o[0]=this.x+this.width,r[1]=a[1]=this.y+this.height,u(i,i,t),u(r,r,t),u(a,a,t),u(o,o,t),this.x=h(i[0],r[0],a[0],o[0]),this.y=h(i[1],r[1],a[1],o[1])
var e=c(i[0],r[0],a[0],o[0]),n=c(i[1],r[1],a[1],o[1])
this.width=e-this.x,this.height=n-this.y}}),calculateTransform:function(t){var e=this,n=t.width/e.width,i=t.height/e.height,r=l.create()
return l.translate(r,r,[-e.x,-e.y]),l.scale(r,r,[n,i]),l.translate(r,r,[t.x,t.y]),r},intersect:function(t){if(!t)return!1
t instanceof f||(t=f.create(t))
var e=this,n=e.x,i=e.x+e.width,r=e.y,a=e.y+e.height,o=t.x,s=t.x+t.width,l=t.y,u=t.y+t.height
return!(i<o||s<n||a<l||u<r)},contain:function(t,e){return t>=this.x&&t<=this.x+this.width&&e>=this.y&&e<=this.y+this.height},clone:function(){return new f(this.x,this.y,this.width,this.height)},copy:function(t){this.x=t.x,this.y=t.y,this.width=t.width,this.height=t.height},plain:function(){return{x:this.x,y:this.y,width:this.width,height:this.height}}},f.create=function(t){return new f(t.x,t.y,t.width,t.height)}
var d=f
t.exports=d},function(t,e,n){var i=n(207),r=n(217),a=n(214),o=i.normalizeCssArray,s=/([&<>"'])/g,l={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}
function u(t){return null==t?"":(t+"").replace(s,(function(t,e){return l[e]}))}var h=["a","b","c","d","e","f","g"],c=function(t,e){return"{"+t+(null==e?"":e)+"}"}
function f(t,e){return"0000".substr(0,e-(t+="").length)+t}var d=r.truncateText
e.addCommas=function(t){return isNaN(t)?"-":(t=(t+"").split("."))[0].replace(/(\d{1,3})(?=(?:\d{3})+(?!\d))/g,"$1,")+(t.length>1?"."+t[1]:"")},e.toCamelCase=function(t,e){return t=(t||"").toLowerCase().replace(/-(.)/g,(function(t,e){return e.toUpperCase()})),e&&t&&(t=t.charAt(0).toUpperCase()+t.slice(1)),t},e.normalizeCssArray=o,e.encodeHTML=u,e.formatTpl=function(t,e,n){i.isArray(e)||(e=[e])
var r=e.length
if(!r)return""
for(var a=e[0].$vars||[],o=0;o<a.length;o++){var s=h[o]
t=t.replace(c(s),c(s,0))}for(var l=0;l<r;l++)for(var f=0;f<a.length;f++){var d=e[l][a[f]]
t=t.replace(c(h[f],l),n?u(d):d)}return t},e.formatTplSimple=function(t,e,n){return i.each(e,(function(e,i){t=t.replace("{"+i+"}",n?u(e):e)})),t},e.getTooltipMarker=function(t,e){var n=(t=i.isString(t)?{color:t,extraCssText:e}:t||{}).color,r=t.type,a=(e=t.extraCssText,t.renderMode||"html"),o=t.markerId||"X"
return n?"html"===a?"subItem"===r?'<span style="display:inline-block;vertical-align:middle;margin-right:8px;margin-left:3px;border-radius:4px;width:4px;height:4px;background-color:'+u(n)+";"+(e||"")+'"></span>':'<span style="display:inline-block;margin-right:5px;border-radius:10px;width:10px;height:10px;background-color:'+u(n)+";"+(e||"")+'"></span>':{renderMode:a,content:"{marker"+o+"|}  ",style:{color:n}}:""},e.formatTime=function(t,e,n){"week"!==t&&"month"!==t&&"quarter"!==t&&"half-year"!==t&&"year"!==t||(t="MM-dd\nyyyy")
var i=a.parseDate(e),r=n?"UTC":"",o=i["get"+r+"FullYear"](),s=i["get"+r+"Month"]()+1,l=i["get"+r+"Date"](),u=i["get"+r+"Hours"](),h=i["get"+r+"Minutes"](),c=i["get"+r+"Seconds"](),d=i["get"+r+"Milliseconds"]()
return t.replace("MM",f(s,2)).replace("M",s).replace("yyyy",o).replace("yy",o%100).replace("dd",f(l,2)).replace("d",l).replace("hh",f(u,2)).replace("h",u).replace("mm",f(h,2)).replace("m",h).replace("ss",f(c,2)).replace("s",c).replace("SSS",f(d,3))},e.capitalFirst=function(t){return t?t.charAt(0).toUpperCase()+t.substr(1):t},e.truncateText=d,e.getTextBoundingRect=function(t){return r.getBoundingRect(t.text,t.font,t.textAlign,t.textVerticalAlign,t.textPadding,t.textLineHeight,t.rich,t.truncate)},e.getTextRect=function(t,e,n,i,a,o,s,l){return r.getBoundingRect(t,e,n,i,a,l,o,s)},e.windowOpen=function(t,e){if("_blank"===e||"blank"===e){var n=window.open()
n.opener=null,n.location=t}else window.open(t,e)}},function(t,e,n){var i=n(215),r=n(244),a=n(207),o=a.getContext,s=a.extend,l=a.retrieve2,u=a.retrieve3,h=a.trim,c={},f=0,d=/\{([a-zA-Z0-9_]+)\|([^}]*)\}/g,p={}
function g(t,e){var n=t+":"+(e=e||"12px sans-serif")
if(c[n])return c[n]
for(var i=(t+"").split("\n"),r=0,a=0,o=i.length;a<o;a++)r=Math.max(T(i[a],e).width,r)
return f>5e3&&(f=0,c={}),f++,c[n]=r,r}function v(t,e,n){return"right"===n?t-=e:"center"===n&&(t-=e/2),t}function m(t,e,n){return"middle"===n?t-=e/2:"bottom"===n&&(t-=e),t}function _(t,e,n){var i=e.textPosition,r=e.textDistance,a=n.x,o=n.y
r=r||0
var s=n.height,l=n.width,u=s/2,h="left",c="top"
switch(i){case"left":a-=r,o+=u,h="right",c="middle"
break
case"right":a+=r+l,o+=u,c="middle"
break
case"top":a+=l/2,o-=r,h="center",c="bottom"
break
case"bottom":a+=l/2,o+=s+r,h="center"
break
case"inside":a+=l/2,o+=u,h="center",c="middle"
break
case"insideLeft":a+=r,o+=u,c="middle"
break
case"insideRight":a+=l-r,o+=u,h="right",c="middle"
break
case"insideTop":a+=l/2,o+=r,h="center"
break
case"insideBottom":a+=l/2,o+=s-r,h="center",c="bottom"
break
case"insideTopLeft":a+=r,o+=r
break
case"insideTopRight":a+=l-r,o+=r,h="right"
break
case"insideBottomLeft":a+=r,o+=s-r,c="bottom"
break
case"insideBottomRight":a+=l-r,o+=s-r,h="right",c="bottom"}return(t=t||{}).x=a,t.y=o,t.textAlign=h,t.textVerticalAlign=c,t}function y(t,e,n,i,r){if(!e)return""
var a=(t+"").split("\n")
r=x(e,n,i,r)
for(var o=0,s=a.length;o<s;o++)a[o]=w(a[o],r)
return a.join("\n")}function x(t,e,n,i){(i=s({},i)).font=e,n=l(n,"..."),i.maxIterations=l(i.maxIterations,2)
var r=i.minChar=l(i.minChar,0)
i.cnCharWidth=g("国",e)
var a=i.ascCharWidth=g("a",e)
i.placeholder=l(i.placeholder,"")
for(var o=t=Math.max(0,t-1),u=0;u<r&&o>=a;u++)o-=a
var h=g(n,e)
return h>o&&(n="",h=0),o=t-h,i.ellipsis=n,i.ellipsisWidth=h,i.contentWidth=o,i.containerWidth=t,i}function w(t,e){var n=e.containerWidth,i=e.font,r=e.contentWidth
if(!n)return""
var a=g(t,i)
if(a<=n)return t
for(var o=0;;o++){if(a<=r||o>=e.maxIterations){t+=e.ellipsis
break}var s=0===o?b(t,r,e.ascCharWidth,e.cnCharWidth):a>0?Math.floor(t.length*r/a):0
a=g(t=t.substr(0,s),i)}return""===t&&(t=e.placeholder),t}function b(t,e,n,i){for(var r=0,a=0,o=t.length;a<o&&r<e;a++){var s=t.charCodeAt(a)
r+=0<=s&&s<=127?n:i}return a}function S(t){return g("国",t)}function T(t,e){return p.measureText(t,e)}function M(t,e,n,i,r){null!=t&&(t+="")
var a=l(i,S(e)),o=t?t.split("\n"):[],s=o.length*a,u=s,h=!0
if(n&&(u+=n[0]+n[2]),t&&r){h=!1
var c=r.outerHeight,f=r.outerWidth
if(null!=c&&u>c)t="",o=[]
else if(null!=f)for(var d=x(f-(n?n[1]+n[3]:0),e,r.ellipsis,{minChar:r.minChar,placeholder:r.placeholder}),p=0,g=o.length;p<g;p++)o[p]=w(o[p],d)}return{lines:o,height:s,outerHeight:u,lineHeight:a,canCacheByTextString:h}}function C(t,e){var n={lines:[],width:0,height:0}
if(null!=t&&(t+=""),!t)return n
for(var i,a=d.lastIndex=0;null!=(i=d.exec(t));){var o=i.index
o>a&&k(n,t.substring(a,o)),k(n,i[2],i[1]),a=d.lastIndex}a<t.length&&k(n,t.substring(a,t.length))
var s=n.lines,h=0,c=0,f=[],p=e.textPadding,v=e.truncate,m=v&&v.outerWidth,_=v&&v.outerHeight
p&&(null!=m&&(m-=p[1]+p[3]),null!=_&&(_-=p[0]+p[2]))
for(var x=0;x<s.length;x++){for(var w=s[x],b=0,T=0,M=0;M<w.tokens.length;M++){var C=(N=w.tokens[M]).styleName&&e.rich[N.styleName]||{},D=N.textPadding=C.textPadding,I=N.font=C.font||e.font,A=N.textHeight=l(C.textHeight,S(I))
if(D&&(A+=D[0]+D[2]),N.height=A,N.lineHeight=u(C.textLineHeight,e.textLineHeight,A),N.textAlign=C&&C.textAlign||e.textAlign,N.textVerticalAlign=C&&C.textVerticalAlign||"middle",null!=_&&h+N.lineHeight>_)return{lines:[],width:0,height:0}
N.textWidth=g(N.text,I)
var O=C.textWidth,P=null==O||"auto"===O
if("string"==typeof O&&"%"===O.charAt(O.length-1))N.percentWidth=O,f.push(N),O=0
else{if(P){O=N.textWidth
var L=C.textBackgroundColor,E=L&&L.image
E&&(E=r.findExistImage(E),r.isImageReady(E)&&(O=Math.max(O,E.width*A/E.height)))}var R=D?D[1]+D[3]:0
O+=R
var B=null!=m?m-T:null
null!=B&&B<O&&(!P||B<R?(N.text="",N.textWidth=O=0):(N.text=y(N.text,B-R,I,v.ellipsis,{minChar:v.minChar}),N.textWidth=g(N.text,I),O=N.textWidth+R))}T+=N.width=O,C&&(b=Math.max(b,N.lineHeight))}w.width=T,w.lineHeight=b,h+=b,c=Math.max(c,T)}for(n.outerWidth=n.width=l(e.textWidth,c),n.outerHeight=n.height=l(e.textHeight,h),p&&(n.outerWidth+=p[1]+p[3],n.outerHeight+=p[0]+p[2]),x=0;x<f.length;x++){var N,F=(N=f[x]).percentWidth
N.width=parseInt(F,10)/100*c}return n}function k(t,e,n){for(var i=""===e,r=e.split("\n"),a=t.lines,o=0;o<r.length;o++){var s=r[o],l={styleName:n,text:s,isLineHolder:!s&&!i}
if(o)a.push({tokens:[l]})
else{var u=(a[a.length-1]||(a[0]={tokens:[]})).tokens,h=u.length
1===h&&u[0].isLineHolder?u[0]=l:(s||!h||i)&&u.push(l)}}}p.measureText=function(t,e){var n=o()
return n.font=e||"12px sans-serif",n.measureText(t)},e.DEFAULT_FONT="12px sans-serif",e.$override=function(t,e){p[t]=e},e.getWidth=g,e.getBoundingRect=function(t,e,n,r,a,o,s,l){return s?function(t,e,n,r,a,o,s,l){var u=C(t,{rich:s,truncate:l,font:e,textAlign:n,textPadding:a,textLineHeight:o}),h=u.outerWidth,c=u.outerHeight,f=v(0,h,n),d=m(0,c,r)
return new i(f,d,h,c)}(t,e,n,r,a,o,s,l):function(t,e,n,r,a,o,s){var l=M(t,e,a,o,s),u=g(t,e)
a&&(u+=a[1]+a[3])
var h=l.outerHeight,c=v(0,u,n),f=m(0,h,r),d=new i(c,f,u,h)
return d.lineHeight=l.lineHeight,d}(t,e,n,r,a,o,l)},e.adjustTextX=v,e.adjustTextY=m,e.calculateTextPosition=_,e.adjustTextPositionOnRect=function(t,e,n){return _({},{textPosition:t,textDistance:n},e)},e.truncateText=y,e.getLineHeight=S,e.measureText=T,e.parsePlainText=M,e.parseRichText=C,e.makeFont=function(t){var e=(t.fontSize||t.fontFamily)&&[t.fontStyle,t.fontWeight,(t.fontSize||12)+"px",t.fontFamily||"sans-serif"].join(" ")
return e&&h(e)||t.textFont||t.font}},function(t,e,n){var i=n(207),r=n(211),a=n(208).makeInner,o=n(219),s=o.enableClassExtend,l=o.enableClassCheck,u=n(318),h=n(319),c=n(320),f=n(336),d=i.mixin,p=a()
function g(t,e,n){this.parentModel=e,this.ecModel=n,this.option=t}function v(t,e,n){for(var i=0;i<e.length&&(!e[i]||null!=(t=t&&"object"==typeof t?t[e[i]]:null));i++);return null==t&&n&&(t=n.get(e)),t}function m(t,e){var n=p(t).getParent
return n?n.call(t,e):t.parentModel}g.prototype={constructor:g,init:null,mergeOption:function(t){i.merge(this.option,t,!0)},get:function(t,e){return null==t?this.option:v(this.option,this.parsePath(t),!e&&m(this,t))},getShallow:function(t,e){var n=this.option,i=null==n?n:n[t],r=!e&&m(this,t)
return null==i&&r&&(i=r.getShallow(t)),i},getModel:function(t,e){var n
return new g(null==t?this.option:v(this.option,t=this.parsePath(t)),e=e||(n=m(this,t))&&n.getModel(t),this.ecModel)},isEmpty:function(){return null==this.option},restoreData:function(){},clone:function(){return new(0,this.constructor)(i.clone(this.option))},setReadOnly:function(t){},parsePath:function(t){return"string"==typeof t&&(t=t.split(".")),t},customizeGetParent:function(t){p(this).getParent=t},isAnimationEnabled:function(){if(!r.node){if(null!=this.option.animation)return!!this.option.animation
if(this.parentModel)return this.parentModel.isAnimationEnabled()}}},s(g),l(g),d(g,u),d(g,h),d(g,c),d(g,f)
var _=g
t.exports=_},function(t,e,n){n(210).__DEV__
var i=n(207),r="___EC__COMPONENT__CONTAINER___"
function a(t){var e={main:"",sub:""}
return t&&(t=t.split("."),e.main=t[0]||"",e.sub=t[1]||""),e}var o=0
function s(t,e){var n=i.slice(arguments,2)
return this.superClass.prototype[e].apply(t,n)}function l(t,e,n){return this.superClass.prototype[e].apply(t,n)}e.parseClassType=a,e.enableClassExtend=function(t,e){t.$constructor=t,t.extend=function(t){var e=this,n=function(){t.$constructor?t.$constructor.apply(this,arguments):e.apply(this,arguments)}
return i.extend(n.prototype,t),n.extend=this.extend,n.superCall=s,n.superApply=l,i.inherits(n,this),n.superClass=e,n}},e.enableClassCheck=function(t){var e=["__\0is_clz",o++,Math.random().toFixed(3)].join("_")
t.prototype[e]=!0,t.isInstance=function(t){return!(!t||!t[e])}},e.enableClassManagement=function(t,e){e=e||{}
var n={}
if(t.registerClass=function(t,e){return e&&(function(t){i.assert(/^[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)?$/.test(t),'componentType "'+t+'" illegal')}(e),(e=a(e)).sub?e.sub!==r&&((function(t){var e=n[t.main]
return e&&e[r]||((e=n[t.main]={})[r]=!0),e}(e))[e.sub]=t):n[e.main]=t),t},t.getClass=function(t,e,i){var a=n[t]
if(a&&a[r]&&(a=e?a[e]:null),i&&!a)throw new Error(e?"Component "+t+"."+(e||"")+" not exists. Load it first.":t+".type should be specified.")
return a},t.getClassesByMainType=function(t){t=a(t)
var e=[],o=n[t.main]
return o&&o[r]?i.each(o,(function(t,n){n!==r&&e.push(t)})):e.push(o),e},t.hasClass=function(t){return t=a(t),!!n[t.main]},t.getAllClassMainTypes=function(){var t=[]
return i.each(n,(function(e,n){t.push(n)})),t},t.hasSubTypes=function(t){t=a(t)
var e=n[t.main]
return e&&e[r]},t.parseClassType=a,e.registerWhenExtend){var o=t.extend
o&&(t.extend=function(e){var n=o.call(this,e)
return t.registerClass(n,e.type)})}return t},e.setReadOnly=function(t,e){}},function(t,e,n){var i=n(207),r=n(218),a=n(238),o=n(219),s=o.enableClassManagement,l=o.parseClassType,u=n(208).makeInner,h=n(224),c=n(337),f=u(),d=r.extend({type:"component",id:"",name:"",mainType:"",subType:"",componentIndex:0,defaultOption:null,ecModel:null,dependentModels:[],uid:null,layoutMode:null,$constructor:function(t,e,n,i){r.call(this,t,e,n,i),this.uid=a.getUID("ec_cpt_model")},init:function(t,e,n,i){this.mergeDefaultAndTheme(t,n)},mergeDefaultAndTheme:function(t,e){var n=this.layoutMode,r=n?h.getLayoutParams(t):{},a=e.getTheme()
i.merge(t,a.get(this.mainType)),i.merge(t,this.getDefaultOption()),n&&h.mergeLayoutParam(t,r,n)},mergeOption:function(t,e){i.merge(this.option,t,!0)
var n=this.layoutMode
n&&h.mergeLayoutParam(this.option,t,n)},optionUpdated:function(t,e){},getDefaultOption:function(){var t=f(this)
if(!t.defaultOption){for(var e=[],n=this.constructor;n;){var r=n.prototype.defaultOption
r&&e.push(r),n=n.superClass}for(var a={},o=e.length-1;o>=0;o--)a=i.merge(a,e[o],!0)
t.defaultOption=a}return t.defaultOption},getReferringComponents:function(t){return this.ecModel.queryComponents({mainType:t,index:this.get(t+"Index",!0),id:this.get(t+"Id",!0)})}})
s(d,{registerWhenExtend:!0}),a.enableSubTypeDefaulter(d),a.enableTopologicalTravel(d,(function(t){var e=[]
return i.each(d.getClassesByMainType(t),(function(t){e=e.concat(t.prototype.dependencies||[])})),e=i.map(e,(function(t){return l(t).main})),"dataset"!==t&&i.indexOf(e,"dataset")<=0&&e.unshift("dataset"),e})),i.mixin(d,c)
var p=d
t.exports=p},function(t,e){var n="undefined"==typeof Float32Array?Array:Float32Array
function i(){var t=new n(6)
return r(t),t}function r(t){return t[0]=1,t[1]=0,t[2]=0,t[3]=1,t[4]=0,t[5]=0,t}function a(t,e){return t[0]=e[0],t[1]=e[1],t[2]=e[2],t[3]=e[3],t[4]=e[4],t[5]=e[5],t}e.create=i,e.identity=r,e.copy=a,e.mul=function(t,e,n){var i=e[0]*n[0]+e[2]*n[1],r=e[1]*n[0]+e[3]*n[1],a=e[0]*n[2]+e[2]*n[3],o=e[1]*n[2]+e[3]*n[3],s=e[0]*n[4]+e[2]*n[5]+e[4],l=e[1]*n[4]+e[3]*n[5]+e[5]
return t[0]=i,t[1]=r,t[2]=a,t[3]=o,t[4]=s,t[5]=l,t},e.translate=function(t,e,n){return t[0]=e[0],t[1]=e[1],t[2]=e[2],t[3]=e[3],t[4]=e[4]+n[0],t[5]=e[5]+n[1],t},e.rotate=function(t,e,n){var i=e[0],r=e[2],a=e[4],o=e[1],s=e[3],l=e[5],u=Math.sin(n),h=Math.cos(n)
return t[0]=i*h+o*u,t[1]=-i*u+o*h,t[2]=r*h+s*u,t[3]=-r*u+h*s,t[4]=h*a+u*l,t[5]=h*l-u*a,t},e.scale=function(t,e,n){var i=n[0],r=n[1]
return t[0]=e[0]*i,t[1]=e[1]*r,t[2]=e[2]*i,t[3]=e[3]*r,t[4]=e[4]*i,t[5]=e[5]*r,t},e.invert=function(t,e){var n=e[0],i=e[2],r=e[4],a=e[1],o=e[3],s=e[5],l=n*o-a*i
return l?(l=1/l,t[0]=o*l,t[1]=-a*l,t[2]=-i*l,t[3]=n*l,t[4]=(i*s-o*r)*l,t[5]=(a*r-n*s)*l,t):null},e.clone=function(t){var e=i()
return a(e,t),e}},function(t,e,n){var i=n(227)
e.Dispatcher=i
var r=n(211),a=n(259),o=a.isCanvasEl,s=a.transformCoordWithViewport,l="undefined"!=typeof window&&!!window.addEventListener,u=/^(?:mouse|pointer|contextmenu|drag|drop)|click/,h=[]
function c(t,e,n,i){return n=n||{},i||!r.canvasSupported?f(t,e,n):r.browser.firefox&&null!=e.layerX&&e.layerX!==e.offsetX?(n.zrX=e.layerX,n.zrY=e.layerY):null!=e.offsetX?(n.zrX=e.offsetX,n.zrY=e.offsetY):f(t,e,n),n}function f(t,e,n){if(r.domSupported&&t.getBoundingClientRect){var i=e.clientX,a=e.clientY
if(o(t)){var l=t.getBoundingClientRect()
return n.zrX=i-l.left,void(n.zrY=a-l.top)}if(s(h,t,i,a))return n.zrX=h[0],void(n.zrY=h[1])}n.zrX=n.zrY=0}function d(t){return t||window.event}var p=l?function(t){t.preventDefault(),t.stopPropagation(),t.cancelBubble=!0}:function(t){t.returnValue=!1,t.cancelBubble=!0}
e.clientToLocal=c,e.getNativeEvent=d,e.normalizeEvent=function(t,e,n){if(null!=(e=d(e)).zrX)return e
var i=e.type
if(i&&i.indexOf("touch")>=0){var r="touchend"!==i?e.targetTouches[0]:e.changedTouches[0]
r&&c(t,r,e,n)}else c(t,e,e,n),e.zrDelta=e.wheelDelta?e.wheelDelta/120:-(e.detail||0)/3
var a=e.button
return null==e.which&&void 0!==a&&u.test(e.type)&&(e.which=1&a?1:2&a?3:4&a?2:0),e},e.addEventListener=function(t,e,n,i){l?t.addEventListener(e,n,i):t.attachEvent("on"+e,n)},e.removeEventListener=function(t,e,n,i){l?t.removeEventListener(e,n,i):t.detachEvent("on"+e,n)},e.stop=p,e.isMiddleOrRightButtonOnMouseUpDown=function(t){return 2===t.which||3===t.which},e.notLeftMouse=function(t){return t.which>1}},function(t,e,n){var i=n(212),r=i.create,a=i.distSquare,o=Math.pow,s=Math.sqrt,l=s(3),u=r(),h=r(),c=r()
function f(t){return t>-1e-8&&t<1e-8}function d(t){return t>1e-8||t<-1e-8}function p(t,e,n,i,r){var a=1-r
return a*a*(a*t+3*r*e)+r*r*(r*i+3*a*n)}function g(t,e,n,i){var r=1-i
return r*(r*t+2*i*e)+i*i*n}e.cubicAt=p,e.cubicDerivativeAt=function(t,e,n,i,r){var a=1-r
return 3*(((e-t)*a+2*(n-e)*r)*a+(i-n)*r*r)},e.cubicRootAt=function(t,e,n,i,r,a){var u=i+3*(e-n)-t,h=3*(n-2*e+t),c=3*(e-t),d=t-r,p=h*h-3*u*c,g=h*c-9*u*d,v=c*c-3*h*d,m=0
if(f(p)&&f(g))f(h)?a[0]=0:(D=-c/h)>=0&&D<=1&&(a[m++]=D)
else{var _=g*g-4*p*v
if(f(_)){var y=g/p,x=-y/2;(D=-h/u+y)>=0&&D<=1&&(a[m++]=D),x>=0&&x<=1&&(a[m++]=x)}else if(_>0){var w=s(_),b=p*h+1.5*u*(-g+w),S=p*h+1.5*u*(-g-w);(D=(-h-((b=b<0?-o(-b,1/3):o(b,1/3))+(S=S<0?-o(-S,1/3):o(S,1/3))))/(3*u))>=0&&D<=1&&(a[m++]=D)}else{var T=(2*p*h-3*u*g)/(2*s(p*p*p)),M=Math.acos(T)/3,C=s(p),k=Math.cos(M),D=(-h-2*C*k)/(3*u),I=(x=(-h+C*(k+l*Math.sin(M)))/(3*u),(-h+C*(k-l*Math.sin(M)))/(3*u))
D>=0&&D<=1&&(a[m++]=D),x>=0&&x<=1&&(a[m++]=x),I>=0&&I<=1&&(a[m++]=I)}}return m},e.cubicExtrema=function(t,e,n,i,r){var a=6*n-12*e+6*t,o=9*e+3*i-3*t-9*n,l=3*e-3*t,u=0
if(f(o))d(a)&&(c=-l/a)>=0&&c<=1&&(r[u++]=c)
else{var h=a*a-4*o*l
if(f(h))r[0]=-a/(2*o)
else if(h>0){var c,p=s(h),g=(-a-p)/(2*o);(c=(-a+p)/(2*o))>=0&&c<=1&&(r[u++]=c),g>=0&&g<=1&&(r[u++]=g)}}return u},e.cubicSubdivide=function(t,e,n,i,r,a){var o=(e-t)*r+t,s=(n-e)*r+e,l=(i-n)*r+n,u=(s-o)*r+o,h=(l-s)*r+s,c=(h-u)*r+u
a[0]=t,a[1]=o,a[2]=u,a[3]=c,a[4]=c,a[5]=h,a[6]=l,a[7]=i},e.cubicProjectPoint=function(t,e,n,i,r,o,l,f,d,g,v){var m,_,y,x,w,b=.005,S=1/0
u[0]=d,u[1]=g
for(var T=0;T<1;T+=.05)h[0]=p(t,n,r,l,T),h[1]=p(e,i,o,f,T),(x=a(u,h))<S&&(m=T,S=x)
S=1/0
for(var M=0;M<32&&!(b<1e-4);M++)_=m-b,y=m+b,h[0]=p(t,n,r,l,_),h[1]=p(e,i,o,f,_),x=a(h,u),_>=0&&x<S?(m=_,S=x):(c[0]=p(t,n,r,l,y),c[1]=p(e,i,o,f,y),w=a(c,u),y<=1&&w<S?(m=y,S=w):b*=.5)
return v&&(v[0]=p(t,n,r,l,m),v[1]=p(e,i,o,f,m)),s(S)},e.quadraticAt=g,e.quadraticDerivativeAt=function(t,e,n,i){return 2*((1-i)*(e-t)+i*(n-e))},e.quadraticRootAt=function(t,e,n,i,r){var a=t-2*e+n,o=2*(e-t),l=t-i,u=0
if(f(a))d(o)&&(c=-l/o)>=0&&c<=1&&(r[u++]=c)
else{var h=o*o-4*a*l
if(f(h))(c=-o/(2*a))>=0&&c<=1&&(r[u++]=c)
else if(h>0){var c,p=s(h),g=(-o-p)/(2*a);(c=(-o+p)/(2*a))>=0&&c<=1&&(r[u++]=c),g>=0&&g<=1&&(r[u++]=g)}}return u},e.quadraticExtremum=function(t,e,n){var i=t+n-2*e
return 0===i?.5:(t-e)/i},e.quadraticSubdivide=function(t,e,n,i,r){var a=(e-t)*i+t,o=(n-e)*i+e,s=(o-a)*i+a
r[0]=t,r[1]=a,r[2]=s,r[3]=s,r[4]=o,r[5]=n},e.quadraticProjectPoint=function(t,e,n,i,r,o,l,f,d){var p,v=.005,m=1/0
u[0]=l,u[1]=f
for(var _=0;_<1;_+=.05)h[0]=g(t,n,r,_),h[1]=g(e,i,o,_),(b=a(u,h))<m&&(p=_,m=b)
m=1/0
for(var y=0;y<32&&!(v<1e-4);y++){var x=p-v,w=p+v
h[0]=g(t,n,r,x),h[1]=g(e,i,o,x)
var b=a(h,u)
if(x>=0&&b<m)p=x,m=b
else{c[0]=g(t,n,r,w),c[1]=g(e,i,o,w)
var S=a(c,u)
w<=1&&S<m?(p=w,m=S):v*=.5}}return d&&(d[0]=g(t,n,r,p),d[1]=g(e,i,o,p)),s(m)}},function(t,e,n){var i=n(207),r=n(215),a=n(214).parsePercent,o=n(216),s=i.each,l=["left","right","top","bottom","width","height"],u=[["width","left","right"],["height","top","bottom"]]
function h(t,e,n,i,r){var a=0,o=0
null==i&&(i=1/0),null==r&&(r=1/0)
var s=0
e.eachChild((function(l,u){var h,c,f=l.position,d=l.getBoundingRect(),p=e.childAt(u+1),g=p&&p.getBoundingRect()
if("horizontal"===t){var v=d.width+(g?-g.x+d.x:0);(h=a+v)>i||l.newline?(a=0,h=v,o+=s+n,s=d.height):s=Math.max(s,d.height)}else{var m=d.height+(g?-g.y+d.y:0);(c=o+m)>r||l.newline?(a+=s+n,o=0,c=m,s=d.width):s=Math.max(s,d.width)}l.newline||(f[0]=a,f[1]=o,"horizontal"===t?a=h+n:o=c+n)}))}var c=h,f=i.curry(h,"vertical"),d=i.curry(h,"horizontal")
function p(t,e,n){n=o.normalizeCssArray(n||0)
var i=e.width,s=e.height,l=a(t.left,i),u=a(t.top,s),h=a(t.right,i),c=a(t.bottom,s),f=a(t.width,i),d=a(t.height,s),p=n[2]+n[0],g=n[1]+n[3],v=t.aspect
switch(isNaN(f)&&(f=i-h-g-l),isNaN(d)&&(d=s-c-p-u),null!=v&&(isNaN(f)&&isNaN(d)&&(v>i/s?f=.8*i:d=.8*s),isNaN(f)&&(f=v*d),isNaN(d)&&(d=f/v)),isNaN(l)&&(l=i-h-f-g),isNaN(u)&&(u=s-c-d-p),t.left||t.right){case"center":l=i/2-f/2-n[3]
break
case"right":l=i-f-g}switch(t.top||t.bottom){case"middle":case"center":u=s/2-d/2-n[0]
break
case"bottom":u=s-d-p}l=l||0,u=u||0,isNaN(f)&&(f=i-g-l-(h||0)),isNaN(d)&&(d=s-p-u-(c||0))
var m=new r(l+n[3],u+n[0],f,d)
return m.margin=n,m}function g(t,e){return e&&t&&s(l,(function(n){e.hasOwnProperty(n)&&(t[n]=e[n])})),t}e.LOCATION_PARAMS=l,e.HV_NAMES=u,e.box=c,e.vbox=f,e.hbox=d,e.getAvailableSize=function(t,e,n){var i=e.width,r=e.height,s=a(t.x,i),l=a(t.y,r),u=a(t.x2,i),h=a(t.y2,r)
return(isNaN(s)||isNaN(parseFloat(t.x)))&&(s=0),(isNaN(u)||isNaN(parseFloat(t.x2)))&&(u=i),(isNaN(l)||isNaN(parseFloat(t.y)))&&(l=0),(isNaN(h)||isNaN(parseFloat(t.y2)))&&(h=r),n=o.normalizeCssArray(n||0),{width:Math.max(u-s-n[1]-n[3],0),height:Math.max(h-l-n[0]-n[2],0)}},e.getLayoutRect=p,e.positionElement=function(t,e,n,a,o){var s=!o||!o.hv||o.hv[0],l=!o||!o.hv||o.hv[1],u=o&&o.boundingMode||"all"
if(s||l){var h
if("raw"===u)h="group"===t.type?new r(0,0,+e.width||0,+e.height||0):t.getBoundingRect()
else if(h=t.getBoundingRect(),t.needLocalTransform()){var c=t.getLocalTransform();(h=h.clone()).applyTransform(c)}e=p(i.defaults({width:h.width,height:h.height},e),n,a)
var f=t.position,d=s?e.x-h.x:0,g=l?e.y-h.y:0
t.attr("position","raw"===u?[d,g]:[f[0]+d,f[1]+g])}},e.sizeCalculable=function(t,e){return null!=t[u[e][0]]||null!=t[u[e][1]]&&null!=t[u[e][2]]},e.mergeLayoutParam=function(t,e,n){!i.isObject(n)&&(n={})
var r=n.ignoreSize
!i.isArray(r)&&(r=[r,r])
var a=l(u[0],0),o=l(u[1],1)
function l(n,i){var a={},o=0,l={},u=0
if(s(n,(function(e){l[e]=t[e]})),s(n,(function(t){h(e,t)&&(a[t]=l[t]=e[t]),c(a,t)&&o++,c(l,t)&&u++})),r[i])return c(e,n[1])?l[n[2]]=null:c(e,n[2])&&(l[n[1]]=null),l
if(2!==u&&o){if(o>=2)return a
for(var f=0;f<n.length;f++){var d=n[f]
if(!h(a,d)&&h(t,d)){a[d]=t[d]
break}}return a}return l}function h(t,e){return t.hasOwnProperty(e)}function c(t,e){return null!=t[e]&&"auto"!==t[e]}function f(t,e,n){s(t,(function(t){e[t]=n[t]}))}f(u[0],t,a),f(u[1],t,o)},e.getLayoutParams=function(t){return g({},t)},e.copyLayoutParams=g},function(t,e,n){var i=n(207),r=i.each,a=i.isString
function o(t,e){return!!e&&e===t.getCalculationInfo("stackedDimension")}e.enableDataStack=function(t,e,n){var i,o,s,l,u=(n=n||{}).byIndex,h=n.stackedCoordDimension,c=!(!t||!t.get("stack"))
if(r(e,(function(t,n){a(t)&&(e[n]=t={name:t}),c&&!t.isExtraCoord&&(u||i||!t.ordinalMeta||(i=t),o||"ordinal"===t.type||"time"===t.type||h&&h!==t.coordDim||(o=t))})),!o||u||i||(u=!0),o){s="__\0ecstackresult",l="__\0ecstackedover",i&&(i.createInvertedIndices=!0)
var f=o.coordDim,d=o.type,p=0
r(e,(function(t){t.coordDim===f&&p++})),e.push({name:s,coordDim:f,coordDimIndex:p,type:d,isExtraCoord:!0,isCalculationCoord:!0}),p++,e.push({name:l,coordDim:l,coordDimIndex:p,type:d,isExtraCoord:!0,isCalculationCoord:!0})}return{stackedDimension:o&&o.name,stackedByDimension:i&&i.name,isStackedByIndex:u,stackedOverDimension:l,stackResultDimension:s}},e.isDimensionStacked=o,e.getStackedDimension=function(t,e){return o(t,e)?t.getCalculationInfo("stackResultDimension"):e}},function(t,e,n){n(210).__DEV__
var i=n(207),r=n(359),a=n(255),o=n(239),s=n(214),l=n(360),u=l.prepareLayoutBarSeries,h=l.makeColumnLayout,c=l.retrieveColumnLayout,f=n(215)
function d(t,e){var n,r,a,o=t.type,l=e.getMin(),f=e.getMax(),d=t.getExtent()
"ordinal"===o?n=e.getCategories().length:(r=e.get("boundaryGap"),i.isArray(r)||(r=[r||0,r||0]),"boolean"==typeof r[0]&&(r=[0,0]),r[0]=s.parsePercent(r[0],1),r[1]=s.parsePercent(r[1],1),a=d[1]-d[0]||Math.abs(d[0])),"dataMin"===l?l=d[0]:"function"==typeof l&&(l=l({min:d[0],max:d[1]})),"dataMax"===f?f=d[1]:"function"==typeof f&&(f=f({min:d[0],max:d[1]}))
var p=null!=l,g=null!=f
null==l&&(l="ordinal"===o?n?0:NaN:d[0]-r[0]*a),null==f&&(f="ordinal"===o?n?n-1:NaN:d[1]+r[1]*a),(null==l||!isFinite(l))&&(l=NaN),(null==f||!isFinite(f))&&(f=NaN),t.setBlank(i.eqNaN(l)||i.eqNaN(f)||"ordinal"===o&&!t.getOrdinalMeta().categories.length),e.getNeedCrossZero()&&(l>0&&f>0&&!p&&(l=0),l<0&&f<0&&!g&&(f=0))
var v=e.ecModel
if(v&&"time"===o){var m,_=u("bar",v)
if(i.each(_,(function(t){m|=t.getBaseAxis()===e.axis})),m){var y=h(_),x=function(t,e,n,r){var a=n.axis.getExtent(),o=a[1]-a[0],s=c(r,n.axis)
if(void 0===s)return{min:t,max:e}
var l=1/0
i.each(s,(function(t){l=Math.min(t.offset,l)}))
var u=-1/0
i.each(s,(function(t){u=Math.max(t.offset+t.width,u)})),l=Math.abs(l),u=Math.abs(u)
var h=l+u,f=e-t,d=f/(1-(l+u)/o)-f
return{min:t-=d*(l/h),max:e+=d*(u/h)}}(l,f,e,y)
l=x.min,f=x.max}}return{extent:[l,f],fixMin:p,fixMax:g}}function p(t){var e,n=t.getLabelModel().get("formatter"),i="category"===t.type?t.scale.getExtent()[0]:null
return"string"==typeof n?(e=n,n=function(n){return n=t.scale.getLabel(n),e.replace("{value}",null!=n?n:"")}):"function"==typeof n?function(e,r){return null!=i&&(r=e-i),n(g(t,e),r)}:function(e){return t.scale.getLabel(e)}}function g(t,e){return"category"===t.type?t.scale.getLabel(e):e}function v(t){var e=t.get("interval")
return null==e?"auto":e}n(361),n(362),e.getScaleExtent=d,e.niceScaleExtent=function(t,e){var n=d(t,e),i=n.extent,r=e.get("splitNumber")
"log"===t.type&&(t.base=e.get("logBase"))
var a=t.type
t.setExtent(i[0],i[1]),t.niceExtent({splitNumber:r,fixMin:n.fixMin,fixMax:n.fixMax,minInterval:"interval"===a||"time"===a?e.get("minInterval"):null,maxInterval:"interval"===a||"time"===a?e.get("maxInterval"):null})
var o=e.get("interval")
null!=o&&t.setInterval&&t.setInterval(o)},e.createScaleByModel=function(t,e){if(e=e||t.get("type"))switch(e){case"category":return new r(t.getOrdinalMeta?t.getOrdinalMeta():t.getCategories(),[1/0,-1/0])
case"value":return new a
default:return(o.getClass(e)||a).create(t)}},e.ifAxisCrossZero=function(t){var e=t.scale.getExtent(),n=e[0],i=e[1]
return!(n>0&&i>0||n<0&&i<0)},e.makeLabelFormatter=p,e.getAxisRawValue=g,e.estimateLabelUnionRect=function(t){var e=t.model,n=t.scale
if(e.get("axisLabel.show")&&!n.isBlank()){var i,r,a="category"===t.type,o=n.getExtent()
r=a?n.count():(i=n.getTicks()).length
var s,l,u,h,c,d,g,v,m=t.getLabelModel(),_=p(t),y=1
r>40&&(y=Math.ceil(r/40))
for(var x=0;x<r;x+=y){var w=_(i?i[x]:o[0]+x),b=(l=m.getTextRect(w),void 0,void 0,void 0,void 0,void 0,void 0,u=(m.get("rotate")||0)*Math.PI/180,c=(h=l.plain()).width,d=h.height,g=c*Math.abs(Math.cos(u))+Math.abs(d*Math.sin(u)),v=c*Math.abs(Math.sin(u))+Math.abs(d*Math.cos(u)),new f(h.x,h.y,g,v))
s?s.union(b):s=b}return s}},e.getOptionCategoryInterval=v,e.shouldShowAllLabels=function(t){return"category"===t.type&&0===v(t.getLabelModel())}},function(t,e){var n=Array.prototype.slice,i=function(t){this._$handlers={},this._$eventProcessor=t}
function r(t,e,n,i,r,a){var o=t._$handlers
if("function"==typeof n&&(r=i,i=n,n=null),!i||!e)return t
n=function(t,e){var n=t._$eventProcessor
return null!=e&&n&&n.normalizeQuery&&(e=n.normalizeQuery(e)),e}(t,n),o[e]||(o[e]=[])
for(var s=0;s<o[e].length;s++)if(o[e][s].h===i)return t
var l={h:i,one:a,query:n,ctx:r||t,callAtLast:i.zrEventfulCallAtLast},u=o[e].length-1,h=o[e][u]
return h&&h.callAtLast?o[e].splice(u,0,l):o[e].push(l),t}i.prototype={constructor:i,one:function(t,e,n,i){return r(this,t,e,n,i,!0)},on:function(t,e,n,i){return r(this,t,e,n,i,!1)},isSilent:function(t){var e=this._$handlers
return!e[t]||!e[t].length},off:function(t,e){var n=this._$handlers
if(!t)return this._$handlers={},this
if(e){if(n[t]){for(var i=[],r=0,a=n[t].length;r<a;r++)n[t][r].h!==e&&i.push(n[t][r])
n[t]=i}n[t]&&0===n[t].length&&delete n[t]}else delete n[t]
return this},trigger:function(t){var e=this._$handlers[t],i=this._$eventProcessor
if(e){var r=arguments,a=r.length
a>3&&(r=n.call(r,1))
for(var o=e.length,s=0;s<o;){var l=e[s]
if(i&&i.filter&&null!=l.query&&!i.filter(t,l.query))s++
else{switch(a){case 1:l.h.call(l.ctx)
break
case 2:l.h.call(l.ctx,r[1])
break
case 3:l.h.call(l.ctx,r[1],r[2])
break
default:l.h.apply(l.ctx,r)}l.one?(e.splice(s,1),o--):s++}}}return i&&i.afterTrigger&&i.afterTrigger(t),this},triggerWithContext:function(t){var e=this._$handlers[t],i=this._$eventProcessor
if(e){var r=arguments,a=r.length
a>4&&(r=n.call(r,1,r.length-1))
for(var o=r[r.length-1],s=e.length,l=0;l<s;){var u=e[l]
if(i&&i.filter&&null!=u.query&&!i.filter(t,u.query))l++
else{switch(a){case 1:u.h.call(o)
break
case 2:u.h.call(o,r[1])
break
case 3:u.h.call(o,r[1],r[2])
break
default:u.h.apply(o,r)}u.one?(e.splice(l,1),s--):l++}}}return i&&i.afterTrigger&&i.afterTrigger(t),this}}
var a=i
t.exports=a},function(t,e,n){var i=n(207),r=n(260),a=n(215),o=function(t){for(var e in t=t||{},r.call(this,t),t)t.hasOwnProperty(e)&&(this[e]=t[e])
this._children=[],this.__storage=null,this.__dirty=!0}
o.prototype={constructor:o,isGroup:!0,type:"group",silent:!1,children:function(){return this._children.slice()},childAt:function(t){return this._children[t]},childOfName:function(t){for(var e=this._children,n=0;n<e.length;n++)if(e[n].name===t)return e[n]},childCount:function(){return this._children.length},add:function(t){return t&&t!==this&&t.parent!==this&&(this._children.push(t),this._doAdd(t)),this},addBefore:function(t,e){if(t&&t!==this&&t.parent!==this&&e&&e.parent===this){var n=this._children,i=n.indexOf(e)
i>=0&&(n.splice(i,0,t),this._doAdd(t))}return this},_doAdd:function(t){t.parent&&t.parent.remove(t),t.parent=this
var e=this.__storage,n=this.__zr
e&&e!==t.__storage&&(e.addToStorage(t),t instanceof o&&t.addChildrenToStorage(e)),n&&n.refresh()},remove:function(t){var e=this.__zr,n=this.__storage,r=this._children,a=i.indexOf(r,t)
return a<0||(r.splice(a,1),t.parent=null,n&&(n.delFromStorage(t),t instanceof o&&t.delChildrenFromStorage(n)),e&&e.refresh()),this},removeAll:function(){var t,e,n=this._children,i=this.__storage
for(e=0;e<n.length;e++)t=n[e],i&&(i.delFromStorage(t),t instanceof o&&t.delChildrenFromStorage(i)),t.parent=null
return n.length=0,this},eachChild:function(t,e){for(var n=this._children,i=0;i<n.length;i++){var r=n[i]
t.call(e,r,i)}return this},traverse:function(t,e){for(var n=0;n<this._children.length;n++){var i=this._children[n]
t.call(e,i),"group"===i.type&&i.traverse(t,e)}return this},addChildrenToStorage:function(t){for(var e=0;e<this._children.length;e++){var n=this._children[e]
t.addToStorage(n),n instanceof o&&n.addChildrenToStorage(t)}},delChildrenFromStorage:function(t){for(var e=0;e<this._children.length;e++){var n=this._children[e]
t.delFromStorage(n),n instanceof o&&n.delChildrenFromStorage(t)}},dirty:function(){return this.__dirty=!0,this.__zr&&this.__zr.refresh(),this},getBoundingRect:function(t){for(var e=null,n=new a(0,0,0,0),i=t||this._children,r=[],o=0;o<i.length;o++){var s=i[o]
if(!s.ignore&&!s.invisible){var l=s.getBoundingRect(),u=s.getLocalTransform(r)
u?(n.copy(l),n.applyTransform(u),(e=e||n.clone()).union(n)):(e=e||l.clone()).union(l)}}return e||n}},i.inherits(o,r)
var s=o
t.exports=s},function(t,e,n){var i=n(263),r={transparent:[0,0,0,0],aliceblue:[240,248,255,1],antiquewhite:[250,235,215,1],aqua:[0,255,255,1],aquamarine:[127,255,212,1],azure:[240,255,255,1],beige:[245,245,220,1],bisque:[255,228,196,1],black:[0,0,0,1],blanchedalmond:[255,235,205,1],blue:[0,0,255,1],blueviolet:[138,43,226,1],brown:[165,42,42,1],burlywood:[222,184,135,1],cadetblue:[95,158,160,1],chartreuse:[127,255,0,1],chocolate:[210,105,30,1],coral:[255,127,80,1],cornflowerblue:[100,149,237,1],cornsilk:[255,248,220,1],crimson:[220,20,60,1],cyan:[0,255,255,1],darkblue:[0,0,139,1],darkcyan:[0,139,139,1],darkgoldenrod:[184,134,11,1],darkgray:[169,169,169,1],darkgreen:[0,100,0,1],darkgrey:[169,169,169,1],darkkhaki:[189,183,107,1],darkmagenta:[139,0,139,1],darkolivegreen:[85,107,47,1],darkorange:[255,140,0,1],darkorchid:[153,50,204,1],darkred:[139,0,0,1],darksalmon:[233,150,122,1],darkseagreen:[143,188,143,1],darkslateblue:[72,61,139,1],darkslategray:[47,79,79,1],darkslategrey:[47,79,79,1],darkturquoise:[0,206,209,1],darkviolet:[148,0,211,1],deeppink:[255,20,147,1],deepskyblue:[0,191,255,1],dimgray:[105,105,105,1],dimgrey:[105,105,105,1],dodgerblue:[30,144,255,1],firebrick:[178,34,34,1],floralwhite:[255,250,240,1],forestgreen:[34,139,34,1],fuchsia:[255,0,255,1],gainsboro:[220,220,220,1],ghostwhite:[248,248,255,1],gold:[255,215,0,1],goldenrod:[218,165,32,1],gray:[128,128,128,1],green:[0,128,0,1],greenyellow:[173,255,47,1],grey:[128,128,128,1],honeydew:[240,255,240,1],hotpink:[255,105,180,1],indianred:[205,92,92,1],indigo:[75,0,130,1],ivory:[255,255,240,1],khaki:[240,230,140,1],lavender:[230,230,250,1],lavenderblush:[255,240,245,1],lawngreen:[124,252,0,1],lemonchiffon:[255,250,205,1],lightblue:[173,216,230,1],lightcoral:[240,128,128,1],lightcyan:[224,255,255,1],lightgoldenrodyellow:[250,250,210,1],lightgray:[211,211,211,1],lightgreen:[144,238,144,1],lightgrey:[211,211,211,1],lightpink:[255,182,193,1],lightsalmon:[255,160,122,1],lightseagreen:[32,178,170,1],lightskyblue:[135,206,250,1],lightslategray:[119,136,153,1],lightslategrey:[119,136,153,1],lightsteelblue:[176,196,222,1],lightyellow:[255,255,224,1],lime:[0,255,0,1],limegreen:[50,205,50,1],linen:[250,240,230,1],magenta:[255,0,255,1],maroon:[128,0,0,1],mediumaquamarine:[102,205,170,1],mediumblue:[0,0,205,1],mediumorchid:[186,85,211,1],mediumpurple:[147,112,219,1],mediumseagreen:[60,179,113,1],mediumslateblue:[123,104,238,1],mediumspringgreen:[0,250,154,1],mediumturquoise:[72,209,204,1],mediumvioletred:[199,21,133,1],midnightblue:[25,25,112,1],mintcream:[245,255,250,1],mistyrose:[255,228,225,1],moccasin:[255,228,181,1],navajowhite:[255,222,173,1],navy:[0,0,128,1],oldlace:[253,245,230,1],olive:[128,128,0,1],olivedrab:[107,142,35,1],orange:[255,165,0,1],orangered:[255,69,0,1],orchid:[218,112,214,1],palegoldenrod:[238,232,170,1],palegreen:[152,251,152,1],paleturquoise:[175,238,238,1],palevioletred:[219,112,147,1],papayawhip:[255,239,213,1],peachpuff:[255,218,185,1],peru:[205,133,63,1],pink:[255,192,203,1],plum:[221,160,221,1],powderblue:[176,224,230,1],purple:[128,0,128,1],red:[255,0,0,1],rosybrown:[188,143,143,1],royalblue:[65,105,225,1],saddlebrown:[139,69,19,1],salmon:[250,128,114,1],sandybrown:[244,164,96,1],seagreen:[46,139,87,1],seashell:[255,245,238,1],sienna:[160,82,45,1],silver:[192,192,192,1],skyblue:[135,206,235,1],slateblue:[106,90,205,1],slategray:[112,128,144,1],slategrey:[112,128,144,1],snow:[255,250,250,1],springgreen:[0,255,127,1],steelblue:[70,130,180,1],tan:[210,180,140,1],teal:[0,128,128,1],thistle:[216,191,216,1],tomato:[255,99,71,1],turquoise:[64,224,208,1],violet:[238,130,238,1],wheat:[245,222,179,1],white:[255,255,255,1],whitesmoke:[245,245,245,1],yellow:[255,255,0,1],yellowgreen:[154,205,50,1]}
function a(t){return(t=Math.round(t))<0?0:t>255?255:t}function o(t){return t<0?0:t>1?1:t}function s(t){return t.length&&"%"===t.charAt(t.length-1)?a(parseFloat(t)/100*255):a(parseInt(t,10))}function l(t){return t.length&&"%"===t.charAt(t.length-1)?o(parseFloat(t)/100):o(parseFloat(t))}function u(t,e,n){return n<0?n+=1:n>1&&(n-=1),6*n<1?t+(e-t)*n*6:2*n<1?e:3*n<2?t+(e-t)*(2/3-n)*6:t}function h(t,e,n){return t+(e-t)*n}function c(t,e,n,i,r){return t[0]=e,t[1]=n,t[2]=i,t[3]=r,t}function f(t,e){return t[0]=e[0],t[1]=e[1],t[2]=e[2],t[3]=e[3],t}var d=new i(20),p=null
function g(t,e){p&&f(p,e),p=d.put(t,p||e.slice())}function v(t,e){if(t){e=e||[]
var n=d.get(t)
if(n)return f(e,n)
var i,a=(t+="").replace(/ /g,"").toLowerCase()
if(a in r)return f(e,r[a]),g(t,e),e
if("#"===a.charAt(0))return 4===a.length?(i=parseInt(a.substr(1),16))>=0&&i<=4095?(c(e,(3840&i)>>4|(3840&i)>>8,240&i|(240&i)>>4,15&i|(15&i)<<4,1),g(t,e),e):void c(e,0,0,0,1):7===a.length?(i=parseInt(a.substr(1),16))>=0&&i<=16777215?(c(e,(16711680&i)>>16,(65280&i)>>8,255&i,1),g(t,e),e):void c(e,0,0,0,1):void 0
var o=a.indexOf("("),u=a.indexOf(")")
if(-1!==o&&u+1===a.length){var h=a.substr(0,o),p=a.substr(o+1,u-(o+1)).split(","),v=1
switch(h){case"rgba":if(4!==p.length)return void c(e,0,0,0,1)
v=l(p.pop())
case"rgb":return 3!==p.length?void c(e,0,0,0,1):(c(e,s(p[0]),s(p[1]),s(p[2]),v),g(t,e),e)
case"hsla":return 4!==p.length?void c(e,0,0,0,1):(p[3]=l(p[3]),m(p,e),g(t,e),e)
case"hsl":return 3!==p.length?void c(e,0,0,0,1):(m(p,e),g(t,e),e)
default:return}}c(e,0,0,0,1)}}function m(t,e){var n=(parseFloat(t[0])%360+360)%360/360,i=l(t[1]),r=l(t[2]),o=r<=.5?r*(i+1):r+i-r*i,s=2*r-o
return c(e=e||[],a(255*u(s,o,n+1/3)),a(255*u(s,o,n)),a(255*u(s,o,n-1/3)),1),4===t.length&&(e[3]=t[3]),e}function _(t,e,n){if(e&&e.length&&t>=0&&t<=1){n=n||[]
var i=t*(e.length-1),r=Math.floor(i),s=Math.ceil(i),l=e[r],u=e[s],c=i-r
return n[0]=a(h(l[0],u[0],c)),n[1]=a(h(l[1],u[1],c)),n[2]=a(h(l[2],u[2],c)),n[3]=o(h(l[3],u[3],c)),n}}var y=_
function x(t,e,n){if(e&&e.length&&t>=0&&t<=1){var i=t*(e.length-1),r=Math.floor(i),s=Math.ceil(i),l=v(e[r]),u=v(e[s]),c=i-r,f=b([a(h(l[0],u[0],c)),a(h(l[1],u[1],c)),a(h(l[2],u[2],c)),o(h(l[3],u[3],c))],"rgba")
return n?{color:f,leftIndex:r,rightIndex:s,value:i}:f}}var w=x
function b(t,e){if(t&&t.length){var n=t[0]+","+t[1]+","+t[2]
return"rgba"!==e&&"hsva"!==e&&"hsla"!==e||(n+=","+t[3]),e+"("+n+")"}}e.parse=v,e.lift=function(t,e){var n=v(t)
if(n){for(var i=0;i<3;i++)n[i]=e<0?n[i]*(1-e)|0:(255-n[i])*e+n[i]|0,n[i]>255?n[i]=255:t[i]<0&&(n[i]=0)
return b(n,4===n.length?"rgba":"rgb")}},e.toHex=function(t){var e=v(t)
if(e)return((1<<24)+(e[0]<<16)+(e[1]<<8)+ +e[2]).toString(16).slice(1)},e.fastLerp=_,e.fastMapToColor=y,e.lerp=x,e.mapToColor=w,e.modifyHSL=function(t,e,n,i){if(t=v(t))return t=function(t){if(t){var e,n,i=t[0]/255,r=t[1]/255,a=t[2]/255,o=Math.min(i,r,a),s=Math.max(i,r,a),l=s-o,u=(s+o)/2
if(0===l)e=0,n=0
else{n=u<.5?l/(s+o):l/(2-s-o)
var h=((s-i)/6+l/2)/l,c=((s-r)/6+l/2)/l,f=((s-a)/6+l/2)/l
i===s?e=f-c:r===s?e=1/3+h-f:a===s&&(e=2/3+c-h),e<0&&(e+=1),e>1&&(e-=1)}var d=[360*e,n,u]
return null!=t[3]&&d.push(t[3]),d}}(t),null!=e&&(t[0]=(r=e,(r=Math.round(r))<0?0:r>360?360:r)),null!=n&&(t[1]=l(n)),null!=i&&(t[2]=l(i)),b(m(t),"rgba")
var r},e.modifyAlpha=function(t,e){if((t=v(t))&&null!=e)return t[3]=o(e),b(t,"rgba")},e.stringify=b},function(t,e,n){n(210).__DEV__
var i=n(208),r=i.makeInner,a=i.getDataItemValue,o=n(207),s=o.createHashMap,l=o.each,u=o.map,h=o.isArray,c=o.isString,f=o.isObject,d=o.isTypedArray,p=o.isArrayLike,g=o.extend,v=(o.assert,n(231)),m=n(232),_=m.SOURCE_FORMAT_ORIGINAL,y=m.SOURCE_FORMAT_ARRAY_ROWS,x=m.SOURCE_FORMAT_OBJECT_ROWS,w=m.SOURCE_FORMAT_KEYED_COLUMNS,b=m.SOURCE_FORMAT_UNKNOWN,S=m.SOURCE_FORMAT_TYPED_ARRAY,T=m.SERIES_LAYOUT_BY_ROW,M={Must:1,Might:2,Not:3},C=r()
function k(t){if(t){var e=s()
return u(t,(function(t,n){if(null==(t=g({},f(t)?t:{name:t})).name)return t
t.name+="",null==t.displayName&&(t.displayName=t.name)
var i=e.get(t.name)
return i?t.name+="-"+i.count++:e.set(t.name,{count:1}),t}))}}function D(t,e,n,i){if(null==i&&(i=1/0),e===T)for(var r=0;r<n.length&&r<i;r++)t(n[r]?n[r][0]:null,r)
else{var a=n[0]||[]
for(r=0;r<a.length&&r<i;r++)t(a[r],r)}}function I(t){var e=t.option
if(!e.data)return t.ecModel.getComponent("dataset",e.datasetIndex||0)}function A(t,e,n,i,r,o){var s,l,u
if(d(t))return M.Not
if(i){var p=i[o]
f(p)?(l=p.name,u=p.type):c(p)&&(l=p)}if(null!=u)return"ordinal"===u?M.Must:M.Not
if(e===y)if(n===T){for(var g=t[o],v=0;v<(g||[]).length&&v<5;v++)if(null!=(s=C(g[r+v])))return s}else for(v=0;v<t.length&&v<5;v++){var m=t[r+v]
if(m&&null!=(s=C(m[o])))return s}else if(e===x){if(!l)return M.Not
for(v=0;v<t.length&&v<5;v++)if((b=t[v])&&null!=(s=C(b[l])))return s}else if(e===w){if(!l)return M.Not
if(!(g=t[l])||d(g))return M.Not
for(v=0;v<g.length&&v<5;v++)if(null!=(s=C(g[v])))return s}else if(e===_)for(v=0;v<t.length&&v<5;v++){var b=t[v],S=a(b)
if(!h(S))return M.Not
if(null!=(s=C(S[o])))return s}function C(t){var e=c(t)
return null!=t&&isFinite(t)&&""!==t?e?M.Might:M.Not:e&&"-"!==t?M.Must:void 0}return M.Not}e.BE_ORDINAL=M,e.detectSourceFormat=function(t){var e=t.option.source,n=b
if(d(e))n=S
else if(h(e)){0===e.length&&(n=y)
for(var i=0,r=e.length;i<r;i++){var a=e[i]
if(null!=a){if(h(a)){n=y
break}if(f(a)){n=x
break}}}}else if(f(e)){for(var o in e)if(e.hasOwnProperty(o)&&p(e[o])){n=w
break}}else if(null!=e)throw new Error("Invalid data")
C(t).sourceFormat=n},e.getSource=function(t){return C(t).source},e.resetSourceDefaulter=function(t){C(t).datasetMap=s()},e.prepareSource=function(t){var e=t.option,n=e.data,i=d(n)?S:_,r=!1,o=e.seriesLayoutBy,s=e.sourceHeader,u=e.dimensions,f=I(t)
if(f){var p=f.option
n=p.source,i=C(f).sourceFormat,r=!0,o=o||p.seriesLayoutBy,null==s&&(s=p.sourceHeader),u=u||p.dimensions}var g=function(t,e,n,i,r){if(!t)return{dimensionsDefine:k(r)}
var o,s
if(e===y)"auto"===i||null==i?D((function(t){null!=t&&"-"!==t&&(c(t)?null==s&&(s=1):s=0)}),n,t,10):s=i?1:0,r||1!==s||(r=[],D((function(t,e){r[e]=null!=t?t:""}),n,t)),o=r?r.length:n===T?t.length:t[0]?t[0].length:null
else if(e===x)r||(r=function(t){for(var e,n=0;n<t.length&&!(e=t[n++]););if(e){var i=[]
return l(e,(function(t,e){i.push(e)})),i}}(t))
else if(e===w)r||(r=[],l(t,(function(t,e){r.push(e)})))
else if(e===_){var u=a(t[0])
o=h(u)&&u.length||1}return{startIndex:s,dimensionsDefine:k(r),dimensionsDetectCount:o}}(n,i,o,s,u)
C(t).source=new v({data:n,fromDataset:r,seriesLayoutBy:o,sourceFormat:i,dimensionsDefine:g.dimensionsDefine,startIndex:g.startIndex,dimensionsDetectCount:g.dimensionsDetectCount,encodeDefine:e.encode})},e.makeSeriesEncodeForAxisCoordSys=function(t,e,n){var i={},r=I(e)
if(!r||!t)return i
var a,o,s=[],u=[],h=e.ecModel,c=C(h).datasetMap,d=r.uid+"_"+n.seriesLayoutBy
t=t.slice(),l(t,(function(e,n){!f(e)&&(t[n]={name:e}),"ordinal"===e.type&&null==a&&(a=n,o=v(t[n])),i[e.name]=[]}))
var p=c.get(d)||c.set(d,{categoryWayDim:o,valueWayDim:0})
function g(t,e,n){for(var i=0;i<n;i++)t.push(e+i)}function v(t){var e=t.dimsDef
return e?e.length:1}return l(t,(function(t,e){var n=t.name,r=v(t)
if(null==a){var o=p.valueWayDim
g(i[n],o,r),g(u,o,r),p.valueWayDim+=r}else a===e?(g(i[n],0,r),g(s,0,r)):(o=p.categoryWayDim,g(i[n],o,r),g(u,o,r),p.categoryWayDim+=r)})),s.length&&(i.itemName=s),u.length&&(i.seriesName=u),i},e.makeSeriesEncodeForNameBased=function(t,e,n){var i={}
if(!I(t))return i
var r,a=e.sourceFormat,o=e.dimensionsDefine
a!==x&&a!==w||l(o,(function(t,e){"name"===(f(t)?t.name:t)&&(r=e)}))
var s=function(){for(var t={},i={},s=[],l=0,u=Math.min(5,n);l<u;l++){var h=A(e.data,a,e.seriesLayoutBy,o,e.startIndex,l)
s.push(h)
var c=h===M.Not
if(c&&null==t.v&&l!==r&&(t.v=l),(null==t.n||t.n===t.v||!c&&s[t.n]===M.Not)&&(t.n=l),f(t)&&s[t.n]!==M.Not)return t
c||(h===M.Might&&null==i.v&&l!==r&&(i.v=l),null!=i.n&&i.n!==i.v||(i.n=l))}function f(t){return null!=t.v&&null!=t.n}return f(t)?t:f(i)?i:null}()
if(s){i.value=s.v
var u=null!=r?r:s.n
i.itemName=[u],i.seriesName=[u]}return i},e.guessOrdinal=function(t,e){return A(t.data,t.sourceFormat,t.seriesLayoutBy,t.dimensionsDefine,t.startIndex,e)}},function(t,e,n){var i=n(207),r=i.createHashMap,a=i.isTypedArray,o=n(219).enableClassCheck,s=n(232),l=s.SOURCE_FORMAT_ORIGINAL,u=s.SERIES_LAYOUT_BY_COLUMN,h=s.SOURCE_FORMAT_UNKNOWN,c=s.SOURCE_FORMAT_TYPED_ARRAY,f=s.SOURCE_FORMAT_KEYED_COLUMNS
function d(t){this.fromDataset=t.fromDataset,this.data=t.data||(t.sourceFormat===f?{}:[]),this.sourceFormat=t.sourceFormat||h,this.seriesLayoutBy=t.seriesLayoutBy||u,this.dimensionsDefine=t.dimensionsDefine,this.encodeDefine=t.encodeDefine&&r(t.encodeDefine),this.startIndex=t.startIndex||0,this.dimensionsDetectCount=t.dimensionsDetectCount}d.seriesDataToSource=function(t){return new d({data:t,sourceFormat:a(t)?c:l,fromDataset:!1})},o(d)
var p=d
t.exports=p},function(t,e){e.SOURCE_FORMAT_ORIGINAL="original",e.SOURCE_FORMAT_ARRAY_ROWS="arrayRows",e.SOURCE_FORMAT_OBJECT_ROWS="objectRows",e.SOURCE_FORMAT_KEYED_COLUMNS="keyedColumns",e.SOURCE_FORMAT_UNKNOWN="unknown",e.SOURCE_FORMAT_TYPED_ARRAY="typedArray",e.SERIES_LAYOUT_BY_COLUMN="column",e.SERIES_LAYOUT_BY_ROW="row"},function(t,e,n){n(210).__DEV__
var i=n(207),r=(i.isTypedArray,i.extend),a=(i.assert,i.each),o=i.isObject,s=n(208),l=s.getDataItemValue,u=s.isDataItemOption,h=n(214).parseDate,c=n(231),f=n(232),d=f.SOURCE_FORMAT_TYPED_ARRAY,p=f.SOURCE_FORMAT_ARRAY_ROWS,g=f.SOURCE_FORMAT_ORIGINAL,v=f.SOURCE_FORMAT_OBJECT_ROWS
function m(t,e){c.isInstance(t)||(t=c.seriesDataToSource(t)),this._source=t
var n=this._data=t.data,i=t.sourceFormat
i===d&&(this._offset=0,this._dimSize=e,this._data=n)
var a=y[i===p?i+"_"+t.seriesLayoutBy:i]
r(this,a)}var _=m.prototype
_.pure=!1,_.persistent=!0,_.getSource=function(){return this._source}
var y={arrayRows_column:{pure:!0,count:function(){return Math.max(0,this._data.length-this._source.startIndex)},getItem:function(t){return this._data[t+this._source.startIndex]},appendData:b},arrayRows_row:{pure:!0,count:function(){var t=this._data[0]
return t?Math.max(0,t.length-this._source.startIndex):0},getItem:function(t){t+=this._source.startIndex
for(var e=[],n=this._data,i=0;i<n.length;i++){var r=n[i]
e.push(r?r[t]:null)}return e},appendData:function(){throw new Error('Do not support appendData when set seriesLayoutBy: "row".')}},objectRows:{pure:!0,count:x,getItem:w,appendData:b},keyedColumns:{pure:!0,count:function(){var t=this._source.dimensionsDefine[0].name,e=this._data[t]
return e?e.length:0},getItem:function(t){for(var e=[],n=this._source.dimensionsDefine,i=0;i<n.length;i++){var r=this._data[n[i].name]
e.push(r?r[t]:null)}return e},appendData:function(t){var e=this._data
a(t,(function(t,n){for(var i=e[n]||(e[n]=[]),r=0;r<(t||[]).length;r++)i.push(t[r])}))}},original:{count:x,getItem:w,appendData:b},typedArray:{persistent:!1,pure:!0,count:function(){return this._data?this._data.length/this._dimSize:0},getItem:function(t,e){t-=this._offset,e=e||[]
for(var n=this._dimSize*t,i=0;i<this._dimSize;i++)e[i]=this._data[n+i]
return e},appendData:function(t){this._data=t},clean:function(){this._offset+=this.count(),this._data=null}}}
function x(){return this._data.length}function w(t){return this._data[t]}function b(t){for(var e=0;e<t.length;e++)this._data.push(t[e])}var S={arrayRows:T,objectRows:function(t,e,n,i){return null!=n?t[i]:t},keyedColumns:T,original:function(t,e,n,i){var r=l(t)
return null!=n&&r instanceof Array?r[n]:r},typedArray:T}
function T(t,e,n,i){return null!=n?t[n]:t}var M={arrayRows:C,objectRows:function(t,e,n,i){return k(t[e],this._dimensionInfos[e])},keyedColumns:C,original:function(t,e,n,i){var r=t&&(null==t.value?t:t.value)
return!this._rawData.pure&&u(t)&&(this.hasItemOption=!0),k(r instanceof Array?r[i]:r,this._dimensionInfos[e])},typedArray:function(t,e,n,i){return t[i]}}
function C(t,e,n,i){return k(t[i],this._dimensionInfos[e])}function k(t,e){var n=e&&e.type
if("ordinal"===n){var i=e&&e.ordinalMeta
return i?i.parseAndCollect(t):t}return"time"===n&&"number"!=typeof t&&null!=t&&"-"!==t&&(t=+h(t)),null==t||""===t?NaN:+t}e.DefaultDataProvider=m,e.defaultDimValueGetters=M,e.retrieveRawValue=function(t,e,n){if(t){var i=t.getRawDataItem(e)
if(null!=i){var r,a,o=t.getProvider().getSource().sourceFormat,s=t.getDimensionInfo(n)
return s&&(r=s.name,a=s.index),S[o](i,e,a,r)}}},e.retrieveRawAttr=function(t,e,n){if(t){var i=t.getProvider().getSource().sourceFormat
if(i===g||i===v){var r=t.getRawDataItem(e)
return i!==g||o(r)||(r=null),r?r[n]:void 0}}}},function(t,e){var n=1
"undefined"!=typeof window&&(n=Math.max(window.devicePixelRatio||1,1))
var i=n
e.debugMode=0,e.devicePixelRatio=i},function(t,e){e.ContextCachedBy={NONE:0,STYLE_BIND:1,PLAIN_TEXT:2},e.WILL_BE_RESTORED=9},function(t,e,n){var i=n(207),r=n(242),a=n(260),o=n(315)
function s(t){for(var e in t=t||{},a.call(this,t),t)t.hasOwnProperty(e)&&"style"!==e&&(this[e]=t[e])
this.style=new r(t.style,this),this._rect=null,this.__clipPaths=null}s.prototype={constructor:s,type:"displayable",__dirty:!0,invisible:!1,z:0,z2:0,zlevel:0,draggable:!1,dragging:!1,silent:!1,culling:!1,cursor:"pointer",rectHover:!1,progressive:!1,incremental:!1,globalScaleRatio:1,beforeBrush:function(t){},afterBrush:function(t){},brush:function(t,e){},getBoundingRect:function(){},contain:function(t,e){return this.rectContain(t,e)},traverse:function(t,e){t.call(e,this)},rectContain:function(t,e){var n=this.transformCoordToLocal(t,e)
return this.getBoundingRect().contain(n[0],n[1])},dirty:function(){this.__dirty=this.__dirtyText=!0,this._rect=null,this.__zr&&this.__zr.refresh()},animateStyle:function(t){return this.animate("style",t)},attrKV:function(t,e){"style"!==t?a.prototype.attrKV.call(this,t,e):this.style.set(e)},setStyle:function(t,e){return this.style.set(t,e),this.dirty(!1),this},useStyle:function(t){return this.style=new r(t,this),this.dirty(!1),this},calculateTextPosition:null},i.inherits(s,a),i.mixin(s,o)
var l=s
t.exports=l},function(t,e,n){var i=n(223),r=n(212),a=n(246),o=n(215),s=n(234).devicePixelRatio,l={M:1,L:2,C:3,Q:4,A:5,Z:6,R:7},u=[],h=[],c=[],f=[],d=Math.min,p=Math.max,g=Math.cos,v=Math.sin,m=Math.sqrt,_=Math.abs,y="undefined"!=typeof Float32Array,x=function(t){this._saveData=!t,this._saveData&&(this.data=[]),this._ctx=null}
x.prototype={constructor:x,_xi:0,_yi:0,_x0:0,_y0:0,_ux:0,_uy:0,_len:0,_lineDash:null,_dashOffset:0,_dashIdx:0,_dashSum:0,setScale:function(t,e,n){n=n||0,this._ux=_(n/s/t)||0,this._uy=_(n/s/e)||0},getContext:function(){return this._ctx},beginPath:function(t){return this._ctx=t,t&&t.beginPath(),t&&(this.dpr=t.dpr),this._saveData&&(this._len=0),this._lineDash&&(this._lineDash=null,this._dashOffset=0),this},moveTo:function(t,e){return this.addData(l.M,t,e),this._ctx&&this._ctx.moveTo(t,e),this._x0=t,this._y0=e,this._xi=t,this._yi=e,this},lineTo:function(t,e){var n=_(t-this._xi)>this._ux||_(e-this._yi)>this._uy||this._len<5
return this.addData(l.L,t,e),this._ctx&&n&&(this._needsDash()?this._dashedLineTo(t,e):this._ctx.lineTo(t,e)),n&&(this._xi=t,this._yi=e),this},bezierCurveTo:function(t,e,n,i,r,a){return this.addData(l.C,t,e,n,i,r,a),this._ctx&&(this._needsDash()?this._dashedBezierTo(t,e,n,i,r,a):this._ctx.bezierCurveTo(t,e,n,i,r,a)),this._xi=r,this._yi=a,this},quadraticCurveTo:function(t,e,n,i){return this.addData(l.Q,t,e,n,i),this._ctx&&(this._needsDash()?this._dashedQuadraticTo(t,e,n,i):this._ctx.quadraticCurveTo(t,e,n,i)),this._xi=n,this._yi=i,this},arc:function(t,e,n,i,r,a){return this.addData(l.A,t,e,n,n,i,r-i,0,a?0:1),this._ctx&&this._ctx.arc(t,e,n,i,r,a),this._xi=g(r)*n+t,this._yi=v(r)*n+e,this},arcTo:function(t,e,n,i,r){return this._ctx&&this._ctx.arcTo(t,e,n,i,r),this},rect:function(t,e,n,i){return this._ctx&&this._ctx.rect(t,e,n,i),this.addData(l.R,t,e,n,i),this},closePath:function(){this.addData(l.Z)
var t=this._ctx,e=this._x0,n=this._y0
return t&&(this._needsDash()&&this._dashedLineTo(e,n),t.closePath()),this._xi=e,this._yi=n,this},fill:function(t){t&&t.fill(),this.toStatic()},stroke:function(t){t&&t.stroke(),this.toStatic()},setLineDash:function(t){if(t instanceof Array){this._lineDash=t,this._dashIdx=0
for(var e=0,n=0;n<t.length;n++)e+=t[n]
this._dashSum=e}return this},setLineDashOffset:function(t){return this._dashOffset=t,this},len:function(){return this._len},setData:function(t){var e=t.length
this.data&&this.data.length===e||!y||(this.data=new Float32Array(e))
for(var n=0;n<e;n++)this.data[n]=t[n]
this._len=e},appendPath:function(t){t instanceof Array||(t=[t])
for(var e=t.length,n=0,i=this._len,r=0;r<e;r++)n+=t[r].len()
for(y&&this.data instanceof Float32Array&&(this.data=new Float32Array(i+n)),r=0;r<e;r++)for(var a=t[r].data,o=0;o<a.length;o++)this.data[i++]=a[o]
this._len=i},addData:function(t){if(this._saveData){var e=this.data
this._len+arguments.length>e.length&&(this._expandData(),e=this.data)
for(var n=0;n<arguments.length;n++)e[this._len++]=arguments[n]
this._prevCmd=t}},_expandData:function(){if(!(this.data instanceof Array)){for(var t=[],e=0;e<this._len;e++)t[e]=this.data[e]
this.data=t}},_needsDash:function(){return this._lineDash},_dashedLineTo:function(t,e){var n,i,r=this._dashSum,a=this._dashOffset,o=this._lineDash,s=this._ctx,l=this._xi,u=this._yi,h=t-l,c=e-u,f=m(h*h+c*c),g=l,v=u,_=o.length
for(a<0&&(a=r+a),g-=(a%=r)*(h/=f),v-=a*(c/=f);h>0&&g<=t||h<0&&g>=t||0===h&&(c>0&&v<=e||c<0&&v>=e);)g+=h*(n=o[i=this._dashIdx]),v+=c*n,this._dashIdx=(i+1)%_,h>0&&g<l||h<0&&g>l||c>0&&v<u||c<0&&v>u||s[i%2?"moveTo":"lineTo"](h>=0?d(g,t):p(g,t),c>=0?d(v,e):p(v,e))
h=g-t,c=v-e,this._dashOffset=-m(h*h+c*c)},_dashedBezierTo:function(t,e,n,r,a,o){var s,l,u,h,c,f=this._dashSum,d=this._dashOffset,p=this._lineDash,g=this._ctx,v=this._xi,_=this._yi,y=i.cubicAt,x=0,w=this._dashIdx,b=p.length,S=0
for(d<0&&(d=f+d),d%=f,s=0;s<1;s+=.1)l=y(v,t,n,a,s+.1)-y(v,t,n,a,s),u=y(_,e,r,o,s+.1)-y(_,e,r,o,s),x+=m(l*l+u*u)
for(;w<b&&!((S+=p[w])>d);w++);for(s=(S-d)/x;s<=1;)h=y(v,t,n,a,s),c=y(_,e,r,o,s),w%2?g.moveTo(h,c):g.lineTo(h,c),s+=p[w]/x,w=(w+1)%b
w%2!=0&&g.lineTo(a,o),l=a-h,u=o-c,this._dashOffset=-m(l*l+u*u)},_dashedQuadraticTo:function(t,e,n,i){var r=n,a=i
n=(n+2*t)/3,i=(i+2*e)/3,t=(this._xi+2*t)/3,e=(this._yi+2*e)/3,this._dashedBezierTo(t,e,n,i,r,a)},toStatic:function(){var t=this.data
t instanceof Array&&(t.length=this._len,y&&(this.data=new Float32Array(t)))},getBoundingRect:function(){u[0]=u[1]=c[0]=c[1]=Number.MAX_VALUE,h[0]=h[1]=f[0]=f[1]=-Number.MAX_VALUE
for(var t=this.data,e=0,n=0,i=0,s=0,d=0;d<t.length;){var p=t[d++]
switch(1===d&&(i=e=t[d],s=n=t[d+1]),p){case l.M:e=i=t[d++],n=s=t[d++],c[0]=i,c[1]=s,f[0]=i,f[1]=s
break
case l.L:a.fromLine(e,n,t[d],t[d+1],c,f),e=t[d++],n=t[d++]
break
case l.C:a.fromCubic(e,n,t[d++],t[d++],t[d++],t[d++],t[d],t[d+1],c,f),e=t[d++],n=t[d++]
break
case l.Q:a.fromQuadratic(e,n,t[d++],t[d++],t[d],t[d+1],c,f),e=t[d++],n=t[d++]
break
case l.A:var m=t[d++],_=t[d++],y=t[d++],x=t[d++],w=t[d++],b=t[d++]+w
d+=1
var S=1-t[d++]
1===d&&(i=g(w)*y+m,s=v(w)*x+_),a.fromArc(m,_,y,x,w,b,S,c,f),e=g(b)*y+m,n=v(b)*x+_
break
case l.R:i=e=t[d++],s=n=t[d++]
var T=t[d++],M=t[d++]
a.fromLine(i,s,i+T,s+M,c,f)
break
case l.Z:e=i,n=s}r.min(u,u,c),r.max(h,h,f)}return 0===d&&(u[0]=u[1]=h[0]=h[1]=0),new o(u[0],u[1],h[0]-u[0],h[1]-u[1])},rebuildPath:function(t){for(var e,n,i,r,a,o,s=this.data,u=this._ux,h=this._uy,c=this._len,f=0;f<c;){var d=s[f++]
switch(1===f&&(e=i=s[f],n=r=s[f+1]),d){case l.M:e=i=s[f++],n=r=s[f++],t.moveTo(i,r)
break
case l.L:a=s[f++],o=s[f++],(_(a-i)>u||_(o-r)>h||f===c-1)&&(t.lineTo(a,o),i=a,r=o)
break
case l.C:t.bezierCurveTo(s[f++],s[f++],s[f++],s[f++],s[f++],s[f++]),i=s[f-2],r=s[f-1]
break
case l.Q:t.quadraticCurveTo(s[f++],s[f++],s[f++],s[f++]),i=s[f-2],r=s[f-1]
break
case l.A:var p=s[f++],m=s[f++],y=s[f++],x=s[f++],w=s[f++],b=s[f++],S=s[f++],T=s[f++],M=y>x?y:x,C=y>x?1:y/x,k=y>x?x/y:1,D=w+b
Math.abs(y-x)>.001?(t.translate(p,m),t.rotate(S),t.scale(C,k),t.arc(0,0,M,w,D,1-T),t.scale(1/C,1/k),t.rotate(-S),t.translate(-p,-m)):t.arc(p,m,M,w,D,1-T),1===f&&(e=g(w)*y+p,n=v(w)*x+m),i=g(D)*y+p,r=v(D)*x+m
break
case l.R:e=i=s[f],n=r=s[f+1],t.rect(s[f++],s[f++],s[f++],s[f++])
break
case l.Z:t.closePath(),i=e,r=n}}}},x.CMD=l
var w=x
t.exports=w},function(t,e,n){var i=n(207),r=n(219).parseClassType,a=0
e.getUID=function(t){return[t||"",a++,Math.random().toFixed(5)].join("_")},e.enableSubTypeDefaulter=function(t){var e={}
return t.registerSubTypeDefaulter=function(t,n){t=r(t),e[t.main]=n},t.determineSubType=function(n,i){var a=i.type
if(!a){var o=r(n).main
t.hasSubTypes(n)&&e[o]&&(a=e[o](i))}return a},t},e.enableTopologicalTravel=function(t,e){function n(t,e){return t[e]||(t[e]={predecessor:[],successor:[]}),t[e]}t.topologicalTravel=function(t,r,a,o){if(t.length){var s=function(t){var r={},a=[]
return i.each(t,(function(o){var s=n(r,o),l=function(t,e){var n=[]
return i.each(t,(function(t){i.indexOf(e,t)>=0&&n.push(t)})),n}(s.originalDeps=e(o),t)
s.entryCount=l.length,0===s.entryCount&&a.push(o),i.each(l,(function(t){i.indexOf(s.predecessor,t)<0&&s.predecessor.push(t)
var e=n(r,t)
i.indexOf(e.successor,t)<0&&e.successor.push(o)}))})),{graph:r,noEntryList:a}}(r),l=s.graph,u=s.noEntryList,h={}
for(i.each(t,(function(t){h[t]=!0}));u.length;){var c=u.pop(),f=l[c],d=!!h[c]
d&&(a.call(o,c,f.originalDeps.slice()),delete h[c]),i.each(f.successor,d?g:p)}i.each(h,(function(){throw new Error("Circle dependency may exists")}))}function p(t){l[t].entryCount--,0===l[t].entryCount&&u.push(t)}function g(t){h[t]=!0,p(t)}}}},function(t,e,n){var i=n(219)
function r(t){this._setting=t||{},this._extent=[1/0,-1/0],this._interval=0,this.init&&this.init.apply(this,arguments)}r.prototype.parse=function(t){return t},r.prototype.getSetting=function(t){return this._setting[t]},r.prototype.contain=function(t){var e=this._extent
return t>=e[0]&&t<=e[1]},r.prototype.normalize=function(t){var e=this._extent
return e[1]===e[0]?.5:(t-e[0])/(e[1]-e[0])},r.prototype.scale=function(t){var e=this._extent
return t*(e[1]-e[0])+e[0]},r.prototype.unionExtent=function(t){var e=this._extent
t[0]<e[0]&&(e[0]=t[0]),t[1]>e[1]&&(e[1]=t[1])},r.prototype.unionExtentFromData=function(t,e){this.unionExtent(t.getApproximateExtent(e))},r.prototype.getExtent=function(){return this._extent.slice()},r.prototype.setExtent=function(t,e){var n=this._extent
isNaN(t)||(n[0]=t),isNaN(e)||(n[1]=e)},r.prototype.isBlank=function(){return this._isBlank},r.prototype.setBlank=function(t){this._isBlank=t},r.prototype.getLabel=null,i.enableClassExtend(r),i.enableClassManagement(r,{registerWhenExtend:!0})
var a=r
t.exports=a},,function(t,e){function n(t,e,n,i){var r=e+1
if(r===n)return 1
if(i(t[r++],t[e])<0){for(;r<n&&i(t[r],t[r-1])<0;)r++
!function(t,e,n){for(n--;e<n;){var i=t[e]
t[e++]=t[n],t[n--]=i}}(t,e,r)}else for(;r<n&&i(t[r],t[r-1])>=0;)r++
return r-e}function i(t,e,n,i,r){for(i===e&&i++;i<n;i++){for(var a,o=t[i],s=e,l=i;s<l;)r(o,t[a=s+l>>>1])<0?l=a:s=a+1
var u=i-s
switch(u){case 3:t[s+3]=t[s+2]
case 2:t[s+2]=t[s+1]
case 1:t[s+1]=t[s]
break
default:for(;u>0;)t[s+u]=t[s+u-1],u--}t[s]=o}}function r(t,e,n,i,r,a){var o=0,s=0,l=1
if(a(t,e[n+r])>0){for(s=i-r;l<s&&a(t,e[n+r+l])>0;)o=l,(l=1+(l<<1))<=0&&(l=s)
l>s&&(l=s),o+=r,l+=r}else{for(s=r+1;l<s&&a(t,e[n+r-l])<=0;)o=l,(l=1+(l<<1))<=0&&(l=s)
l>s&&(l=s)
var u=o
o=r-l,l=r-u}for(o++;o<l;){var h=o+(l-o>>>1)
a(t,e[n+h])>0?o=h+1:l=h}return l}function a(t,e,n,i,r,a){var o=0,s=0,l=1
if(a(t,e[n+r])<0){for(s=r+1;l<s&&a(t,e[n+r-l])<0;)o=l,(l=1+(l<<1))<=0&&(l=s)
l>s&&(l=s)
var u=o
o=r-l,l=r-u}else{for(s=i-r;l<s&&a(t,e[n+r+l])>=0;)o=l,(l=1+(l<<1))<=0&&(l=s)
l>s&&(l=s),o+=r,l+=r}for(o++;o<l;){var h=o+(l-o>>>1)
a(t,e[n+h])<0?l=h:o=h+1}return l}function o(t,e){var n,i,o=7,s=0
t.length
var l=[]
function u(u){var h=n[u],c=i[u],f=n[u+1],d=i[u+1]
i[u]=c+d,u===s-3&&(n[u+1]=n[u+2],i[u+1]=i[u+2]),s--
var p=a(t[f],t,h,c,0,e)
h+=p,0!=(c-=p)&&0!==(d=r(t[h+c-1],t,f,d,d-1,e))&&(c<=d?function(n,i,s,u){var h=0
for(h=0;h<i;h++)l[h]=t[n+h]
var c=0,f=s,d=n
if(t[d++]=t[f++],0!=--u)if(1!==i){for(var p,g,v,m=o;;){p=0,g=0,v=!1
do{if(e(t[f],l[c])<0){if(t[d++]=t[f++],g++,p=0,0==--u){v=!0
break}}else if(t[d++]=l[c++],p++,g=0,1==--i){v=!0
break}}while((p|g)<m)
if(v)break
do{if(0!==(p=a(t[f],l,c,i,0,e))){for(h=0;h<p;h++)t[d+h]=l[c+h]
if(d+=p,c+=p,(i-=p)<=1){v=!0
break}}if(t[d++]=t[f++],0==--u){v=!0
break}if(0!==(g=r(l[c],t,f,u,0,e))){for(h=0;h<g;h++)t[d+h]=t[f+h]
if(d+=g,f+=g,0==(u-=g)){v=!0
break}}if(t[d++]=l[c++],1==--i){v=!0
break}m--}while(p>=7||g>=7)
if(v)break
m<0&&(m=0),m+=2}if((o=m)<1&&(o=1),1===i){for(h=0;h<u;h++)t[d+h]=t[f+h]
t[d+u]=l[c]}else{if(0===i)throw new Error
for(h=0;h<i;h++)t[d+h]=l[c+h]}}else{for(h=0;h<u;h++)t[d+h]=t[f+h]
t[d+u]=l[c]}else for(h=0;h<i;h++)t[d+h]=l[c+h]}(h,c,f,d):function(n,i,s,u){var h=0
for(h=0;h<u;h++)l[h]=t[s+h]
var c=n+i-1,f=u-1,d=s+u-1,p=0,g=0
if(t[d--]=t[c--],0!=--i)if(1!==u){for(var v=o;;){var m=0,_=0,y=!1
do{if(e(l[f],t[c])<0){if(t[d--]=t[c--],m++,_=0,0==--i){y=!0
break}}else if(t[d--]=l[f--],_++,m=0,1==--u){y=!0
break}}while((m|_)<v)
if(y)break
do{if(0!=(m=i-a(l[f],t,n,i,i-1,e))){for(i-=m,g=1+(d-=m),p=1+(c-=m),h=m-1;h>=0;h--)t[g+h]=t[p+h]
if(0===i){y=!0
break}}if(t[d--]=l[f--],1==--u){y=!0
break}if(0!=(_=u-r(t[c],l,0,u,u-1,e))){for(u-=_,g=1+(d-=_),p=1+(f-=_),h=0;h<_;h++)t[g+h]=l[p+h]
if(u<=1){y=!0
break}}if(t[d--]=t[c--],0==--i){y=!0
break}v--}while(m>=7||_>=7)
if(y)break
v<0&&(v=0),v+=2}if((o=v)<1&&(o=1),1===u){for(g=1+(d-=i),p=1+(c-=i),h=i-1;h>=0;h--)t[g+h]=t[p+h]
t[d]=l[f]}else{if(0===u)throw new Error
for(p=d-(u-1),h=0;h<u;h++)t[p+h]=l[h]}}else{for(g=1+(d-=i),p=1+(c-=i),h=i-1;h>=0;h--)t[g+h]=t[p+h]
t[d]=l[f]}else for(p=d-(u-1),h=0;h<u;h++)t[p+h]=l[h]}(h,c,f,d))}n=[],i=[],this.mergeRuns=function(){for(;s>1;){var t=s-2
if(t>=1&&i[t-1]<=i[t]+i[t+1]||t>=2&&i[t-2]<=i[t]+i[t-1])i[t-1]<i[t+1]&&t--
else if(i[t]>i[t+1])break
u(t)}},this.forceMergeRuns=function(){for(;s>1;){var t=s-2
t>0&&i[t-1]<i[t+1]&&t--,u(t)}},this.pushRun=function(t,e){n[s]=t,i[s]=e,s+=1}}t.exports=function(t,e,r,a){r||(r=0),a||(a=t.length)
var s=a-r
if(!(s<2)){var l=0
if(s<32)i(t,r,a,r+(l=n(t,r,a,e)),e)
else{var u=new o(t,e),h=function(t){for(var e=0;t>=32;)e|=1&t,t>>=1
return t+e}(s)
do{if((l=n(t,r,a,e))<h){var c=s
c>h&&(c=h),i(t,r,r+c,r+l,e),l=c}u.pushRun(r,l),u.mergeRuns(),s-=l,r+=l}while(0!==s)
u.forceMergeRuns()}}}},function(t,e,n){var i=n(265),r=n(235).ContextCachedBy,a=[["shadowBlur",0],["shadowOffsetX",0],["shadowOffsetY",0],["shadowColor","#000"],["lineCap","butt"],["lineJoin","miter"],["miterLimit",10]],o=function(t){this.extendFrom(t,!1)}
function s(t,e,n){var i=null==e.x?0:e.x,r=null==e.x2?1:e.x2,a=null==e.y?0:e.y,o=null==e.y2?0:e.y2
return e.global||(i=i*n.width+n.x,r=r*n.width+n.x,a=a*n.height+n.y,o=o*n.height+n.y),i=isNaN(i)?0:i,r=isNaN(r)?1:r,a=isNaN(a)?0:a,o=isNaN(o)?0:o,t.createLinearGradient(i,a,r,o)}function l(t,e,n){var i=n.width,r=n.height,a=Math.min(i,r),o=null==e.x?.5:e.x,s=null==e.y?.5:e.y,l=null==e.r?.5:e.r
return e.global||(o=o*i+n.x,s=s*r+n.y,l*=a),t.createRadialGradient(o,s,0,o,s,l)}for(var u=o.prototype={constructor:o,fill:"#000",stroke:null,opacity:1,fillOpacity:null,strokeOpacity:null,lineDash:null,lineDashOffset:0,shadowBlur:0,shadowOffsetX:0,shadowOffsetY:0,lineWidth:1,strokeNoScale:!1,text:null,font:null,textFont:null,fontStyle:null,fontWeight:null,fontSize:null,fontFamily:null,textTag:null,textFill:"#000",textStroke:null,textWidth:null,textHeight:null,textStrokeWidth:0,textLineHeight:null,textPosition:"inside",textRect:null,textOffset:null,textAlign:null,textVerticalAlign:null,textDistance:5,textShadowColor:"transparent",textShadowBlur:0,textShadowOffsetX:0,textShadowOffsetY:0,textBoxShadowColor:"transparent",textBoxShadowBlur:0,textBoxShadowOffsetX:0,textBoxShadowOffsetY:0,transformText:!1,textRotation:0,textOrigin:null,textBackgroundColor:null,textBorderColor:null,textBorderWidth:0,textBorderRadius:0,textPadding:null,rich:null,truncate:null,blend:null,bind:function(t,e,n){var o=n&&n.style,s=!o||t.__attrCachedBy!==r.STYLE_BIND
t.__attrCachedBy=r.STYLE_BIND
for(var l=0;l<a.length;l++){var u=a[l],h=u[0];(s||this[h]!==o[h])&&(t[h]=i(t,h,this[h]||u[1]))}if((s||this.fill!==o.fill)&&(t.fillStyle=this.fill),(s||this.stroke!==o.stroke)&&(t.strokeStyle=this.stroke),(s||this.opacity!==o.opacity)&&(t.globalAlpha=null==this.opacity?1:this.opacity),(s||this.blend!==o.blend)&&(t.globalCompositeOperation=this.blend||"source-over"),this.hasStroke()){var c=this.lineWidth
t.lineWidth=c/(this.strokeNoScale&&e&&e.getLineScale?e.getLineScale():1)}},hasFill:function(){var t=this.fill
return null!=t&&"none"!==t},hasStroke:function(){var t=this.stroke
return null!=t&&"none"!==t&&this.lineWidth>0},extendFrom:function(t,e){if(t)for(var n in t)!t.hasOwnProperty(n)||!0!==e&&(!1===e?this.hasOwnProperty(n):null==t[n])||(this[n]=t[n])},set:function(t,e){"string"==typeof t?this[t]=e:this.extendFrom(t,!0)},clone:function(){var t=new this.constructor
return t.extendFrom(this,!0),t},getGradient:function(t,e,n){for(var i=("radial"===e.type?l:s)(t,e,n),r=e.colorStops,a=0;a<r.length;a++)i.addColorStop(r[a].offset,r[a].color)
return i}},h=0;h<a.length;h++){var c=a[h]
c[0]in u||(u[c[0]]=c[1])}o.getGradient=u.getGradient
var f=o
t.exports=f},function(t,e,n){var i=n(236),r=n(215),a=n(207),o=n(244)
function s(t){i.call(this,t)}s.prototype={constructor:s,type:"image",brush:function(t,e){var n=this.style,i=n.image
n.bind(t,this,e)
var r=this._image=o.createOrUpdateImage(i,this._image,this,this.onload)
if(r&&o.isImageReady(r)){var a=n.x||0,s=n.y||0,l=n.width,u=n.height,h=r.width/r.height
if(null==l&&null!=u?l=u*h:null==u&&null!=l?u=l/h:null==l&&null==u&&(l=r.width,u=r.height),this.setTransform(t),n.sWidth&&n.sHeight){var c=n.sx||0,f=n.sy||0
t.drawImage(r,c,f,n.sWidth,n.sHeight,a,s,l,u)}else if(n.sx&&n.sy){var d=l-(c=n.sx),p=u-(f=n.sy)
t.drawImage(r,c,f,d,p,a,s,l,u)}else t.drawImage(r,a,s,l,u)
null!=n.text&&(this.restoreTransform(t),this.drawRectText(t,this.getBoundingRect()))}},getBoundingRect:function(){var t=this.style
return this._rect||(this._rect=new r(t.x||0,t.y||0,t.width||0,t.height||0)),this._rect}},a.inherits(s,i)
var l=s
t.exports=l},function(t,e,n){var i=new(n(263))(50)
function r(){var t=this.__cachedImgObj
this.onload=this.onerror=this.__cachedImgObj=null
for(var e=0;e<t.pending.length;e++){var n=t.pending[e],i=n.cb
i&&i(this,n.cbPayload),n.hostEl.dirty()}t.pending.length=0}function a(t){return t&&t.width&&t.height}e.findExistImage=function(t){if("string"==typeof t){var e=i.get(t)
return e&&e.image}return t},e.createOrUpdateImage=function(t,e,n,o,s){if(t){if("string"==typeof t){if(e&&e.__zrImageSrc===t||!n)return e
var l=i.get(t),u={hostEl:n,cb:o,cbPayload:s}
return l?!a(e=l.image)&&l.pending.push(u):((e=new Image).onload=e.onerror=r,i.put(t,e.__cachedImgObj={image:e,pending:[u]}),e.src=e.__zrImageSrc=t),e}return t}return e},e.isImageReady=a},function(t,e,n){var i=n(207)
t.exports=function(t){for(var e=0;e<t.length;e++)t[e][1]||(t[e][1]=t[e][0])
return function(e,n,r){for(var a={},o=0;o<t.length;o++){var s=t[o][1]
if(!(n&&i.indexOf(n,s)>=0||r&&i.indexOf(r,s)<0)){var l=e.getShallow(s)
null!=l&&(a[t[o][0]]=l)}}return a}}},function(t,e,n){var i=n(212),r=n(223),a=Math.min,o=Math.max,s=Math.sin,l=Math.cos,u=2*Math.PI,h=i.create(),c=i.create(),f=i.create(),d=[],p=[]
e.fromPoints=function(t,e,n){if(0!==t.length){var i,r=t[0],s=r[0],l=r[0],u=r[1],h=r[1]
for(i=1;i<t.length;i++)r=t[i],s=a(s,r[0]),l=o(l,r[0]),u=a(u,r[1]),h=o(h,r[1])
e[0]=s,e[1]=u,n[0]=l,n[1]=h}},e.fromLine=function(t,e,n,i,r,s){r[0]=a(t,n),r[1]=a(e,i),s[0]=o(t,n),s[1]=o(e,i)},e.fromCubic=function(t,e,n,i,s,l,u,h,c,f){var g,v=r.cubicExtrema,m=r.cubicAt,_=v(t,n,s,u,d)
for(c[0]=1/0,c[1]=1/0,f[0]=-1/0,f[1]=-1/0,g=0;g<_;g++){var y=m(t,n,s,u,d[g])
c[0]=a(y,c[0]),f[0]=o(y,f[0])}for(_=v(e,i,l,h,p),g=0;g<_;g++){var x=m(e,i,l,h,p[g])
c[1]=a(x,c[1]),f[1]=o(x,f[1])}c[0]=a(t,c[0]),f[0]=o(t,f[0]),c[0]=a(u,c[0]),f[0]=o(u,f[0]),c[1]=a(e,c[1]),f[1]=o(e,f[1]),c[1]=a(h,c[1]),f[1]=o(h,f[1])},e.fromQuadratic=function(t,e,n,i,s,l,u,h){var c=r.quadraticExtremum,f=r.quadraticAt,d=o(a(c(t,n,s),1),0),p=o(a(c(e,i,l),1),0),g=f(t,n,s,d),v=f(e,i,l,p)
u[0]=a(t,s,g),u[1]=a(e,l,v),h[0]=o(t,s,g),h[1]=o(e,l,v)},e.fromArc=function(t,e,n,r,a,o,d,p,g){var v=i.min,m=i.max,_=Math.abs(a-o)
if(_%u<1e-4&&_>1e-4)return p[0]=t-n,p[1]=e-r,g[0]=t+n,void(g[1]=e+r)
if(h[0]=l(a)*n+t,h[1]=s(a)*r+e,c[0]=l(o)*n+t,c[1]=s(o)*r+e,v(p,h,c),m(g,h,c),(a%=u)<0&&(a+=u),(o%=u)<0&&(o+=u),a>o&&!d?o+=u:a<o&&d&&(a+=u),d){var y=o
o=a,a=y}for(var x=0;x<o;x+=Math.PI/2)x>a&&(f[0]=l(x)*n+t,f[1]=s(x)*r+e,v(p,f,p),m(g,f,g))}},function(t,e,n){var i=n(236),r=n(207),a=n(217),o=n(268),s=n(235).ContextCachedBy,l=function(t){i.call(this,t)}
l.prototype={constructor:l,type:"text",brush:function(t,e){var n=this.style
this.__dirty&&o.normalizeTextStyle(n,!0),n.fill=n.stroke=n.shadowBlur=n.shadowColor=n.shadowOffsetX=n.shadowOffsetY=null
var i=n.text
null!=i&&(i+=""),o.needDrawText(i,n)?(this.setTransform(t),o.renderText(this,t,i,n,null,e),this.restoreTransform(t)):t.__attrCachedBy=s.NONE},getBoundingRect:function(){var t=this.style
if(this.__dirty&&o.normalizeTextStyle(t,!0),!this._rect){var e=t.text
null!=e?e+="":e=""
var n=a.getBoundingRect(t.text+"",t.font,t.textAlign,t.textVerticalAlign,t.textPadding,t.textLineHeight,t.rich)
if(n.x+=t.x||0,n.y+=t.y||0,o.getStroke(t.textStroke,t.textStrokeWidth)){var i=t.textStrokeWidth
n.x-=i/2,n.y-=i/2,n.width+=i,n.height+=i}this._rect=n}return this._rect}},r.inherits(l,i)
var u=l
t.exports=u},function(t,e){var n=Math.round
function i(t,e,i){if(!e)return t
var r=n(2*t)
return(r+n(e))%2==0?r/2:(r+(i?1:-1))/2}e.subPixelOptimizeLine=function(t,e,r){if(e){var a=e.x1,o=e.x2,s=e.y1,l=e.y2
t.x1=a,t.x2=o,t.y1=s,t.y2=l
var u=r&&r.lineWidth
u&&(n(2*a)===n(2*o)&&(t.x1=t.x2=i(a,u,!0)),n(2*s)===n(2*l)&&(t.y1=t.y2=i(s,u,!0)))}},e.subPixelOptimizeRect=function(t,e,n){if(e){var r=e.x,a=e.y,o=e.width,s=e.height
t.x=r,t.y=a,t.width=o,t.height=s
var l=n&&n.lineWidth
l&&(t.x=i(r,l,!0),t.y=i(a,l,!0),t.width=Math.max(i(r+o,l,!1)-t.x,0===o?0:1),t.height=Math.max(i(a+s,l,!1)-t.y,0===s?0:1))}},e.subPixelOptimize=i},function(t,e){var n=function(t){this.colorStops=t||[]}
n.prototype={constructor:n,addColorStop:function(t,e){this.colorStops.push({offset:t,color:e})}}
var i=n
t.exports=i},function(t,e,n){var i=n(207),r={}
function a(){this._coordinateSystems=[]}a.prototype={constructor:a,create:function(t,e){var n=[]
i.each(r,(function(i,r){var a=i.create(t,e)
n=n.concat(a||[])})),this._coordinateSystems=n},update:function(t,e){i.each(this._coordinateSystems,(function(n){n.update&&n.update(t,e)}))},getCoordinateSystems:function(){return this._coordinateSystems.slice()}},a.register=function(t,e){r[t]=e},a.get=function(t){return r[t]}
var o=a
t.exports=o},function(t,e,n){var i=n(207),r=(i.assert,i.isArray)
function a(t){t=t||{},this._reset=t.reset,this._plan=t.plan,this._count=t.count,this._onDirty=t.onDirty,this._dirty=!0,this.context}n(210).__DEV__
var o=a.prototype
o.perform=function(t){var e,n=this._upstream,i=t&&t.skip
if(this._dirty&&n){var a=this.context
a.data=a.outputData=n.context.outputData}this.__pipeline&&(this.__pipeline.currentTask=this),this._plan&&!i&&(e=this._plan(this.context))
var o,s=f(this._modBy),u=this._modDataCount||0,h=f(t&&t.modBy),c=t&&t.modDataCount||0
function f(t){return!(t>=1)&&(t=1),t}s===h&&u===c||(e="reset"),(this._dirty||"reset"===e)&&(this._dirty=!1,o=function(t,e){var n,i
t._dueIndex=t._outputDueEnd=t._dueEnd=0,t._settedOutputEnd=null,!e&&t._reset&&((n=t._reset(t.context))&&n.progress&&(i=n.forceFirstProgress,n=n.progress),r(n)&&!n.length&&(n=null)),t._progress=n,t._modBy=t._modDataCount=null
var a=t._downstream
return a&&a.dirty(),i}(this,i)),this._modBy=h,this._modDataCount=c
var d=t&&t.step
if(this._dueEnd=n?n._outputDueEnd:this._count?this._count(this.context):1/0,this._progress){var p=this._dueIndex,g=Math.min(null!=d?this._dueIndex+d:1/0,this._dueEnd)
if(!i&&(o||p<g)){var v=this._progress
if(r(v))for(var m=0;m<v.length;m++)l(this,v[m],p,g,h,c)
else l(this,v,p,g,h,c)}this._dueIndex=g
var _=null!=this._settedOutputEnd?this._settedOutputEnd:g
this._outputDueEnd=_}else this._dueIndex=this._outputDueEnd=null!=this._settedOutputEnd?this._settedOutputEnd:this._dueEnd
return this.unfinished()}
var s=function(){var t,e,n,i,r,a={reset:function(l,u,h,c){e=l,t=u,n=h,i=c,r=Math.ceil(i/n),a.next=n>1&&i>0?s:o}}
return a
function o(){return e<t?e++:null}function s(){var a=e%r*n+Math.ceil(e/r),o=e>=t?null:a<i?a:e
return e++,o}}()
function l(t,e,n,i,r,a){s.reset(n,i,r,a),t._callingProgress=e,t._callingProgress({start:n,end:i,count:i-n,next:s.next},t.context)}o.dirty=function(){this._dirty=!0,this._onDirty&&this._onDirty(this.context)},o.unfinished=function(){return this._progress&&this._dueIndex<this._dueEnd},o.pipe=function(t){(this._downstream!==t||this._dirty)&&(this._downstream=t,t._upstream=this,t.dirty())},o.dispose=function(){this._disposed||(this._upstream&&(this._upstream._downstream=null),this._downstream&&(this._downstream._upstream=null),this._dirty=!1,this._disposed=!0)},o.getUpstream=function(){return this._upstream},o.getDownstream=function(){return this._downstream},o.setOutputEnd=function(t){this._outputDueEnd=this._settedOutputEnd=t},e.createTask=function(t){return new a(t)}},function(t,e,n){var i=n(208).makeInner
t.exports=function(){var t=i()
return function(e){var n=t(e),i=e.pipelineContext,r=n.large,a=n.progressiveRender,o=n.large=i&&i.large,s=n.progressiveRender=i&&i.progressiveRender
return!!(r^o||a^s)&&"reset"}}},function(t,e){var n="\0__throttleOriginMethod",i="\0__throttleRate"
function r(t,e,n){var i,r,a,o,s,l=0,u=0,h=null
function c(){u=(new Date).getTime(),h=null,t.apply(a,o||[])}e=e||0
var f=function(){i=(new Date).getTime(),a=this,o=arguments
var t=s||e,f=s||n
s=null,r=i-(f?l:u)-t,clearTimeout(h),f?h=setTimeout(c,t):r>=0?c():h=setTimeout(c,-r),l=i}
return f.clear=function(){h&&(clearTimeout(h),h=null)},f.debounceNextCall=function(t){s=t},f}e.throttle=r,e.createOrUpdate=function(t,e,a,o){var s=t[e]
if(s){var l=s[n]||s,u=s["\0__throttleType"]
if(s[i]!==a||u!==o){if(null==a||!o)return t[e]=l;(s=t[e]=r(l,a,"debounce"===o))[n]=l,s["\0__throttleType"]=o,s[i]=a}return s}},e.clear=function(t,e){var i=t[e]
i&&i[n]&&(t[e]=i[n])}},function(t,e,n){var i=n(207),r=i.each,a=i.createHashMap,o=(i.assert,n(210).__DEV__,a(["tooltip","label","itemName","itemId","seriesName"]))
function s(t,e){return t.hasOwnProperty(e)||(t[e]=[]),t[e]}e.OTHER_DIMENSIONS=o,e.summarizeDimensions=function(t){var e={},n=e.encode={},i=a(),l=[],u=[],h=e.userOutput={dimensionNames:t.dimensions.slice(),encode:{}}
r(t.dimensions,(function(e){var r,a=t.getDimensionInfo(e),c=a.coordDim
if(c){var f=a.coordDimIndex
s(n,c)[f]=e,a.isExtraCoord||(i.set(c,1),"ordinal"!==(r=a.type)&&"time"!==r&&(l[0]=e),s(h.encode,c)[f]=a.index),a.defaultTooltip&&u.push(e)}o.each((function(t,e){var i=s(n,e),r=a.otherDims[e]
null!=r&&!1!==r&&(i[r]=a.name)}))}))
var c=[],f={}
i.each((function(t,e){var i=n[e]
f[e]=i[0],c=c.concat(i)})),e.dataDimsOnCoord=c,e.encodeFirstDimNotExtra=f
var d=n.label
d&&d.length&&(l=d.slice())
var p=n.tooltip
return p&&p.length?u=p.slice():u.length||(u=l.slice()),n.defaultedLabel=l,n.defaultedTooltip=u,e},e.getDimensionTypeByAxis=function(t){return"category"===t?"ordinal":"time"===t?"time":"float"}},function(t,e,n){var i=n(214),r=n(216),a=n(239),o=n(293),s=i.round,l=a.extend({type:"interval",_interval:0,_intervalPrecision:2,setExtent:function(t,e){var n=this._extent
isNaN(t)||(n[0]=parseFloat(t)),isNaN(e)||(n[1]=parseFloat(e))},unionExtent:function(t){var e=this._extent
t[0]<e[0]&&(e[0]=t[0]),t[1]>e[1]&&(e[1]=t[1]),l.prototype.setExtent.call(this,e[0],e[1])},getInterval:function(){return this._interval},setInterval:function(t){this._interval=t,this._niceExtent=this._extent.slice(),this._intervalPrecision=o.getIntervalPrecision(t)},getTicks:function(t){var e=this._interval,n=this._extent,i=this._niceExtent,r=this._intervalPrecision,a=[]
if(!e)return a
n[0]<i[0]&&(t?a.push(s(i[0]-e,r)):a.push(n[0]))
for(var o=i[0];o<=i[1]&&(a.push(o),(o=s(o+e,r))!==a[a.length-1]);)if(a.length>1e4)return[]
var l=a.length?a[a.length-1]:i[1]
return n[1]>l&&(t?a.push(s(l+e,r)):a.push(n[1])),a},getMinorTicks:function(t){for(var e=this.getTicks(!0),n=[],r=this.getExtent(),a=1;a<e.length;a++){for(var o=e[a],s=e[a-1],l=0,u=[],h=(o-s)/t;l<t-1;){var c=i.round(s+(l+1)*h)
c>r[0]&&c<r[1]&&u.push(c),l++}n.push(u)}return n},getLabel:function(t,e){if(null==t)return""
var n=e&&e.precision
return null==n?n=i.getPrecisionSafe(t)||0:"auto"===n&&(n=this._intervalPrecision),t=s(t,n,!0),r.addCommas(t)},niceTicks:function(t,e,n){t=t||5
var i=this._extent,r=i[1]-i[0]
if(isFinite(r)){r<0&&(r=-r,i.reverse())
var a=o.intervalScaleNiceTicks(i,t,e,n)
this._intervalPrecision=a.intervalPrecision,this._interval=a.interval,this._niceExtent=a.niceTickExtent}},niceExtent:function(t){var e=this._extent
if(e[0]===e[1])if(0!==e[0]){var n=e[0]
t.fixMax||(e[1]+=n/2),e[0]-=n/2}else e[1]=1
var i=e[1]-e[0]
isFinite(i)||(e[0]=0,e[1]=1),this.niceTicks(t.splitNumber,t.minInterval,t.maxInterval)
var r=this._interval
t.fixMin||(e[0]=s(Math.floor(e[0]/r)*r)),t.fixMax||(e[1]=s(Math.ceil(e[1]/r)*r))}})
l.create=function(){return new l}
var u=l
t.exports=u},function(t,e,n){var i=n(207),r=n(209),a=n(215),o=n(217).calculateTextPosition,s=r.extendShape({type:"triangle",shape:{cx:0,cy:0,width:0,height:0},buildPath:function(t,e){var n=e.cx,i=e.cy,r=e.width/2,a=e.height/2
t.moveTo(n,i-a),t.lineTo(n+r,i+a),t.lineTo(n-r,i+a),t.closePath()}}),l=r.extendShape({type:"diamond",shape:{cx:0,cy:0,width:0,height:0},buildPath:function(t,e){var n=e.cx,i=e.cy,r=e.width/2,a=e.height/2
t.moveTo(n,i-a),t.lineTo(n+r,i),t.lineTo(n,i+a),t.lineTo(n-r,i),t.closePath()}}),u=r.extendShape({type:"pin",shape:{x:0,y:0,width:0,height:0},buildPath:function(t,e){var n=e.x,i=e.y,r=e.width/5*3,a=Math.max(r,e.height),o=r/2,s=o*o/(a-o),l=i-a+o+s,u=Math.asin(s/o),h=Math.cos(u)*o,c=Math.sin(u),f=Math.cos(u),d=.6*o,p=.7*o
t.moveTo(n-h,l+s),t.arc(n,l,o,Math.PI-u,2*Math.PI+u),t.bezierCurveTo(n+h-c*d,l+s+f*d,n,i-p,n,i),t.bezierCurveTo(n,i-p,n-h+c*d,l+s+f*d,n-h,l+s),t.closePath()}}),h=r.extendShape({type:"arrow",shape:{x:0,y:0,width:0,height:0},buildPath:function(t,e){var n=e.height,i=e.width,r=e.x,a=e.y,o=i/3*2
t.moveTo(r,a),t.lineTo(r+o,a+n),t.lineTo(r,a+n/4*3),t.lineTo(r-o,a+n),t.lineTo(r,a),t.closePath()}}),c={line:r.Line,rect:r.Rect,roundRect:r.Rect,square:r.Rect,circle:r.Circle,diamond:l,pin:u,arrow:h,triangle:s},f={line:function(t,e,n,i,r){r.x1=t,r.y1=e+i/2,r.x2=t+n,r.y2=e+i/2},rect:function(t,e,n,i,r){r.x=t,r.y=e,r.width=n,r.height=i},roundRect:function(t,e,n,i,r){r.x=t,r.y=e,r.width=n,r.height=i,r.r=Math.min(n,i)/4},square:function(t,e,n,i,r){var a=Math.min(n,i)
r.x=t,r.y=e,r.width=a,r.height=a},circle:function(t,e,n,i,r){r.cx=t+n/2,r.cy=e+i/2,r.r=Math.min(n,i)/2},diamond:function(t,e,n,i,r){r.cx=t+n/2,r.cy=e+i/2,r.width=n,r.height=i},pin:function(t,e,n,i,r){r.x=t+n/2,r.y=e+i/2,r.width=n,r.height=i},arrow:function(t,e,n,i,r){r.x=t+n/2,r.y=e+i/2,r.width=n,r.height=i},triangle:function(t,e,n,i,r){r.cx=t+n/2,r.cy=e+i/2,r.width=n,r.height=i}},d={}
i.each(c,(function(t,e){d[e]=new t}))
var p=r.extendShape({type:"symbol",shape:{symbolType:"",x:0,y:0,width:0,height:0},calculateTextPosition:function(t,e,n){var i=o(t,e,n),r=this.shape
return r&&"pin"===r.symbolType&&"inside"===e.textPosition&&(i.y=n.y+.4*n.height),i},buildPath:function(t,e,n){var i=e.symbolType
if("none"!==i){var r=d[i]
r||(r=d[i="rect"]),f[i](e.x,e.y,e.width,e.height,r.shape),r.buildPath(t,r.shape,n)}}})
function g(t,e){if("image"!==this.type){var n=this.style,i=this.shape
i&&"line"===i.symbolType?n.stroke=t:this.__isEmptyBrush?(n.stroke=t,n.fill=e||"#fff"):(n.fill&&(n.fill=t),n.stroke&&(n.stroke=t)),this.dirty(!1)}}e.createSymbol=function(t,e,n,i,o,s,l){var u,h=0===t.indexOf("empty")
return h&&(t=t.substr(5,1).toLowerCase()+t.substr(6)),(u=0===t.indexOf("image://")?r.makeImage(t.slice(8),new a(e,n,i,o),l?"center":"cover"):0===t.indexOf("path://")?r.makePath(t.slice(7),{},new a(e,n,i,o),l?"center":"cover"):new p({shape:{symbolType:t,x:e,y:n,width:i,height:o}})).__isEmptyBrush=h,u.setColor=g,u.setColor(s),u}},function(t,e,n){var i=n(258),r=n(211),a=n(207),o=n(305),s=n(309),l=n(313),u=n(316),h=n(317),c=!r.canvasSupported,f={canvas:l},d={},p=function(t,e,n){n=n||{},this.dom=e,this.id=t
var i=this,l=new s,d=n.renderer
if(c){if(!f.vml)throw new Error("You need to require 'zrender/vml/vml' to support IE8")
d="vml"}else d&&f[d]||(d="canvas")
var p=new f[d](e,l,n,t)
this.storage=l,this.painter=p
var g=r.node||r.worker?null:new h(p.getViewportRoot(),p.root)
this.handler=new o(l,p,g,p.root),this.animation=new u({stage:{update:a.bind(this.flush,this)}}),this.animation.start(),this._needsRefresh
var v=l.delFromStorage,m=l.addToStorage
l.delFromStorage=function(t){v.call(l,t),t&&t.removeSelfFromZr(i)},l.addToStorage=function(t){m.call(l,t),t.addSelfToZr(i)}}
p.prototype={constructor:p,getId:function(){return this.id},add:function(t){this.storage.addRoot(t),this._needsRefresh=!0},remove:function(t){this.storage.delRoot(t),this._needsRefresh=!0},configLayer:function(t,e){this.painter.configLayer&&this.painter.configLayer(t,e),this._needsRefresh=!0},setBackgroundColor:function(t){this.painter.setBackgroundColor&&this.painter.setBackgroundColor(t),this._needsRefresh=!0},refreshImmediately:function(){this._needsRefresh=this._needsRefreshHover=!1,this.painter.refresh(),this._needsRefresh=this._needsRefreshHover=!1},refresh:function(){this._needsRefresh=!0},flush:function(){var t
this._needsRefresh&&(t=!0,this.refreshImmediately()),this._needsRefreshHover&&(t=!0,this.refreshHoverImmediately()),t&&this.trigger("rendered")},addHover:function(t,e){if(this.painter.addHover){var n=this.painter.addHover(t,e)
return this.refreshHover(),n}},removeHover:function(t){this.painter.removeHover&&(this.painter.removeHover(t),this.refreshHover())},clearHover:function(){this.painter.clearHover&&(this.painter.clearHover(),this.refreshHover())},refreshHover:function(){this._needsRefreshHover=!0},refreshHoverImmediately:function(){this._needsRefreshHover=!1,this.painter.refreshHover&&this.painter.refreshHover()},resize:function(t){t=t||{},this.painter.resize(t.width,t.height),this.handler.resize()},clearAnimation:function(){this.animation.clear()},getWidth:function(){return this.painter.getWidth()},getHeight:function(){return this.painter.getHeight()},pathToImage:function(t,e){return this.painter.pathToImage(t,e)},setCursorStyle:function(t){this.handler.setCursorStyle(t)},findHover:function(t,e){return this.handler.findHover(t,e)},on:function(t,e,n){this.handler.on(t,e,n)},off:function(t,e){this.handler.off(t,e)},trigger:function(t,e){this.handler.trigger(t,e)},clear:function(){this.storage.delRoot(),this.painter.clear()},dispose:function(){var t
this.animation.stop(),this.clear(),this.storage.dispose(),this.painter.dispose(),this.handler.dispose(),this.animation=this.storage=this.painter=this.handler=null,t=this.id,delete d[t]}},e.version="4.3.2",e.init=function(t,e){var n=new p(i(),t,e)
return d[n.id]=n,n},e.dispose=function(t){if(t)t.dispose()
else{for(var e in d)d.hasOwnProperty(e)&&d[e].dispose()
d={}}return this},e.getInstance=function(t){return d[t]},e.registerPainter=function(t,e){f[t]=e}},function(t,e){var n=2311
t.exports=function(){return n++}},function(t,e,n){var i=n(211),r=n(307).buildTransformer,a=[]
function o(t,e,n,a,o){if(e.getBoundingClientRect&&i.domSupported&&!s(e)){var l=e.___zrEVENTSAVED||(e.___zrEVENTSAVED={}),u=function(t,e,n){for(var i=n?"invTrans":"trans",a=e[i],o=e.srcCoords,s=!0,l=[],u=[],h=0;h<4;h++){var c=t[h].getBoundingClientRect(),f=2*h,d=c.left,p=c.top
l.push(d,p),s=s&&o&&d===o[f]&&p===o[f+1],u.push(t[h].offsetLeft,t[h].offsetTop)}return s&&a?a:(e.srcCoords=l,e[i]=n?r(u,l):r(l,u))}(function(t,e){var n=e.markers
if(n)return n
n=e.markers=[]
for(var i=["left","right"],r=["top","bottom"],a=0;a<4;a++){var o=document.createElement("div"),s=a%2,l=(a>>1)%2
o.style.cssText=["position: absolute","visibility: hidden","padding: 0","margin: 0","border-width: 0","user-select: none","width:0","height:0",i[s]+":0",r[l]+":0",i[1-s]+":auto",r[1-l]+":auto",""].join("!important;"),t.appendChild(o),n.push(o)}return n}(e,l),l,o)
if(u)return u(t,n,a),!0}return!1}function s(t){return"CANVAS"===t.nodeName.toUpperCase()}e.transformLocalCoord=function(t,e,n,i,r){return o(a,e,i,r,!0)&&o(t,n,a[0],a[1])},e.transformCoordWithViewport=o,e.isCanvasEl=s},function(t,e,n){var i=n(258),r=n(227),a=n(261),o=n(310),s=n(207),l=function(t){a.call(this,t),r.call(this,t),o.call(this,t),this.id=t.id||i()}
l.prototype={type:"element",name:"",__zr:null,ignore:!1,clipPath:null,isGroup:!1,drift:function(t,e){switch(this.draggable){case"horizontal":e=0
break
case"vertical":t=0}var n=this.transform
n||(n=this.transform=[1,0,0,1,0,0]),n[4]+=t,n[5]+=e,this.decomposeTransform(),this.dirty(!1)},beforeUpdate:function(){},afterUpdate:function(){},update:function(){this.updateTransform()},traverse:function(t,e){},attrKV:function(t,e){if("position"===t||"scale"===t||"origin"===t){if(e){var n=this[t]
n||(n=this[t]=[]),n[0]=e[0],n[1]=e[1]}}else this[t]=e},hide:function(){this.ignore=!0,this.__zr&&this.__zr.refresh()},show:function(){this.ignore=!1,this.__zr&&this.__zr.refresh()},attr:function(t,e){if("string"==typeof t)this.attrKV(t,e)
else if(s.isObject(t))for(var n in t)t.hasOwnProperty(n)&&this.attrKV(n,t[n])
return this.dirty(!1),this},setClipPath:function(t){var e=this.__zr
e&&t.addSelfToZr(e),this.clipPath&&this.clipPath!==t&&this.removeClipPath(),this.clipPath=t,t.__zr=e,t.__clipTarget=this,this.dirty(!1)},removeClipPath:function(){var t=this.clipPath
t&&(t.__zr&&t.removeSelfFromZr(t.__zr),t.__zr=null,t.__clipTarget=null,this.clipPath=null,this.dirty(!1))},addSelfToZr:function(t){this.__zr=t
var e=this.animators
if(e)for(var n=0;n<e.length;n++)t.animation.addAnimator(e[n])
this.clipPath&&this.clipPath.addSelfToZr(t)},removeSelfFromZr:function(t){this.__zr=null
var e=this.animators
if(e)for(var n=0;n<e.length;n++)t.animation.removeAnimator(e[n])
this.clipPath&&this.clipPath.removeSelfFromZr(t)}},s.mixin(l,o),s.mixin(l,a),s.mixin(l,r)
var u=l
t.exports=u},function(t,e,n){var i=n(221),r=n(212),a=i.identity
function o(t){return t>5e-5||t<-5e-5}var s=function(t){(t=t||{}).position||(this.position=[0,0]),null==t.rotation&&(this.rotation=0),t.scale||(this.scale=[1,1]),this.origin=this.origin||null},l=s.prototype
l.transform=null,l.needLocalTransform=function(){return o(this.rotation)||o(this.position[0])||o(this.position[1])||o(this.scale[0]-1)||o(this.scale[1]-1)}
var u=[]
l.updateTransform=function(){var t=this.parent,e=t&&t.transform,n=this.needLocalTransform(),r=this.transform
if(n||e){r=r||i.create(),n?this.getLocalTransform(r):a(r),e&&(n?i.mul(r,t.transform,r):i.copy(r,t.transform)),this.transform=r
var o=this.globalScaleRatio
if(null!=o&&1!==o){this.getGlobalScale(u)
var s=u[0]<0?-1:1,l=u[1]<0?-1:1,h=((u[0]-s)*o+s)/u[0]||0,c=((u[1]-l)*o+l)/u[1]||0
r[0]*=h,r[1]*=h,r[2]*=c,r[3]*=c}this.invTransform=this.invTransform||i.create(),i.invert(this.invTransform,r)}else r&&a(r)},l.getLocalTransform=function(t){return s.getLocalTransform(this,t)},l.setTransform=function(t){var e=this.transform,n=t.dpr||1
e?t.setTransform(n*e[0],n*e[1],n*e[2],n*e[3],n*e[4],n*e[5]):t.setTransform(n,0,0,n,0,0)},l.restoreTransform=function(t){var e=t.dpr||1
t.setTransform(e,0,0,e,0,0)}
var h=[],c=i.create()
l.setLocalTransform=function(t){if(t){var e=t[0]*t[0]+t[1]*t[1],n=t[2]*t[2]+t[3]*t[3],i=this.position,r=this.scale
o(e-1)&&(e=Math.sqrt(e)),o(n-1)&&(n=Math.sqrt(n)),t[0]<0&&(e=-e),t[3]<0&&(n=-n),i[0]=t[4],i[1]=t[5],r[0]=e,r[1]=n,this.rotation=Math.atan2(-t[1]/n,t[0]/e)}},l.decomposeTransform=function(){if(this.transform){var t=this.parent,e=this.transform
t&&t.transform&&(i.mul(h,t.invTransform,e),e=h)
var n=this.origin
n&&(n[0]||n[1])&&(c[4]=n[0],c[5]=n[1],i.mul(h,e,c),h[4]-=n[0],h[5]-=n[1],e=h),this.setLocalTransform(e)}},l.getGlobalScale=function(t){var e=this.transform
return t=t||[],e?(t[0]=Math.sqrt(e[0]*e[0]+e[1]*e[1]),t[1]=Math.sqrt(e[2]*e[2]+e[3]*e[3]),e[0]<0&&(t[0]=-t[0]),e[3]<0&&(t[1]=-t[1]),t):(t[0]=1,t[1]=1,t)},l.transformCoordToLocal=function(t,e){var n=[t,e],i=this.invTransform
return i&&r.applyTransform(n,n,i),n},l.transformCoordToGlobal=function(t,e){var n=[t,e],i=this.transform
return i&&r.applyTransform(n,n,i),n},s.getLocalTransform=function(t,e){a(e=e||[])
var n=t.origin,r=t.scale||[1,1],o=t.rotation||0,s=t.position||[0,0]
return n&&(e[4]-=n[0],e[5]-=n[1]),i.scale(e,e,r),o&&i.rotate(e,e,o),n&&(e[4]+=n[0],e[5]+=n[1]),e[4]+=s[0],e[5]+=s[1],e}
var f=s
t.exports=f},function(t,e,n){var i=n(311),r=n(229),a=n(207).isArrayLike,o=Array.prototype.slice
function s(t,e){return t[e]}function l(t,e,n){t[e]=n}function u(t,e,n){return(e-t)*n+t}function h(t,e,n){return n>.5?e:t}function c(t,e,n,i,r){var a=t.length
if(1===r)for(var o=0;o<a;o++)i[o]=u(t[o],e[o],n)
else{var s=a&&t[0].length
for(o=0;o<a;o++)for(var l=0;l<s;l++)i[o][l]=u(t[o][l],e[o][l],n)}}function f(t,e,n){var i=t.length,r=e.length
if(i!==r)if(i>r)t.length=r
else for(var a=i;a<r;a++)t.push(1===n?e[a]:o.call(e[a]))
var s=t[0]&&t[0].length
for(a=0;a<t.length;a++)if(1===n)isNaN(t[a])&&(t[a]=e[a])
else for(var l=0;l<s;l++)isNaN(t[a][l])&&(t[a][l]=e[a][l])}function d(t,e,n){if(t===e)return!0
var i=t.length
if(i!==e.length)return!1
if(1===n){for(var r=0;r<i;r++)if(t[r]!==e[r])return!1}else{var a=t[0].length
for(r=0;r<i;r++)for(var o=0;o<a;o++)if(t[r][o]!==e[r][o])return!1}return!0}function p(t,e,n,i,r,a,o,s,l){var u=t.length
if(1===l)for(var h=0;h<u;h++)s[h]=g(t[h],e[h],n[h],i[h],r,a,o)
else{var c=t[0].length
for(h=0;h<u;h++)for(var f=0;f<c;f++)s[h][f]=g(t[h][f],e[h][f],n[h][f],i[h][f],r,a,o)}}function g(t,e,n,i,r,a,o){var s=.5*(n-t),l=.5*(i-e)
return(2*(e-n)+s+l)*o+(-3*(e-n)-2*s-l)*a+s*r+e}function v(t){if(a(t)){var e=t.length
if(a(t[0])){for(var n=[],i=0;i<e;i++)n.push(o.call(t[i]))
return n}return o.call(t)}return t}function m(t){return t[0]=Math.floor(t[0]),t[1]=Math.floor(t[1]),t[2]=Math.floor(t[2]),"rgba("+t.join(",")+")"}function _(t,e,n,o,s,l){var v=t._getter,_=t._setter,y="spline"===e,x=o.length
if(x){var w,b=o[0].value,S=a(b),T=!1,M=!1,C=S?function(t){var e=t[t.length-1].value
return a(e&&e[0])?2:1}(o):0
o.sort((function(t,e){return t.time-e.time})),w=o[x-1].time
for(var k=[],D=[],I=o[0].value,A=!0,O=0;O<x;O++){k.push(o[O].time/w)
var P=o[O].value
if(S&&d(P,I,C)||!S&&P===I||(A=!1),I=P,"string"==typeof P){var L=r.parse(P)
L?(P=L,T=!0):M=!0}D.push(P)}if(l||!A){var E=D[x-1]
for(O=0;O<x-1;O++)S?f(D[O],E,C):!isNaN(D[O])||isNaN(E)||M||T||(D[O]=E)
S&&f(v(t._target,s),E,C)
var R,B,N,F,z,H=0,W=0
if(T)var V=[0,0,0,0]
var U=new i({target:t._target,life:w,loop:t._loop,delay:t._delay,onframe:function(t,e){var n
if(e<0)n=0
else if(e<W){for(n=Math.min(H+1,x-1);n>=0&&!(k[n]<=e);n--);n=Math.min(n,x-2)}else{for(n=H;n<x&&!(k[n]>e);n++);n=Math.min(n-1,x-2)}H=n,W=e
var i=k[n+1]-k[n]
if(0!==i)if(R=(e-k[n])/i,y)if(N=D[n],B=D[0===n?n:n-1],F=D[n>x-2?x-1:n+1],z=D[n>x-3?x-1:n+2],S)p(B,N,F,z,R,R*R,R*R*R,v(t,s),C)
else{if(T)r=p(B,N,F,z,R,R*R,R*R*R,V,1),r=m(V)
else{if(M)return h(N,F,R)
r=g(B,N,F,z,R,R*R,R*R*R)}_(t,s,r)}else if(S)c(D[n],D[n+1],R,v(t,s),C)
else{var r
if(T)c(D[n],D[n+1],R,V,1),r=m(V)
else{if(M)return h(D[n],D[n+1],R)
r=u(D[n],D[n+1],R)}_(t,s,r)}},ondestroy:n})
return e&&"spline"!==e&&(U.easing=e),U}}}var y=function(t,e,n,i){this._tracks={},this._target=t,this._loop=e||!1,this._getter=n||s,this._setter=i||l,this._clipCount=0,this._delay=0,this._doneList=[],this._onframeList=[],this._clipList=[]}
y.prototype={when:function(t,e){var n=this._tracks
for(var i in e)if(e.hasOwnProperty(i)){if(!n[i]){n[i]=[]
var r=this._getter(this._target,i)
if(null==r)continue
0!==t&&n[i].push({time:0,value:v(r)})}n[i].push({time:t,value:e[i]})}return this},during:function(t){return this._onframeList.push(t),this},pause:function(){for(var t=0;t<this._clipList.length;t++)this._clipList[t].pause()
this._paused=!0},resume:function(){for(var t=0;t<this._clipList.length;t++)this._clipList[t].resume()
this._paused=!1},isPaused:function(){return!!this._paused},_doneCallback:function(){this._tracks={},this._clipList.length=0
for(var t=this._doneList,e=t.length,n=0;n<e;n++)t[n].call(this)},start:function(t,e){var n,i=this,r=0,a=function(){--r||i._doneCallback()}
for(var o in this._tracks)if(this._tracks.hasOwnProperty(o)){var s=_(this,t,a,this._tracks[o],o,e)
s&&(this._clipList.push(s),r++,this.animation&&this.animation.addClip(s),n=s)}if(n){var l=n.onframe
n.onframe=function(t,e){l(t,e)
for(var n=0;n<i._onframeList.length;n++)i._onframeList[n](t,e)}}return r||this._doneCallback(),this},stop:function(t){for(var e=this._clipList,n=this.animation,i=0;i<e.length;i++){var r=e[i]
t&&r.onframe(this._target,1),n&&n.removeClip(r)}e.length=0},delay:function(t){return this._delay=t,this},done:function(t){return t&&this._doneList.push(t),this},getClips:function(){return this._clipList}}
var x=y
t.exports=x},function(t,e){var n=function(){this.head=null,this.tail=null,this._len=0},i=n.prototype
i.insert=function(t){var e=new r(t)
return this.insertEntry(e),e},i.insertEntry=function(t){this.head?(this.tail.next=t,t.prev=this.tail,t.next=null,this.tail=t):this.head=this.tail=t,this._len++},i.remove=function(t){var e=t.prev,n=t.next
e?e.next=n:this.head=n,n?n.prev=e:this.tail=e,t.next=t.prev=null,this._len--},i.len=function(){return this._len},i.clear=function(){this.head=this.tail=null,this._len=0}
var r=function(t){this.value=t,this.next,this.prev},a=function(t){this._list=new n,this._map={},this._maxSize=t||10,this._lastRemovedEntry=null},o=a.prototype
o.put=function(t,e){var n=this._list,i=this._map,a=null
if(null==i[t]){var o=n.len(),s=this._lastRemovedEntry
if(o>=this._maxSize&&o>0){var l=n.head
n.remove(l),delete i[l.key],a=l.value,this._lastRemovedEntry=l}s?s.value=e:s=new r(e),s.key=t,n.insertEntry(s),i[t]=s}return a},o.get=function(t){var e=this._map[t],n=this._list
if(null!=e)return e!==n.tail&&(n.remove(e),n.insertEntry(e)),e.value},o.clear=function(){this._list.clear(),this._map={}}
var s=a
t.exports=s},function(t,e,n){var i=function(){}
1===n(234).debugMode&&(i=console.error)
var r=i
t.exports=r},function(t,e){var n={shadowBlur:1,shadowOffsetX:1,shadowOffsetY:1,textShadowBlur:1,textShadowOffsetX:1,textShadowOffsetY:1,textBoxShadowBlur:1,textBoxShadowOffsetX:1,textBoxShadowOffsetY:1}
t.exports=function(t,e,i){return n.hasOwnProperty(e)?i*t.dpr:i}},function(t,e){var n=function(t,e){this.image=t,this.repeat=e,this.type="pattern"}
n.prototype.getCanvasPattern=function(t){return t.createPattern(this.image,this.repeat||"repeat")}
var i=n
t.exports=i},function(t,e){var n="undefined"!=typeof window&&(window.requestAnimationFrame&&window.requestAnimationFrame.bind(window)||window.msRequestAnimationFrame&&window.msRequestAnimationFrame.bind(window)||window.mozRequestAnimationFrame||window.webkitRequestAnimationFrame)||function(t){setTimeout(t,16)}
t.exports=n},function(t,e,n){var i=n(207),r=i.retrieve2,a=i.retrieve3,o=i.each,s=i.normalizeCssArray,l=i.isString,u=i.isObject,h=n(217),c=n(269),f=n(244),d=n(265),p=n(235),g=p.ContextCachedBy,v=p.WILL_BE_RESTORED,m=h.DEFAULT_FONT,_={left:1,right:1,center:1},y={top:1,bottom:1,middle:1},x=[["textShadowBlur","shadowBlur",0],["textShadowOffsetX","shadowOffsetX",0],["textShadowOffsetY","shadowOffsetY",0],["textShadowColor","shadowColor","transparent"]],w={},b={}
function S(t){if(t){t.font=h.makeFont(t)
var e=t.textAlign
"middle"===e&&(e="center"),t.textAlign=null==e||_[e]?e:"left"
var n=t.textVerticalAlign||t.textBaseline
"center"===n&&(n="middle"),t.textVerticalAlign=null==n||y[n]?n:"top",t.textPadding&&(t.textPadding=s(t.textPadding))}}function T(t,e,n,i,r){if(n&&e.textRotation){var a=e.textOrigin
"center"===a?(i=n.width/2+n.x,r=n.height/2+n.y):a&&(i=a[0]+n.x,r=a[1]+n.y),t.translate(i,r),t.rotate(-e.textRotation),t.translate(-i,-r)}}function M(t,e,n,i,o,s,l,u){var h=i.rich[n.styleName]||{}
h.text=n.text
var c=n.textVerticalAlign,f=s+o/2
"top"===c?f=s+n.height/2:"bottom"===c&&(f=s+o-n.height/2),!n.isLineHolder&&C(h)&&k(t,e,h,"right"===u?l-n.width:"center"===u?l-n.width/2:l,f-n.height/2,n.width,n.height)
var d=n.textPadding
d&&(l=E(l,u,d),f-=n.height/2-d[2]-n.textHeight/2),A(e,"shadowBlur",a(h.textShadowBlur,i.textShadowBlur,0)),A(e,"shadowColor",h.textShadowColor||i.textShadowColor||"transparent"),A(e,"shadowOffsetX",a(h.textShadowOffsetX,i.textShadowOffsetX,0)),A(e,"shadowOffsetY",a(h.textShadowOffsetY,i.textShadowOffsetY,0)),A(e,"textAlign",u),A(e,"textBaseline","middle"),A(e,"font",n.font||m)
var p=O(h.textStroke||i.textStroke,v),g=P(h.textFill||i.textFill),v=r(h.textStrokeWidth,i.textStrokeWidth)
p&&(A(e,"lineWidth",v),A(e,"strokeStyle",p),e.strokeText(n.text,l,f)),g&&(A(e,"fillStyle",g),e.fillText(n.text,l,f))}function C(t){return!!(t.textBackgroundColor||t.textBorderWidth&&t.textBorderColor)}function k(t,e,n,i,r,a,o){var s=n.textBackgroundColor,h=n.textBorderWidth,d=n.textBorderColor,p=l(s)
if(A(e,"shadowBlur",n.textBoxShadowBlur||0),A(e,"shadowColor",n.textBoxShadowColor||"transparent"),A(e,"shadowOffsetX",n.textBoxShadowOffsetX||0),A(e,"shadowOffsetY",n.textBoxShadowOffsetY||0),p||h&&d){e.beginPath()
var g=n.textBorderRadius
g?c.buildPath(e,{x:i,y:r,width:a,height:o,r:g}):e.rect(i,r,a,o),e.closePath()}if(p)if(A(e,"fillStyle",s),null!=n.fillOpacity){var v=e.globalAlpha
e.globalAlpha=n.fillOpacity*n.opacity,e.fill(),e.globalAlpha=v}else e.fill()
else if(u(s)){var m=s.image;(m=f.createOrUpdateImage(m,null,t,D,s))&&f.isImageReady(m)&&e.drawImage(m,i,r,a,o)}h&&d&&(A(e,"lineWidth",h),A(e,"strokeStyle",d),null!=n.strokeOpacity?(v=e.globalAlpha,e.globalAlpha=n.strokeOpacity*n.opacity,e.stroke(),e.globalAlpha=v):e.stroke())}function D(t,e){e.image=t}function I(t,e,n,i){var r=n.x||0,a=n.y||0,o=n.textAlign,s=n.textVerticalAlign
if(i){var l=n.textPosition
if(l instanceof Array)r=i.x+L(l[0],i.width),a=i.y+L(l[1],i.height)
else{var u=e&&e.calculateTextPosition?e.calculateTextPosition(w,n,i):h.calculateTextPosition(w,n,i)
r=u.x,a=u.y,o=o||u.textAlign,s=s||u.textVerticalAlign}var c=n.textOffset
c&&(r+=c[0],a+=c[1])}return(t=t||{}).baseX=r,t.baseY=a,t.textAlign=o,t.textVerticalAlign=s,t}function A(t,e,n){return t[e]=d(t,e,n),t[e]}function O(t,e){return null==t||e<=0||"transparent"===t||"none"===t?null:t.image||t.colorStops?"#000":t}function P(t){return null==t||"none"===t?null:t.image||t.colorStops?"#000":t}function L(t,e){return"string"==typeof t?t.lastIndexOf("%")>=0?parseFloat(t)/100*e:parseFloat(t):t}function E(t,e,n){return"right"===e?t-n[1]:"center"===e?t+n[3]/2-n[1]/2:t+n[3]}e.normalizeTextStyle=function(t){return S(t),o(t.rich,S),t},e.renderText=function(t,e,n,i,r,a){i.rich?function(t,e,n,i,r,a){a!==v&&(e.__attrCachedBy=g.NONE)
var o=t.__textCotentBlock
o&&!t.__dirtyText||(o=t.__textCotentBlock=h.parseRichText(n,i)),function(t,e,n,i,r){var a=n.width,o=n.outerWidth,s=n.outerHeight,l=i.textPadding,u=I(b,t,i,r),c=u.baseX,f=u.baseY,d=u.textAlign,p=u.textVerticalAlign
T(e,i,r,c,f)
var g=h.adjustTextX(c,o,d),v=h.adjustTextY(f,s,p),m=g,_=v
l&&(m+=l[3],_+=l[0])
var y=m+a
C(i)&&k(t,e,i,g,v,o,s)
for(var x=0;x<n.lines.length;x++){for(var w,S=n.lines[x],D=S.tokens,A=D.length,O=S.lineHeight,P=S.width,L=0,E=m,R=y,B=A-1;L<A&&(!(w=D[L]).textAlign||"left"===w.textAlign);)M(t,e,w,i,O,_,E,"left"),P-=w.width,E+=w.width,L++
for(;B>=0&&"right"===(w=D[B]).textAlign;)M(t,e,w,i,O,_,R,"right"),P-=w.width,R-=w.width,B--
for(E+=(a-(E-m)-(y-R)-P)/2;L<=B;)M(t,e,w=D[L],i,O,_,E+w.width/2,"center"),E+=w.width,L++
_+=O}}(t,e,o,i,r)}(t,e,n,i,r,a):function(t,e,n,i,r,a){"use strict"
var o,s=C(i),l=!1,u=e.__attrCachedBy===g.PLAIN_TEXT
a!==v?(a&&(o=a.style,l=!s&&u&&o),e.__attrCachedBy=s?g.NONE:g.PLAIN_TEXT):u&&(e.__attrCachedBy=g.NONE)
var c=i.font||m
l&&c===(o.font||m)||(e.font=c)
var f=t.__computedFont
t.__styleFont!==c&&(t.__styleFont=c,f=t.__computedFont=e.font)
var p=i.textPadding,_=i.textLineHeight,y=t.__textCotentBlock
y&&!t.__dirtyText||(y=t.__textCotentBlock=h.parsePlainText(n,f,p,_,i.truncate))
var w=y.outerHeight,S=y.lines,M=y.lineHeight,D=I(b,t,i,r),A=D.baseX,L=D.baseY,R=D.textAlign||"left",B=D.textVerticalAlign
T(e,i,r,A,L)
var N=h.adjustTextY(L,w,B),F=A,z=N
if(s||p){var H=h.getWidth(n,f)
p&&(H+=p[1]+p[3])
var W=h.adjustTextX(A,H,R)
s&&k(t,e,i,W,N,H,w),p&&(F=E(A,R,p),z+=p[0])}e.textAlign=R,e.textBaseline="middle",e.globalAlpha=i.opacity||1
for(var V=0;V<x.length;V++){var U=x[V],Y=U[0],q=U[1],X=i[Y]
l&&X===o[Y]||(e[q]=d(e,q,X||U[2]))}z+=M/2
var G=i.textStrokeWidth,j=l?o.textStrokeWidth:null,Z=!l||G!==j,$=!l||Z||i.textStroke!==o.textStroke,K=O(i.textStroke,G),Q=P(i.textFill)
if(K&&(Z&&(e.lineWidth=G),$&&(e.strokeStyle=K)),Q&&(l&&i.textFill===o.textFill||(e.fillStyle=Q)),1===S.length)K&&e.strokeText(S[0],F,z),Q&&e.fillText(S[0],F,z)
else for(V=0;V<S.length;V++)K&&e.strokeText(S[V],F,z),Q&&e.fillText(S[V],F,z),z+=M}(t,e,n,i,r,a)},e.getBoxPosition=I,e.getStroke=O,e.getFill=P,e.parsePercent=L,e.needDrawText=function(t,e){return null!=t&&(t||e.textBackgroundColor||e.textBorderWidth&&e.textBorderColor||e.textPadding)}},function(t,e){e.buildPath=function(t,e){var n,i,r,a,o,s=e.x,l=e.y,u=e.width,h=e.height,c=e.r
u<0&&(s+=u,u=-u),h<0&&(l+=h,h=-h),"number"==typeof c?n=i=r=a=c:c instanceof Array?1===c.length?n=i=r=a=c[0]:2===c.length?(n=r=c[0],i=a=c[1]):3===c.length?(n=c[0],i=a=c[1],r=c[2]):(n=c[0],i=c[1],r=c[2],a=c[3]):n=i=r=a=0,n+i>u&&(n*=u/(o=n+i),i*=u/o),r+a>u&&(r*=u/(o=r+a),a*=u/o),i+r>h&&(i*=h/(o=i+r),r*=h/o),n+a>h&&(n*=h/(o=n+a),a*=h/o),t.moveTo(s+n,l),t.lineTo(s+u-i,l),0!==i&&t.arc(s+u-i,l+i,i,-Math.PI/2,0),t.lineTo(s+u,l+h-r),0!==r&&t.arc(s+u-r,l+h-r,r,0,Math.PI/2),t.lineTo(s+a,l+h),0!==a&&t.arc(s+a,l+h-a,a,Math.PI/2,Math.PI),t.lineTo(s,l+n),0!==n&&t.arc(s+n,l+n,n,Math.PI,1.5*Math.PI)}},function(t,e,n){n(210).__DEV__
var i=n(207),r=i.each,a=i.filter,o=i.map,s=i.isArray,l=i.indexOf,u=i.isObject,h=i.isString,c=i.createHashMap,f=i.assert,d=i.clone,p=i.merge,g=i.extend,v=i.mixin,m=n(208),_=n(218),y=n(220),x=n(338),w=n(282),b=n(230).resetSourceDefaulter,S=_.extend({init:function(t,e,n,i){n=n||{},this.option=null,this._theme=new _(n),this._optionManager=i},setOption:function(t,e){f(!("\0_ec_inner"in t),"please use chart.getOption()"),this._optionManager.setOption(t,e),this.resetOption(null)},resetOption:function(t){var e=!1,n=this._optionManager
if(!t||"recreate"===t){var i=n.mountOption("recreate"===t)
this.option&&"recreate"!==t?(this.restoreData(),this.mergeOption(i)):T.call(this,i),e=!0}if("timeline"!==t&&"media"!==t||this.restoreData(),!t||"recreate"===t||"timeline"===t){var a=n.getTimelineOption(this)
a&&(this.mergeOption(a),e=!0)}if(!t||"recreate"===t||"media"===t){var o=n.getMediaOption(this,this._api)
o.length&&r(o,(function(t){this.mergeOption(t,e=!0)}),this)}return e},mergeOption:function(t){var e=this.option,n=this._componentsMap,i=[]
b(this),r(t,(function(t,n){null!=t&&(y.hasClass(n)?n&&i.push(n):e[n]=null==e[n]?d(t):p(e[n],t,!0))})),y.topologicalTravel(i,y.getAllClassMainTypes(),(function(i,a){var o=m.normalizeToArray(t[i]),l=m.mappingToExists(n.get(i),o)
m.makeIdAndName(l),r(l,(function(t,e){var n=t.option
u(n)&&(t.keyInfo.mainType=i,t.keyInfo.subType=function(t,e,n){return e.type?e.type:n?n.subType:y.determineSubType(t,e)}(i,n,t.exist))}))
var h=function(t,e){s(e)||(e=e?[e]:[])
var n={}
return r(e,(function(e){n[e]=(t.get(e)||[]).slice()})),n}(n,a)
e[i]=[],n.set(i,[]),r(l,(function(t,r){var a=t.exist,o=t.option
if(f(u(o)||a,"Empty component definition"),o){var s=y.getClass(i,t.keyInfo.subType,!0)
if(a&&a.constructor===s)a.name=t.keyInfo.name,a.mergeOption(o,this),a.optionUpdated(o,!1)
else{var l=g({dependentModels:h,componentIndex:r},t.keyInfo)
a=new s(o,this,this,l),g(a,l),a.init(o,this,this,l),a.optionUpdated(null,!0)}}else a.mergeOption({},this),a.optionUpdated({},!1)
n.get(i)[r]=a,e[i][r]=a.option}),this),"series"===i&&M(this,n.get("series"))}),this),this._seriesIndicesMap=c(this._seriesIndices=this._seriesIndices||[])},getOption:function(){var t=d(this.option)
return r(t,(function(e,n){if(y.hasClass(n)){for(var i=(e=m.normalizeToArray(e)).length-1;i>=0;i--)m.isIdInner(e[i])&&e.splice(i,1)
t[n]=e}})),delete t["\0_ec_inner"],t},getTheme:function(){return this._theme},getComponent:function(t,e){var n=this._componentsMap.get(t)
if(n)return n[e||0]},queryComponents:function(t){var e=t.mainType
if(!e)return[]
var n,i=t.index,r=t.id,u=t.name,h=this._componentsMap.get(e)
if(!h||!h.length)return[]
if(null!=i)s(i)||(i=[i]),n=a(o(i,(function(t){return h[t]})),(function(t){return!!t}))
else if(null!=r){var c=s(r)
n=a(h,(function(t){return c&&l(r,t.id)>=0||!c&&t.id===r}))}else if(null!=u){var f=s(u)
n=a(h,(function(t){return f&&l(u,t.name)>=0||!f&&t.name===u}))}else n=h.slice()
return C(n,t)},findComponents:function(t){var e,n,i,r,o,s=t.query,l=t.mainType,u=(n=l+"Index",i=l+"Id",r=l+"Name",!(e=s)||null==e[n]&&null==e[i]&&null==e[r]?null:{mainType:l,index:e[n],id:e[i],name:e[r]})
return o=C(u?this.queryComponents(u):this._componentsMap.get(l),t),t.filter?a(o,t.filter):o},eachComponent:function(t,e,n){var i=this._componentsMap
if("function"==typeof t)n=e,e=t,i.each((function(t,i){r(t,(function(t,r){e.call(n,i,t,r)}))}))
else if(h(t))r(i.get(t),e,n)
else if(u(t)){var a=this.findComponents(t)
r(a,e,n)}},getSeriesByName:function(t){var e=this._componentsMap.get("series")
return a(e,(function(e){return e.name===t}))},getSeriesByIndex:function(t){return this._componentsMap.get("series")[t]},getSeriesByType:function(t){var e=this._componentsMap.get("series")
return a(e,(function(e){return e.subType===t}))},getSeries:function(){return this._componentsMap.get("series").slice()},getSeriesCount:function(){return this._componentsMap.get("series").length},eachSeries:function(t,e){r(this._seriesIndices,(function(n){var i=this._componentsMap.get("series")[n]
t.call(e,i,n)}),this)},eachRawSeries:function(t,e){r(this._componentsMap.get("series"),t,e)},eachSeriesByType:function(t,e,n){r(this._seriesIndices,(function(i){var r=this._componentsMap.get("series")[i]
r.subType===t&&e.call(n,r,i)}),this)},eachRawSeriesByType:function(t,e,n){return r(this.getSeriesByType(t),e,n)},isSeriesFiltered:function(t){return null==this._seriesIndicesMap.get(t.componentIndex)},getCurrentSeriesIndices:function(){return(this._seriesIndices||[]).slice()},filterSeries:function(t,e){M(this,a(this._componentsMap.get("series"),t,e))},restoreData:function(t){var e=this._componentsMap
M(this,e.get("series"))
var n=[]
e.each((function(t,e){n.push(e)})),y.topologicalTravel(n,y.getAllClassMainTypes(),(function(n,i){r(e.get(n),(function(e){("series"!==n||!function(t,e){if(e){var n=e.seiresIndex,i=e.seriesId,r=e.seriesName
return null!=n&&t.componentIndex!==n||null!=i&&t.id!==i||null!=r&&t.name!==r}}(e,t))&&e.restoreData()}))}))}})
function T(t){var e,n,i
t=t,this.option={},this.option["\0_ec_inner"]=1,this._componentsMap=c({series:[]}),this._seriesIndices,this._seriesIndicesMap,e=t,n=this._theme.option,i=e.color&&!e.colorLayer,r(n,(function(t,n){"colorLayer"===n&&i||y.hasClass(n)||("object"==typeof t?e[n]=e[n]?p(e[n],t,!1):d(t):null==e[n]&&(e[n]=t))})),p(t,x,!1),this.mergeOption(t)}function M(t,e){t._seriesIndicesMap=c(t._seriesIndices=o(e,(function(t){return t.componentIndex}))||[])}function C(t,e){return e.hasOwnProperty("subType")?a(t,(function(t){return t.subType===e.subType})):t}v(S,w)
var k=S
t.exports=k},function(t,e,n){var i=n(213),r=n(237),a=n(326),o=Math.sqrt,s=Math.sin,l=Math.cos,u=Math.PI,h=function(t){return Math.sqrt(t[0]*t[0]+t[1]*t[1])},c=function(t,e){return(t[0]*e[0]+t[1]*e[1])/(h(t)*h(e))},f=function(t,e){return(t[0]*e[1]<t[1]*e[0]?-1:1)*Math.acos(c(t,e))}
function d(t,e,n,i,r,a,h,d,p,g,v){var m=p*(u/180),_=l(m)*(t-n)/2+s(m)*(e-i)/2,y=-1*s(m)*(t-n)/2+l(m)*(e-i)/2,x=_*_/(h*h)+y*y/(d*d)
x>1&&(h*=o(x),d*=o(x))
var w=(r===a?-1:1)*o((h*h*(d*d)-h*h*(y*y)-d*d*(_*_))/(h*h*(y*y)+d*d*(_*_)))||0,b=w*h*y/d,S=w*-d*_/h,T=(t+n)/2+l(m)*b-s(m)*S,M=(e+i)/2+s(m)*b+l(m)*S,C=f([1,0],[(_-b)/h,(y-S)/d]),k=[(_-b)/h,(y-S)/d],D=[(-1*_-b)/h,(-1*y-S)/d],I=f(k,D)
c(k,D)<=-1&&(I=u),c(k,D)>=1&&(I=0),0===a&&I>0&&(I-=2*u),1===a&&I<0&&(I+=2*u),v.addData(g,T,M,h,d,C,I,m,a)}var p=/([mlvhzcqtsa])([^mlvhzcqtsa]*)/gi,g=/-?([0-9]*\.)?[0-9]+([eE]-?[0-9]+)?/g
function v(t,e){var n=function(t){if(!t)return new r
for(var e,n=0,i=0,a=n,o=i,s=new r,l=r.CMD,u=t.match(p),h=0;h<u.length;h++){for(var c,f=u[h],v=f.charAt(0),m=f.match(g)||[],_=m.length,y=0;y<_;y++)m[y]=parseFloat(m[y])
for(var x=0;x<_;){var w,b,S,T,M,C,k,D=n,I=i
switch(v){case"l":n+=m[x++],i+=m[x++],c=l.L,s.addData(c,n,i)
break
case"L":n=m[x++],i=m[x++],c=l.L,s.addData(c,n,i)
break
case"m":n+=m[x++],i+=m[x++],c=l.M,s.addData(c,n,i),a=n,o=i,v="l"
break
case"M":n=m[x++],i=m[x++],c=l.M,s.addData(c,n,i),a=n,o=i,v="L"
break
case"h":n+=m[x++],c=l.L,s.addData(c,n,i)
break
case"H":n=m[x++],c=l.L,s.addData(c,n,i)
break
case"v":i+=m[x++],c=l.L,s.addData(c,n,i)
break
case"V":i=m[x++],c=l.L,s.addData(c,n,i)
break
case"C":c=l.C,s.addData(c,m[x++],m[x++],m[x++],m[x++],m[x++],m[x++]),n=m[x-2],i=m[x-1]
break
case"c":c=l.C,s.addData(c,m[x++]+n,m[x++]+i,m[x++]+n,m[x++]+i,m[x++]+n,m[x++]+i),n+=m[x-2],i+=m[x-1]
break
case"S":w=n,b=i
var A=s.len(),O=s.data
e===l.C&&(w+=n-O[A-4],b+=i-O[A-3]),c=l.C,D=m[x++],I=m[x++],n=m[x++],i=m[x++],s.addData(c,w,b,D,I,n,i)
break
case"s":w=n,b=i,A=s.len(),O=s.data,e===l.C&&(w+=n-O[A-4],b+=i-O[A-3]),c=l.C,D=n+m[x++],I=i+m[x++],n+=m[x++],i+=m[x++],s.addData(c,w,b,D,I,n,i)
break
case"Q":D=m[x++],I=m[x++],n=m[x++],i=m[x++],c=l.Q,s.addData(c,D,I,n,i)
break
case"q":D=m[x++]+n,I=m[x++]+i,n+=m[x++],i+=m[x++],c=l.Q,s.addData(c,D,I,n,i)
break
case"T":w=n,b=i,A=s.len(),O=s.data,e===l.Q&&(w+=n-O[A-4],b+=i-O[A-3]),n=m[x++],i=m[x++],c=l.Q,s.addData(c,w,b,n,i)
break
case"t":w=n,b=i,A=s.len(),O=s.data,e===l.Q&&(w+=n-O[A-4],b+=i-O[A-3]),n+=m[x++],i+=m[x++],c=l.Q,s.addData(c,w,b,n,i)
break
case"A":S=m[x++],T=m[x++],M=m[x++],C=m[x++],k=m[x++],d(D=n,I=i,n=m[x++],i=m[x++],C,k,S,T,M,c=l.A,s)
break
case"a":S=m[x++],T=m[x++],M=m[x++],C=m[x++],k=m[x++],d(D=n,I=i,n+=m[x++],i+=m[x++],C,k,S,T,M,c=l.A,s)}}"z"!==v&&"Z"!==v||(c=l.Z,s.addData(c),n=a,i=o),e=c}return s.toStatic(),s}(t)
return(e=e||{}).buildPath=function(t){if(t.setData)t.setData(n.data),(e=t.getContext())&&t.rebuildPath(e)
else{var e=t
n.rebuildPath(e)}},e.applyTransform=function(t){a(n,t),this.dirty(!0)},e}e.createFromString=function(t,e){return new i(v(t,e))},e.extendFromString=function(t,e){return i.extend(v(t,e))},e.mergePath=function(t,e){for(var n=[],r=t.length,a=0;a<r;a++){var o=t[a]
o.path||o.createPathProxy(),o.__dirtyPath&&o.buildPath(o.path,o.shape,!0),n.push(o.path)}var s=new i(e)
return s.createPathProxy(),s.buildPath=function(t){t.appendPath(n)
var e=t.getContext()
e&&t.rebuildPath(e)},s}},function(t,e){var n=2*Math.PI
e.normalizeRadian=function(t){return(t%=n)<0&&(t+=n),t}},function(t,e){t.exports=function(t,e,n,i,r,a){if(a>e&&a>i||a<e&&a<i)return 0
if(i===e)return 0
var o=i<e?1:-1,s=(a-e)/(i-e)
1!==s&&0!==s||(o=i<e?.5:-.5)
var l=s*(n-t)+t
return l===r?1/0:l>r?o:0}},function(t,e,n){var i=n(213).extend({type:"circle",shape:{cx:0,cy:0,r:0},buildPath:function(t,e,n){n&&t.moveTo(e.cx+e.r,e.cy),t.arc(e.cx,e.cy,e.r,0,2*Math.PI,!0)}})
t.exports=i},function(t,e,n){var i=n(211),r=[["shadowBlur",0],["shadowColor","#000"],["shadowOffsetX",0],["shadowOffsetY",0]]
t.exports=function(t){return i.browser.ie&&i.browser.version>=11?function(){var e,n=this.__clipPaths,i=this.style
if(n)for(var a=0;a<n.length;a++){var o=n[a],s=o&&o.shape,l=o&&o.type
if(s&&("sector"===l&&s.startAngle===s.endAngle||"rect"===l&&(!s.width||!s.height))){for(var u=0;u<r.length;u++)r[u][2]=i[r[u][0]],i[r[u][0]]=r[u][1]
e=!0
break}}if(t.apply(this,arguments),e)for(u=0;u<r.length;u++)i[r[u][0]]=r[u][2]}:t}},function(t,e,n){var i=n(213),r=n(277),a=i.extend({type:"polygon",shape:{points:null,smooth:!1,smoothConstraint:null},buildPath:function(t,e){r.buildPath(t,e,!0)}})
t.exports=a},function(t,e,n){var i=n(329),r=n(330)
e.buildPath=function(t,e,n){var a=e.points,o=e.smooth
if(a&&a.length>=2){if(o&&"spline"!==o){var s=r(a,o,n,e.smoothConstraint)
t.moveTo(a[0][0],a[0][1])
for(var l=a.length,u=0;u<(n?l:l-1);u++){var h=s[2*u],c=s[2*u+1],f=a[(u+1)%l]
t.bezierCurveTo(h[0],h[1],c[0],c[1],f[0],f[1])}}else{"spline"===o&&(a=i(a,n)),t.moveTo(a[0][0],a[0][1]),u=1
for(var d=a.length;u<d;u++)t.lineTo(a[u][0],a[u][1])}n&&t.closePath()}}},function(t,e,n){var i=n(213),r=n(277),a=i.extend({type:"polyline",shape:{points:null,smooth:!1,smoothConstraint:null},style:{stroke:"#000",fill:null},buildPath:function(t,e){r.buildPath(t,e,!1)}})
t.exports=a},function(t,e,n){var i=n(213),r=n(269),a=n(248).subPixelOptimizeRect,o={},s=i.extend({type:"rect",shape:{r:0,x:0,y:0,width:0,height:0},buildPath:function(t,e){var n,i,s,l
this.subPixelOptimize?(a(o,e,this.style),n=o.x,i=o.y,s=o.width,l=o.height,o.r=e.r,e=o):(n=e.x,i=e.y,s=e.width,l=e.height),e.r?r.buildPath(t,e):t.rect(n,i,s,l),t.closePath()}})
t.exports=s},function(t,e,n){var i=n(213),r=n(248).subPixelOptimizeLine,a={},o=i.extend({type:"line",shape:{x1:0,y1:0,x2:0,y2:0,percent:1},style:{stroke:"#000",fill:null},buildPath:function(t,e){var n,i,o,s
this.subPixelOptimize?(r(a,e,this.style),n=a.x1,i=a.y1,o=a.x2,s=a.y2):(n=e.x1,i=e.y1,o=e.x2,s=e.y2)
var l=e.percent
0!==l&&(t.moveTo(n,i),l<1&&(o=n*(1-l)+o*l,s=i*(1-l)+s*l),t.lineTo(o,s))},pointAt:function(t){var e=this.shape
return[e.x1*(1-t)+e.x2*t,e.y1*(1-t)+e.y2*t]}})
t.exports=o},function(t,e,n){var i=n(207),r=n(249),a=function(t,e,n,i,a,o){this.x=null==t?0:t,this.y=null==e?0:e,this.x2=null==n?1:n,this.y2=null==i?0:i,this.type="linear",this.global=o||!1,r.call(this,a)}
a.prototype={constructor:a},i.inherits(a,r)
var o=a
t.exports=o},function(t,e,n){var i=n(208),r=i.makeInner,a=i.normalizeToArray,o=r(),s={clearColorPalette:function(){o(this).colorIdx=0,o(this).colorNameMap={}},getColorFromPalette:function(t,e,n){var i=o(e=e||this),r=i.colorIdx||0,s=i.colorNameMap=i.colorNameMap||{}
if(s.hasOwnProperty(t))return s[t]
var l=a(this.get("color",!0)),u=this.get("colorLayer",!0),h=null!=n&&u?function(t,e){for(var n=t.length,i=0;i<n;i++)if(t[i].length>e)return t[i]
return t[n-1]}(u,n):l
if((h=h||l)&&h.length){var c=h[r]
return t&&(s[t]=c),i.colorIdx=(r+1)%h.length,c}}}
t.exports=s},function(t,e,n){var i=n(207),r=["getDom","getZr","getWidth","getHeight","getDevicePixelRatio","dispatchAction","isDisposed","on","off","getDataURL","getConnectedDataURL","getModel","getOption","getViewOfComponentModel","getViewOfSeriesModel"]
t.exports=function(t){i.each(r,(function(e){this[e]=i.bind(t[e],t)}),this)}},function(t,e,n){n(210).__DEV__
var i=n(207),r=n(211),a=n(216),o=a.formatTime,s=a.encodeHTML,l=a.addCommas,u=a.getTooltipMarker,h=n(208),c=n(220),f=n(282),d=n(343),p=n(224),g=p.getLayoutParams,v=p.mergeLayoutParam,m=n(251).createTask,_=n(230),y=_.prepareSource,x=_.getSource,w=n(233).retrieveRawValue,b=h.makeInner(),S=c.extend({type:"series.__base__",seriesIndex:0,coordinateSystem:null,defaultOption:null,legendVisualProvider:null,visualColorAccessPath:"itemStyle.color",visualBorderColorAccessPath:"itemStyle.borderColor",layoutMode:null,init:function(t,e,n,i){this.seriesIndex=this.componentIndex,this.dataTask=m({count:M,reset:C}),this.dataTask.context={model:this},this.mergeDefaultAndTheme(t,n),y(this)
var r=this.getInitialData(t,n)
D(r,this),this.dataTask.context.data=r,b(this).dataBeforeProcessed=r,T(this)},mergeDefaultAndTheme:function(t,e){var n=this.layoutMode,r=n?g(t):{},a=this.subType
c.hasClass(a)&&(a+="Series"),i.merge(t,e.getTheme().get(this.subType)),i.merge(t,this.getDefaultOption()),h.defaultEmphasis(t,"label",["show"]),this.fillDataTextStyle(t.data),n&&v(t,r,n)},mergeOption:function(t,e){t=i.merge(this.option,t,!0),this.fillDataTextStyle(t.data)
var n=this.layoutMode
n&&v(this.option,t,n),y(this)
var r=this.getInitialData(t,e)
D(r,this),this.dataTask.dirty(),this.dataTask.context.data=r,b(this).dataBeforeProcessed=r,T(this)},fillDataTextStyle:function(t){if(t&&!i.isTypedArray(t))for(var e=["show"],n=0;n<t.length;n++)t[n]&&t[n].label&&h.defaultEmphasis(t[n],"label",e)},getInitialData:function(){},appendData:function(t){this.getRawData().appendData(t.data)},getData:function(t){var e=A(this)
if(e){var n=e.context.data
return null==t?n:n.getLinkedData(t)}return b(this).data},setData:function(t){var e=A(this)
if(e){var n=e.context
n.data!==t&&e.modifyOutputEnd&&e.setOutputEnd(t.count()),n.outputData=t,e!==this.dataTask&&(n.data=t)}b(this).data=t},getSource:function(){return x(this)},getRawData:function(){return b(this).dataBeforeProcessed},getBaseAxis:function(){var t=this.coordinateSystem
return t&&t.getBaseAxis&&t.getBaseAxis()},formatTooltip:function(t,e,n,r){var a=this,c="html"===(r=r||"html")?"<br/>":"\n",f="richText"===r,d={},p=0
var g=this.getData(),v=g.mapDimension("defaultedTooltip",!0),m=v.length,_=this.getRawValue(t),y=i.isArray(_),x=g.getItemVisual(t,"color")
i.isObject(x)&&x.colorStops&&(x=(x.colorStops[0]||{}).color),x=x||"transparent"
var b=(m>1||y&&!m?function(n){var h=i.reduce(n,(function(t,e,n){var i=g.getDimensionInfo(n)
return t|(i&&!1!==i.tooltip&&null!=i.displayName)}),0),c=[]
function m(t,n){var i=g.getDimensionInfo(n)
if(i&&!1!==i.otherDims.tooltip){var v=i.type,m="sub"+a.seriesIndex+"at"+p,_=u({color:x,type:"subItem",renderMode:r,markerId:m}),y="string"==typeof _?_:_.content,w=(h?y+s(i.displayName||"-")+": ":"")+s("ordinal"===v?t+"":"time"===v?e?"":o("yyyy/MM/dd hh:mm:ss",t):l(t))
w&&c.push(w),f&&(d[m]=x,++p)}}v.length?i.each(v,(function(e){m(w(g,t,e),e)})):i.each(n,m)
var _=h?f?"\n":"<br/>":"",y=_+c.join(_||", ")
return{renderMode:r,content:y,style:d}}(_):function(t){return{renderMode:r,content:s(l(t)),style:d}}(m?w(g,t,v[0]):y?_[0]:_)).content,S=a.seriesIndex+"at"+p,T=u({color:x,type:"item",renderMode:r,markerId:S})
d[S]=x,++p
var M=g.getName(t),C=this.name
h.isNameSpecified(this)||(C=""),C=C?s(C)+(e?": ":c):""
var k="string"==typeof T?T:T.content
return{html:e?k+C+b:C+k+(M?s(M)+": "+b:b),markers:d}},isAnimationEnabled:function(){if(r.node)return!1
var t=this.getShallow("animation")
return t&&this.getData().count()>this.getShallow("animationThreshold")&&(t=!1),t},restoreData:function(){this.dataTask.dirty()},getColorFromPalette:function(t,e,n){var i=this.ecModel,r=f.getColorFromPalette.call(this,t,e,n)
return r||(r=i.getColorFromPalette(t,e,n)),r},coordDimToDataDim:function(t){return this.getRawData().mapDimension(t,!0)},getProgressive:function(){return this.get("progressive")},getProgressiveThreshold:function(){return this.get("progressiveThreshold")},getAxisTooltipData:null,getTooltipPosition:null,pipeTask:null,preventIncremental:null,pipelineContext:null})
function T(t){var e=t.name
h.isNameSpecified(t)||(t.name=function(t){var e=t.getRawData(),n=e.mapDimension("seriesName",!0),r=[]
return i.each(n,(function(t){var n=e.getDimensionInfo(t)
n.displayName&&r.push(n.displayName)})),r.join(" ")}(t)||e)}function M(t){return t.model.getRawData().count()}function C(t){var e=t.model
return e.setData(e.getRawData().cloneShallow()),k}function k(t,e){e.outputData&&t.end>e.outputData.count()&&e.model.getRawData().cloneShallow(e.outputData)}function D(t,e){i.each(t.CHANGABLE_METHODS,(function(n){t.wrapMethod(n,i.curry(I,e))}))}function I(t){var e=A(t)
e&&e.setOutputEnd(this.count())}function A(t){var e=(t.ecModel||{}).scheduler,n=e&&e.getPipeline(t.uid)
if(n){var i=n.currentTask
if(i){var r=i.agentStubMap
r&&(i=r.get(t.uid))}return i}}i.mixin(S,d),i.mixin(S,f)
var O=S
t.exports=O},function(t,e,n){var i=n(228),r=n(238),a=n(219),o=function(){this.group=new i,this.uid=r.getUID("viewComponent")},s=o.prototype={constructor:o,init:function(t,e){},render:function(t,e,n,i){},dispose:function(){},filterForExposedEvent:null}
s.updateView=s.updateLayout=s.updateVisual=function(t,e,n,i){},a.enableClassExtend(o),a.enableClassManagement(o,{registerWhenExtend:!0})
var l=o
t.exports=l},function(t,e,n){var i=n(207).each,r=n(228),a=n(238),o=n(219),s=n(208),l=n(209),u=n(251).createTask,h=n(252),c=s.makeInner(),f=h()
function d(){this.group=new r,this.uid=a.getUID("viewChart"),this.renderTask=u({plan:m,reset:_}),this.renderTask.context={view:this}}d.prototype={type:"chart",init:function(t,e){},render:function(t,e,n,i){},highlight:function(t,e,n,i){v(t.getData(),i,"emphasis")},downplay:function(t,e,n,i){v(t.getData(),i,"normal")},remove:function(t,e){this.group.removeAll()},dispose:function(){},incrementalPrepareRender:null,incrementalRender:null,updateTransform:null,filterForExposedEvent:null}
var p=d.prototype
function g(t,e,n){if(t&&(t.trigger(e,n),t.isGroup&&!l.isHighDownDispatcher(t)))for(var i=0,r=t.childCount();i<r;i++)g(t.childAt(i),e,n)}function v(t,e,n){var r=s.queryDataIndex(t,e),a=e&&null!=e.highlightKey?l.getHighlightDigit(e.highlightKey):null
null!=r?i(s.normalizeToArray(r),(function(e){g(t.getItemGraphicEl(e),n,a)})):t.eachItemGraphicEl((function(t){g(t,n,a)}))}function m(t){return f(t.model)}function _(t){var e=t.model,n=t.ecModel,i=t.api,r=t.payload,a=e.pipelineContext.progressiveRender,o=t.view,s=r&&c(r).updateMethod,l=a?"incrementalPrepareRender":s&&o[s]?s:"render"
return"render"!==l&&o[l](e,n,i,r),y[l]}p.updateView=p.updateLayout=p.updateVisual=function(t,e,n,i){this.render(t,e,n,i)},o.enableClassExtend(d,["dispose"]),o.enableClassManagement(d,{registerWhenExtend:!0}),d.markUpdateMethod=function(t,e){c(t).updateMethod=e}
var y={incrementalPrepareRender:{progress:function(t,e){e.view.incrementalRender(t,e.model,e.ecModel,e.api,e.payload)}},render:{forceFirstProgress:!0,progress:function(t,e){e.view.render(e.model,e.ecModel,e.api,e.payload)}}},x=d
t.exports=x},function(t,e,n){var i=n(207),r=n(288),a=n(290),o=n(232).SOURCE_FORMAT_ORIGINAL,s=n(254).getDimensionTypeByAxis,l=n(208).getDataItemValue,u=n(250),h=n(358).getCoordSysInfoBySeries,c=n(231),f=n(225).enableDataStack,d=n(230).makeSeriesEncodeForAxisCoordSys
t.exports=function(t,e,n){n=n||{},c.isInstance(t)||(t=c.seriesDataToSource(t))
var p,g=e.get("coordinateSystem"),v=u.get(g),m=h(e)
m&&(p=i.map(m.coordSysDims,(function(t){var e={name:t},n=m.axisMap.get(t)
if(n){var i=n.get("type")
e.type=s(i)}return e}))),p||(p=v&&(v.getDimensionsInfo?v.getDimensionsInfo():v.dimensions.slice())||["x","y"])
var _,y,x=a(t,{coordDimensions:p,generateCoord:n.generateCoord,encodeDefaulter:n.useEncodeDefaulter?i.curry(d,p,e):null})
m&&i.each(x,(function(t,e){var n=t.coordDim,i=m.categoryAxisMap.get(n)
i&&(null==_&&(_=e),t.ordinalMeta=i.getOrdinalMeta()),null!=t.otherDims.itemName&&(y=!0)})),y||null==_||(x[_].otherDims.itemName=0)
var w=f(e,x),b=new r(x,e)
b.setCalculationInfo(w)
var S=null!=_&&function(t){if(t.sourceFormat===o){var e=function(t){for(var e=0;e<t.length&&null==t[e];)e++
return t[e]}(t.data||[])
return null!=e&&!i.isArray(l(e))}}(t)?function(t,e,n,i){return i===_?n:this.defaultDimValueGetter(t,e,n,i)}:null
return b.hasItemOption=!1,b.initData(t,null,S),b}},function(t,e,n){n(210).__DEV__
var i=n(207),r=n(218),a=n(357),o=n(231),s=n(233),l=s.defaultDimValueGetters,u=s.DefaultDataProvider,h=n(254).summarizeDimensions,c=n(289),f=i.isObject,d={float:"undefined"==typeof Float64Array?Array:Float64Array,int:"undefined"==typeof Int32Array?Array:Int32Array,ordinal:Array,number:Array,time:Array},p="undefined"==typeof Uint32Array?Array:Uint32Array,g="undefined"==typeof Int32Array?Array:Int32Array,v="undefined"==typeof Uint16Array?Array:Uint16Array
function m(t){return t._rawCount>65535?p:v}var _=["hasItemOption","_nameList","_idList","_invertedIndicesMap","_rawData","_chunkSize","_chunkCount","_dimValueGetter","_count","_rawCount","_nameDimIdx","_idDimIdx"],y=["_extent","_approximateExtent","_rawExtent"]
function x(t,e){i.each(_.concat(e.__wrappedMethods||[]),(function(n){e.hasOwnProperty(n)&&(t[n]=e[n])})),t.__wrappedMethods=e.__wrappedMethods,i.each(y,(function(n){t[n]=i.clone(e[n])})),t._calculationInfo=i.extend(e._calculationInfo)}var w=function(t,e){t=t||["x","y"]
for(var n={},r=[],a={},o=0;o<t.length;o++){var s=t[o]
i.isString(s)?s=new c({name:s}):s instanceof c||(s=new c(s))
var l=s.name
s.type=s.type||"float",s.coordDim||(s.coordDim=l,s.coordDimIndex=0),s.otherDims=s.otherDims||{},r.push(l),n[l]=s,s.index=o,s.createInvertedIndices&&(a[l]=[])}this.dimensions=r,this._dimensionInfos=n,this.hostModel=e,this.dataType,this._indices=null,this._count=0,this._rawCount=0,this._storage={},this._nameList=[],this._idList=[],this._optionModels=[],this._visual={},this._layout={},this._itemVisuals=[],this.hasItemVisual={},this._itemLayouts=[],this._graphicEls=[],this._chunkSize=1e5,this._chunkCount=0,this._rawData,this._rawExtent={},this._extent={},this._approximateExtent={},this._dimensionsSummary=h(this),this._invertedIndicesMap=a,this._calculationInfo={},this.userOutput=this._dimensionsSummary.userOutput},b=w.prototype
function S(t,e,n,i,r){var a=d[e.type],o=i-1,s=e.name,l=t[s][o]
if(l&&l.length<n){for(var u=new a(Math.min(r-o*n,n)),h=0;h<l.length;h++)u[h]=l[h]
t[s][o]=u}for(var c=i*n;c<r;c+=n)t[s].push(new a(Math.min(r-c,n)))}function T(t){var e=t._invertedIndicesMap
i.each(e,(function(n,i){var r=t._dimensionInfos[i].ordinalMeta
if(r){n=e[i]=new g(r.categories.length)
for(var a=0;a<n.length;a++)n[a]=-1
for(a=0;a<t._count;a++)n[t.get(i,a)]=a}}))}function M(t,e,n){var i
if(null!=e){var r=t._chunkSize,a=Math.floor(n/r),o=n%r,s=t.dimensions[e],l=t._storage[s][a]
if(l){i=l[o]
var u=t._dimensionInfos[s].ordinalMeta
u&&u.categories.length&&(i=u.categories[i])}}return i}function C(t){return t}function k(t){return t<this._count&&t>=0?this._indices[t]:-1}function D(t,e){var n=t._idList[e]
return null==n&&(n=M(t,t._idDimIdx,e)),null==n&&(n="e\0\0"+e),n}function I(t){return i.isArray(t)||(t=[t]),t}function A(t,e){var n=t.dimensions,r=new w(i.map(n,t.getDimensionInfo,t),t.hostModel)
x(r,t)
for(var a=r._storage={},o=t._storage,s=0;s<n.length;s++){var l=n[s]
o[l]&&(i.indexOf(e,l)>=0?(a[l]=O(o[l]),r._rawExtent[l]=[1/0,-1/0],r._extent[l]=null):a[l]=o[l])}return r}function O(t){for(var e,n,i=new Array(t.length),r=0;r<t.length;r++)i[r]=(n=void 0,(n=(e=t[r]).constructor)===Array?e.slice():new n(e))
return i}b.type="list",b.hasItemOption=!0,b.getDimension=function(t){return"number"!=typeof t&&(isNaN(t)||this._dimensionInfos.hasOwnProperty(t))||(t=this.dimensions[t]),t},b.getDimensionInfo=function(t){return this._dimensionInfos[this.getDimension(t)]},b.getDimensionsOnCoord=function(){return this._dimensionsSummary.dataDimsOnCoord.slice()},b.mapDimension=function(t,e){var n=this._dimensionsSummary
if(null==e)return n.encodeFirstDimNotExtra[t]
var i=n.encode[t]
return!0===e?(i||[]).slice():i&&i[e]},b.initData=function(t,e,n){(o.isInstance(t)||i.isArrayLike(t))&&(t=new u(t,this.dimensions.length)),this._rawData=t,this._storage={},this._indices=null,this._nameList=e||[],this._idList=[],this._nameRepeatCount={},n||(this.hasItemOption=!1),this.defaultDimValueGetter=l[this._rawData.getSource().sourceFormat],this._dimValueGetter=n=n||this.defaultDimValueGetter,this._dimValueGetterArrayRows=l.arrayRows,this._rawExtent={},this._initDataFromProvider(0,t.count()),t.pure&&(this.hasItemOption=!1)},b.getProvider=function(){return this._rawData},b.appendData=function(t){var e=this._rawData,n=this.count()
e.appendData(t)
var i=e.count()
e.persistent||(i+=n),this._initDataFromProvider(n,i)},b.appendValues=function(t,e){for(var n=this._chunkSize,i=this._storage,r=this.dimensions,a=r.length,o=this._rawExtent,s=this.count(),l=s+Math.max(t.length,e?e.length:0),u=this._chunkCount,h=0;h<a;h++)o[m=r[h]]||(o[m]=[1/0,-1/0]),i[m]||(i[m]=[]),S(i,this._dimensionInfos[m],n,u,l),this._chunkCount=i[m].length
for(var c=new Array(a),f=s;f<l;f++){for(var d=f-s,p=Math.floor(f/n),g=f%n,v=0;v<a;v++){var m=r[v],_=this._dimValueGetterArrayRows(t[d]||c,m,d,v)
i[m][p][g]=_
var y=o[m]
_<y[0]&&(y[0]=_),_>y[1]&&(y[1]=_)}e&&(this._nameList[f]=e[d])}this._rawCount=this._count=l,this._extent={},T(this)},b._initDataFromProvider=function(t,e){if(!(t>=e)){for(var n,i=this._chunkSize,r=this._rawData,a=this._storage,o=this.dimensions,s=o.length,l=this._dimensionInfos,u=this._nameList,h=this._idList,c=this._rawExtent,f=this._nameRepeatCount={},d=this._chunkCount,p=0;p<s;p++){c[w=o[p]]||(c[w]=[1/0,-1/0])
var g=l[w]
0===g.otherDims.itemName&&(n=this._nameDimIdx=p),0===g.otherDims.itemId&&(this._idDimIdx=p),a[w]||(a[w]=[]),S(a,g,i,d,e),this._chunkCount=a[w].length}for(var v=new Array(s),m=t;m<e;m++){v=r.getItem(m,v)
for(var _=Math.floor(m/i),y=m%i,x=0;x<s;x++){var w,b=a[w=o[x]][_],M=this._dimValueGetter(v,w,m,x)
b[y]=M
var C=c[w]
M<C[0]&&(C[0]=M),M>C[1]&&(C[1]=M)}if(!r.pure){var k=u[m]
if(v&&null==k)if(null!=v.name)u[m]=k=v.name
else if(null!=n){var D=o[n],I=a[D][_]
if(I){k=I[y]
var A=l[D].ordinalMeta
A&&A.categories.length&&(k=A.categories[k])}}var O=null==v?null:v.id
null==O&&null!=k&&(f[k]=f[k]||0,O=k,f[k]>0&&(O+="__ec__"+f[k]),f[k]++),null!=O&&(h[m]=O)}}!r.persistent&&r.clean&&r.clean(),this._rawCount=this._count=e,this._extent={},T(this)}},b.count=function(){return this._count},b.getIndices=function(){var t=this._indices
if(t){var e=t.constructor,n=this._count
if(e===Array){r=new e(n)
for(var i=0;i<n;i++)r[i]=t[i]}else r=new e(t.buffer,0,n)}else{var r=new(e=m(this))(this.count())
for(i=0;i<r.length;i++)r[i]=i}return r},b.get=function(t,e){if(!(e>=0&&e<this._count))return NaN
var n=this._storage
if(!n[t])return NaN
e=this.getRawIndex(e)
var i=Math.floor(e/this._chunkSize),r=e%this._chunkSize
return n[t][i][r]},b.getByRawIndex=function(t,e){if(!(e>=0&&e<this._rawCount))return NaN
var n=this._storage[t]
if(!n)return NaN
var i=Math.floor(e/this._chunkSize),r=e%this._chunkSize
return n[i][r]},b._getFast=function(t,e){var n=Math.floor(e/this._chunkSize),i=e%this._chunkSize
return this._storage[t][n][i]},b.getValues=function(t,e){var n=[]
i.isArray(t)||(e=t,t=this.dimensions)
for(var r=0,a=t.length;r<a;r++)n.push(this.get(t[r],e))
return n},b.hasValue=function(t){for(var e=this._dimensionsSummary.dataDimsOnCoord,n=0,i=e.length;n<i;n++)if(isNaN(this.get(e[n],t)))return!1
return!0},b.getDataExtent=function(t){t=this.getDimension(t)
var e=[1/0,-1/0]
if(!this._storage[t])return e
var n,i=this.count()
if(!this._indices)return this._rawExtent[t].slice()
if(n=this._extent[t])return n.slice()
for(var r=(n=e)[0],a=n[1],o=0;o<i;o++){var s=this._getFast(t,this.getRawIndex(o))
s<r&&(r=s),s>a&&(a=s)}return n=[r,a],this._extent[t]=n,n},b.getApproximateExtent=function(t){return t=this.getDimension(t),this._approximateExtent[t]||this.getDataExtent(t)},b.setApproximateExtent=function(t,e){e=this.getDimension(e),this._approximateExtent[e]=t.slice()},b.getCalculationInfo=function(t){return this._calculationInfo[t]},b.setCalculationInfo=function(t,e){f(t)?i.extend(this._calculationInfo,t):this._calculationInfo[t]=e},b.getSum=function(t){var e=0
if(this._storage[t])for(var n=0,i=this.count();n<i;n++){var r=this.get(t,n)
isNaN(r)||(e+=r)}return e},b.getMedian=function(t){var e=[]
this.each(t,(function(t,n){isNaN(t)||e.push(t)}))
var n=[].concat(e).sort((function(t,e){return t-e})),i=this.count()
return 0===i?0:i%2==1?n[(i-1)/2]:(n[i/2]+n[i/2-1])/2},b.rawIndexOf=function(t,e){var n=(t&&this._invertedIndicesMap[t])[e]
return null==n||isNaN(n)?-1:n},b.indexOfName=function(t){for(var e=0,n=this.count();e<n;e++)if(this.getName(e)===t)return e
return-1},b.indexOfRawIndex=function(t){if(t>=this._rawCount||t<0)return-1
if(!this._indices)return t
var e=this._indices,n=e[t]
if(null!=n&&n<this._count&&n===t)return t
for(var i=0,r=this._count-1;i<=r;){var a=(i+r)/2|0
if(e[a]<t)i=a+1
else{if(!(e[a]>t))return a
r=a-1}}return-1},b.indicesOfNearest=function(t,e,n){var i=[]
if(!this._storage[t])return i
null==n&&(n=1/0)
for(var r=1/0,a=-1,o=0,s=0,l=this.count();s<l;s++){var u=e-this.get(t,s),h=Math.abs(u)
h<=n&&((h<r||h===r&&u>=0&&a<0)&&(r=h,a=u,o=0),u===a&&(i[o++]=s))}return i.length=o,i},b.getRawIndex=C,b.getRawDataItem=function(t){if(this._rawData.persistent)return this._rawData.getItem(this.getRawIndex(t))
for(var e=[],n=0;n<this.dimensions.length;n++){var i=this.dimensions[n]
e.push(this.get(i,t))}return e},b.getName=function(t){var e=this.getRawIndex(t)
return this._nameList[e]||M(this,this._nameDimIdx,e)||""},b.getId=function(t){return D(this,this.getRawIndex(t))},b.each=function(t,e,n,r){"use strict"
if(this._count){"function"==typeof t&&(r=n,n=e,e=t,t=[]),n=n||r||this
for(var a=(t=i.map(I(t),this.getDimension,this)).length,o=0;o<this.count();o++)switch(a){case 0:e.call(n,o)
break
case 1:e.call(n,this.get(t[0],o),o)
break
case 2:e.call(n,this.get(t[0],o),this.get(t[1],o),o)
break
default:for(var s=0,l=[];s<a;s++)l[s]=this.get(t[s],o)
l[s]=o,e.apply(n,l)}}},b.filterSelf=function(t,e,n,r){"use strict"
if(this._count){"function"==typeof t&&(r=n,n=e,e=t,t=[]),n=n||r||this,t=i.map(I(t),this.getDimension,this)
for(var a=this.count(),o=new(m(this))(a),s=[],l=t.length,u=0,h=t[0],c=0;c<a;c++){var f,d=this.getRawIndex(c)
if(0===l)f=e.call(n,c)
else if(1===l){var p=this._getFast(h,d)
f=e.call(n,p,c)}else{for(var g=0;g<l;g++)s[g]=this._getFast(h,d)
s[g]=c,f=e.apply(n,s)}f&&(o[u++]=d)}return u<a&&(this._indices=o),this._count=u,this._extent={},this.getRawIndex=this._indices?k:C,this}},b.selectRange=function(t){"use strict"
if(this._count){var e=[]
for(var n in t)t.hasOwnProperty(n)&&e.push(n)
var i=e.length
if(i){var r=this.count(),a=new(m(this))(r),o=0,s=e[0],l=t[s][0],u=t[s][1],h=!1
if(!this._indices){var c=0
if(1===i){for(var f=this._storage[e[0]],d=0;d<this._chunkCount;d++)for(var p=f[d],g=Math.min(this._count-d*this._chunkSize,this._chunkSize),v=0;v<g;v++)((b=p[v])>=l&&b<=u||isNaN(b))&&(a[o++]=c),c++
h=!0}else if(2===i){f=this._storage[s]
var _=this._storage[e[1]],y=t[e[1]][0],x=t[e[1]][1]
for(d=0;d<this._chunkCount;d++){p=f[d]
var w=_[d]
for(g=Math.min(this._count-d*this._chunkSize,this._chunkSize),v=0;v<g;v++){var b=p[v],S=w[v];(b>=l&&b<=u||isNaN(b))&&(S>=y&&S<=x||isNaN(S))&&(a[o++]=c),c++}}h=!0}}if(!h)if(1===i)for(v=0;v<r;v++){var T=this.getRawIndex(v);((b=this._getFast(s,T))>=l&&b<=u||isNaN(b))&&(a[o++]=T)}else for(v=0;v<r;v++){var M=!0
for(T=this.getRawIndex(v),d=0;d<i;d++){var D=e[d];((b=this._getFast(n,T))<t[D][0]||b>t[D][1])&&(M=!1)}M&&(a[o++]=this.getRawIndex(v))}return o<r&&(this._indices=a),this._count=o,this._extent={},this.getRawIndex=this._indices?k:C,this}}},b.mapArray=function(t,e,n,i){"use strict"
"function"==typeof t&&(i=n,n=e,e=t,t=[]),n=n||i||this
var r=[]
return this.each(t,(function(){r.push(e&&e.apply(this,arguments))}),n),r},b.map=function(t,e,n,r){"use strict"
n=n||r||this
var a=A(this,t=i.map(I(t),this.getDimension,this))
a._indices=this._indices,a.getRawIndex=a._indices?k:C
for(var o=a._storage,s=[],l=this._chunkSize,u=t.length,h=this.count(),c=[],f=a._rawExtent,d=0;d<h;d++){for(var p=0;p<u;p++)c[p]=this.get(t[p],d)
c[u]=d
var g=e&&e.apply(n,c)
if(null!=g){"object"!=typeof g&&(s[0]=g,g=s)
for(var v=this.getRawIndex(d),m=Math.floor(v/l),_=v%l,y=0;y<g.length;y++){var x=t[y],w=g[y],b=f[x],S=o[x]
S&&(S[m][_]=w),w<b[0]&&(b[0]=w),w>b[1]&&(b[1]=w)}}}return a},b.downSample=function(t,e,n,i){for(var r=A(this,[t]),a=r._storage,o=[],s=Math.floor(1/e),l=a[t],u=this.count(),h=this._chunkSize,c=r._rawExtent[t],f=new(m(this))(u),d=0,p=0;p<u;p+=s){s>u-p&&(s=u-p,o.length=s)
for(var g=0;g<s;g++){var v=this.getRawIndex(p+g),_=Math.floor(v/h),y=v%h
o[g]=l[_][y]}var x=n(o),w=this.getRawIndex(Math.min(p+i(o,x)||0,u-1)),b=w%h
l[Math.floor(w/h)][b]=x,x<c[0]&&(c[0]=x),x>c[1]&&(c[1]=x),f[d++]=w}return r._count=d,r._indices=f,r.getRawIndex=k,r},b.getItemModel=function(t){var e=this.hostModel
return new r(this.getRawDataItem(t),e,e&&e.ecModel)},b.diff=function(t){var e=this
return new a(t?t.getIndices():[],this.getIndices(),(function(e){return D(t,e)}),(function(t){return D(e,t)}))},b.getVisual=function(t){var e=this._visual
return e&&e[t]},b.setVisual=function(t,e){if(f(t))for(var n in t)t.hasOwnProperty(n)&&this.setVisual(n,t[n])
else this._visual=this._visual||{},this._visual[t]=e},b.setLayout=function(t,e){if(f(t))for(var n in t)t.hasOwnProperty(n)&&this.setLayout(n,t[n])
else this._layout[t]=e},b.getLayout=function(t){return this._layout[t]},b.getItemLayout=function(t){return this._itemLayouts[t]},b.setItemLayout=function(t,e,n){this._itemLayouts[t]=n?i.extend(this._itemLayouts[t]||{},e):e},b.clearItemLayouts=function(){this._itemLayouts.length=0},b.getItemVisual=function(t,e,n){var i=this._itemVisuals[t],r=i&&i[e]
return null!=r||n?r:this.getVisual(e)},b.setItemVisual=function(t,e,n){var i=this._itemVisuals[t]||{},r=this.hasItemVisual
if(this._itemVisuals[t]=i,f(e))for(var a in e)e.hasOwnProperty(a)&&(i[a]=e[a],r[a]=!0)
else i[e]=n,r[e]=!0},b.clearAllVisual=function(){this._visual={},this._itemVisuals=[],this.hasItemVisual={}}
var P=function(t){t.seriesIndex=this.seriesIndex,t.dataIndex=this.dataIndex,t.dataType=this.dataType}
b.setItemGraphicEl=function(t,e){var n=this.hostModel
e&&(e.dataIndex=t,e.dataType=this.dataType,e.seriesIndex=n&&n.seriesIndex,"group"===e.type&&e.traverse(P,e)),this._graphicEls[t]=e},b.getItemGraphicEl=function(t){return this._graphicEls[t]},b.eachItemGraphicEl=function(t,e){i.each(this._graphicEls,(function(n,i){n&&t&&t.call(e,n,i)}))},b.cloneShallow=function(t){if(!t){var e=i.map(this.dimensions,this.getDimensionInfo,this)
t=new w(e,this.hostModel)}if(t._storage=this._storage,x(t,this),this._indices){var n=this._indices.constructor
t._indices=new n(this._indices)}else t._indices=null
return t.getRawIndex=t._indices?k:C,t},b.wrapMethod=function(t,e){var n=this[t]
"function"==typeof n&&(this.__wrappedMethods=this.__wrappedMethods||[],this.__wrappedMethods.push(t),this[t]=function(){var t=n.apply(this,arguments)
return e.apply(this,[t].concat(i.slice(arguments)))})},b.TRANSFERABLE_METHODS=["cloneShallow","downSample","map"],b.CHANGABLE_METHODS=["filterSelf","selectRange"]
var L=w
t.exports=L},function(t,e,n){var i=n(207)
t.exports=function(t){null!=t&&i.extend(this,t),this.otherDims={}}},function(t,e,n){var i=n(291)
t.exports=function(t,e){return i((e=e||{}).coordDimensions||[],t,{dimsDef:e.dimensionsDefine||t.dimensionsDefine,encodeDef:e.encodeDefine||t.encodeDefine,dimCount:e.dimensionsCount,encodeDefaulter:e.encodeDefaulter,generateCoord:e.generateCoord,generateCoordCount:e.generateCoordCount})}},function(t,e,n){var i=n(207),r=i.createHashMap,a=i.each,o=i.isString,s=i.defaults,l=i.extend,u=i.isObject,h=i.clone,c=n(208).normalizeToArray,f=n(230),d=f.guessOrdinal,p=f.BE_ORDINAL,g=n(231),v=n(254).OTHER_DIMENSIONS,m=n(289)
function _(t,e,n){if(n||null!=e.get(t)){for(var i=0;null!=e.get(t+i);)i++
t+=i}return e.set(t,!0),t}t.exports=function(t,e,n){g.isInstance(e)||(e=g.seriesDataToSource(e)),n=n||{},t=(t||[]).slice()
for(var i=(n.dimsDef||[]).slice(),f=r(),y=r(),x=[],w=function(t,e,n,i){var r=Math.max(t.dimensionsDetectCount||1,e.length,n.length,i||0)
return a(e,(function(t){var e=t.dimsDef
e&&(r=Math.max(r,e.length))})),r}(e,t,i,n.dimCount),b=0;b<w;b++){var S=i[b]=l({},u(i[b])?i[b]:{name:i[b]}),T=S.name,M=x[b]=new m
null!=T&&null==f.get(T)&&(M.name=M.displayName=T,f.set(T,b)),null!=S.type&&(M.type=S.type),null!=S.displayName&&(M.displayName=S.displayName)}var C=n.encodeDef
!C&&n.encodeDefaulter&&(C=n.encodeDefaulter(e,w)),(C=r(C)).each((function(t,e){if(1===(t=c(t).slice()).length&&!o(t[0])&&t[0]<0)C.set(e,!1)
else{var n=C.set(e,[])
a(t,(function(t,i){o(t)&&(t=f.get(t)),null!=t&&t<w&&(n[i]=t,D(x[t],e,i))}))}}))
var k=0
function D(t,e,n){null!=v.get(e)?t.otherDims[e]=n:(t.coordDim=e,t.coordDimIndex=n,y.set(e,!0))}a(t,(function(t,e){var n,i,r
if(o(t))n=t,t={}
else{n=t.name
var l=t.ordinalMeta
t.ordinalMeta=null,(t=h(t)).ordinalMeta=l,i=t.dimsDef,r=t.otherDims,t.name=t.coordDim=t.coordDimIndex=t.dimsDef=t.otherDims=null}if(!1!==(f=C.get(n))){var f
if(!(f=c(f)).length)for(var d=0;d<(i&&i.length||1);d++){for(;k<x.length&&null!=x[k].coordDim;)k++
k<x.length&&f.push(k++)}a(f,(function(e,a){var o=x[e]
if(D(s(o,t),n,a),null==o.name&&i){var l=i[a]
!u(l)&&(l={name:l}),o.name=o.displayName=l.name,o.defaultTooltip=l.defaultTooltip}r&&s(o.otherDims,r)}))}}))
var I=n.generateCoord,A=n.generateCoordCount,O=null!=A
A=I?A||1:0
for(var P=I||"value",L=0;L<w;L++)null==(M=x[L]=x[L]||new m).coordDim&&(M.coordDim=_(P,y,O),M.coordDimIndex=0,(!I||A<=0)&&(M.isExtraCoord=!0),A--),null==M.name&&(M.name=_(M.coordDim,f)),null!=M.type||d(e,L,M.name)!==p.Must&&(!M.isExtraCoord||null==M.otherDims.itemName&&null==M.otherDims.seriesName)||(M.type="ordinal")
return x}},function(t,e,n){var i=n(207),r=i.createHashMap,a=i.isObject,o=i.map
function s(t){this.categories=t.categories||[],this._needCollect=t.needCollect,this._deduplication=t.deduplication,this._map}s.createByAxisModel=function(t){var e=t.option,n=e.data,i=n&&o(n,h)
return new s({categories:i,needCollect:!i,deduplication:!1!==e.dedplication})}
var l=s.prototype
function u(t){return t._map||(t._map=r(t.categories))}function h(t){return a(t)&&null!=t.value?t.value:t+""}l.getOrdinal=function(t){return u(this).get(t)},l.parseAndCollect=function(t){var e,n=this._needCollect
if("string"!=typeof t&&!n)return t
if(n&&!this._deduplication)return e=this.categories.length,this.categories[e]=t,e
var i=u(this)
return null==(e=i.get(t))&&(n?(e=this.categories.length,this.categories[e]=t,i.set(t,e)):e=NaN),e}
var c=s
t.exports=c},function(t,e,n){var i=n(214),r=i.round
function a(t){return i.getPrecisionSafe(t)+2}function o(t,e,n){t[e]=Math.max(Math.min(t[e],n[1]),n[0])}function s(t,e){!isFinite(t[0])&&(t[0]=e[0]),!isFinite(t[1])&&(t[1]=e[1]),o(t,0,e),o(t,1,e),t[0]>t[1]&&(t[0]=t[1])}e.intervalScaleNiceTicks=function(t,e,n,o){var l={},u=t[1]-t[0],h=l.interval=i.nice(u/e,!0)
null!=n&&h<n&&(h=l.interval=n),null!=o&&h>o&&(h=l.interval=o)
var c=l.intervalPrecision=a(h)
return s(l.niceTickExtent=[r(Math.ceil(t[0]/h)*h,c),r(Math.floor(t[1]/h)*h,c)],t),l},e.getIntervalPrecision=a,e.fixExtent=s},function(t,e,n){var i=n(207),r={getMin:function(t){var e=this.option,n=t||null==e.rangeStart?e.min:e.rangeStart
return this.axis&&null!=n&&"dataMin"!==n&&"function"!=typeof n&&!i.eqNaN(n)&&(n=this.axis.scale.parse(n)),n},getMax:function(t){var e=this.option,n=t||null==e.rangeEnd?e.max:e.rangeEnd
return this.axis&&null!=n&&"dataMax"!==n&&"function"!=typeof n&&!i.eqNaN(n)&&(n=this.axis.scale.parse(n)),n},getNeedCrossZero:function(){var t=this.option
return null==t.rangeStart&&null==t.rangeEnd&&!t.scale},getCoordSysModel:i.noop,setRange:function(t,e){this.option.rangeStart=t,this.option.rangeEnd=e},resetRange:function(){this.option.rangeStart=this.option.rangeEnd=null}}
t.exports=r},function(t,e,n){var i=n(207),r=i.each,a=i.map,o=n(214),s=o.linearMap,l=o.getPixelPrecision,u=o.round,h=n(366),c=h.createAxisTicks,f=h.createAxisLabels,d=h.calculateCategoryInterval,p=[0,1],g=function(t,e,n){this.dim=t,this.scale=e,this._extent=n||[0,0],this.inverse=!1,this.onBand=!1}
function v(t,e){var n=(t[1]-t[0])/e/2
t[0]+=n,t[1]-=n}g.prototype={constructor:g,contain:function(t){var e=this._extent,n=Math.min(e[0],e[1]),i=Math.max(e[0],e[1])
return t>=n&&t<=i},containData:function(t){return this.scale.contain(t)},getExtent:function(){return this._extent.slice()},getPixelPrecision:function(t){return l(t||this.scale.getExtent(),this._extent)},setExtent:function(t,e){var n=this._extent
n[0]=t,n[1]=e},dataToCoord:function(t,e){var n=this._extent,i=this.scale
return t=i.normalize(t),this.onBand&&"ordinal"===i.type&&v(n=n.slice(),i.count()),s(t,p,n,e)},coordToData:function(t,e){var n=this._extent,i=this.scale
this.onBand&&"ordinal"===i.type&&v(n=n.slice(),i.count())
var r=s(t,n,p,e)
return this.scale.scale(r)},pointToData:function(t,e){},getTicksCoords:function(t){var e=(t=t||{}).tickModel||this.getTickModel(),n=c(this,e).ticks,i=a(n,(function(t){return{coord:this.dataToCoord(t),tickValue:t}}),this)
return function(t,e,n,i){var a=e.length
if(t.onBand&&!n&&a){var o,s,l=t.getExtent()
if(1===a)e[0].coord=l[0],o=e[1]={coord:l[0]}
else{var h=e[a-1].tickValue-e[0].tickValue,c=(e[a-1].coord-e[0].coord)/h
r(e,(function(t){t.coord-=c/2})),s=1+t.scale.getExtent()[1]-e[a-1].tickValue,o={coord:e[a-1].coord+c*s},e.push(o)}var f=l[0]>l[1]
d(e[0].coord,l[0])&&(i?e[0].coord=l[0]:e.shift()),i&&d(l[0],e[0].coord)&&e.unshift({coord:l[0]}),d(l[1],o.coord)&&(i?o.coord=l[1]:e.pop()),i&&d(o.coord,l[1])&&e.push({coord:l[1]})}function d(t,e){return t=u(t),e=u(e),f?t>e:t<e}}(this,i,e.get("alignWithLabel"),t.clamp),i},getMinorTicksCoords:function(){if("ordinal"===this.scale.type)return[]
var t=this.model.getModel("minorTick").get("splitNumber")
t>0&&t<100||(t=5)
var e=this.scale.getMinorTicks(t)
return a(e,(function(t){return a(t,(function(t){return{coord:this.dataToCoord(t),tickValue:t}}),this)}),this)},getViewLabels:function(){return f(this).labels},getLabelModel:function(){return this.model.getModel("axisLabel")},getTickModel:function(){return this.model.getModel("axisTick")},getBandWidth:function(){var t=this._extent,e=this.scale.getExtent(),n=e[1]-e[0]+(this.onBand?1:0)
0===n&&(n=1)
var i=Math.abs(t[1]-t[0])
return Math.abs(i)/n},isHorizontal:null,getRotate:null,calculateCategoryInterval:function(){return d(this)}}
var m=g
t.exports=m},,,,,,,,,,function(t,e,n){var i=n(207),r=n(212),a=n(306),o=n(227),s=n(222),l=n(308)
function u(){s.stop(this.event)}function h(){}h.prototype.dispose=function(){}
var c=["click","dblclick","mousewheel","mouseout","mouseup","mousedown","mousemove","contextmenu"],f=function(t,e,n,i){o.call(this),this.storage=t,this.painter=e,this.painterRoot=i,n=n||new h,this.proxy=null,this._hovered={},this._lastTouchMoment,this._lastX,this._lastY,this._gestureMgr,a.call(this),this.setHandlerProxy(n)}
function d(t,e,n){if(t[t.rectHover?"rectContain":"contain"](e,n)){for(var i,r=t;r;){if(r.clipPath&&!r.clipPath.contain(e,n))return!1
r.silent&&(i=!0),r=r.parent}return!i||"silent"}return!1}function p(t,e,n){var i=t.painter
return e<0||e>i.getWidth()||n<0||n>i.getHeight()}f.prototype={constructor:f,setHandlerProxy:function(t){this.proxy&&this.proxy.dispose(),t&&(i.each(c,(function(e){t.on&&t.on(e,this[e],this)}),this),t.handler=this),this.proxy=t},mousemove:function(t){var e=t.zrX,n=t.zrY,i=p(this,e,n),r=this._hovered,a=r.target
a&&!a.__zr&&(a=(r=this.findHover(r.x,r.y)).target)
var o=this._hovered=i?{x:e,y:n}:this.findHover(e,n),s=o.target,l=this.proxy
l.setCursor&&l.setCursor(s?s.cursor:"default"),a&&s!==a&&this.dispatchToElement(r,"mouseout",t),this.dispatchToElement(o,"mousemove",t),s&&s!==a&&this.dispatchToElement(o,"mouseover",t)},mouseout:function(t){var e=t.zrEventControl,n=t.zrIsToLocalDOM
"only_globalout"!==e&&this.dispatchToElement(this._hovered,"mouseout",t),"no_globalout"!==e&&!n&&this.trigger("globalout",{type:"globalout",event:t})},resize:function(t){this._hovered={}},dispatch:function(t,e){var n=this[t]
n&&n.call(this,e)},dispose:function(){this.proxy.dispose(),this.storage=this.proxy=this.painter=null},setCursorStyle:function(t){var e=this.proxy
e.setCursor&&e.setCursor(t)},dispatchToElement:function(t,e,n){var i=(t=t||{}).target
if(!i||!i.silent){for(var r="on"+e,a=function(t,e,n){return{type:t,event:n,target:e.target,topTarget:e.topTarget,cancelBubble:!1,offsetX:n.zrX,offsetY:n.zrY,gestureEvent:n.gestureEvent,pinchX:n.pinchX,pinchY:n.pinchY,pinchScale:n.pinchScale,wheelDelta:n.zrDelta,zrByTouch:n.zrByTouch,which:n.which,stop:u}}(e,t,n);i&&(i[r]&&(a.cancelBubble=i[r].call(i,a)),i.trigger(e,a),i=i.parent,!a.cancelBubble););a.cancelBubble||(this.trigger(e,a),this.painter&&this.painter.eachOtherLayer((function(t){"function"==typeof t[r]&&t[r].call(t,a),t.trigger&&t.trigger(e,a)})))}},findHover:function(t,e,n){for(var i=this.storage.getDisplayList(),r={x:t,y:e},a=i.length-1;a>=0;a--){var o
if(i[a]!==n&&!i[a].ignore&&(o=d(i[a],t,e))&&(!r.topTarget&&(r.topTarget=i[a]),"silent"!==o)){r.target=i[a]
break}}return r},processGesture:function(t,e){this._gestureMgr||(this._gestureMgr=new l)
var n=this._gestureMgr
"start"===e&&n.clear()
var i=n.recognize(t,this.findHover(t.zrX,t.zrY,null).target,this.proxy.dom)
if("end"===e&&n.clear(),i){var r=i.type
t.gestureEvent=r,this.dispatchToElement({target:i.target},r,i.event)}}},i.each(["click","mousedown","mouseup","mousewheel","dblclick","contextmenu"],(function(t){f.prototype[t]=function(e){var n,i,a=e.zrX,o=e.zrY,s=p(this,a,o)
if("mouseup"===t&&s||(i=(n=this.findHover(a,o)).target),"mousedown"===t)this._downEl=i,this._downPoint=[e.zrX,e.zrY],this._upEl=i
else if("mouseup"===t)this._upEl=i
else if("click"===t){if(this._downEl!==this._upEl||!this._downPoint||r.dist(this._downPoint,[e.zrX,e.zrY])>4)return
this._downPoint=null}this.dispatchToElement(n,t,e)}})),i.mixin(f,o),i.mixin(f,a)
var g=f
t.exports=g},function(t,e){function n(){this.on("mousedown",this._dragStart,this),this.on("mousemove",this._drag,this),this.on("mouseup",this._dragEnd,this)}function i(t,e){return{target:t,topTarget:e&&e.topTarget}}n.prototype={constructor:n,_dragStart:function(t){for(var e=t.target;e&&!e.draggable;)e=e.parent
e&&(this._draggingTarget=e,e.dragging=!0,this._x=t.offsetX,this._y=t.offsetY,this.dispatchToElement(i(e,t),"dragstart",t.event))},_drag:function(t){var e=this._draggingTarget
if(e){var n=t.offsetX,r=t.offsetY,a=n-this._x,o=r-this._y
this._x=n,this._y=r,e.drift(a,o,t),this.dispatchToElement(i(e,t),"drag",t.event)
var s=this.findHover(n,r,e).target,l=this._dropTarget
this._dropTarget=s,e!==s&&(l&&s!==l&&this.dispatchToElement(i(l,t),"dragleave",t.event),s&&s!==l&&this.dispatchToElement(i(s,t),"dragenter",t.event))}},_dragEnd:function(t){var e=this._draggingTarget
e&&(e.dragging=!1),this.dispatchToElement(i(e,t),"dragend",t.event),this._dropTarget&&this.dispatchToElement(i(this._dropTarget,t),"drop",t.event),this._draggingTarget=null,this._dropTarget=null}}
var r=n
t.exports=r},function(t,e){var n=Math.log(2)
function i(t,e,r,a,o,s){var l=a+"-"+o,u=t.length
if(s.hasOwnProperty(l))return s[l]
if(1===e){var h=Math.round(Math.log((1<<u)-1&~o)/n)
return t[r][h]}for(var c=a|1<<r,f=r+1;a&1<<f;)f++
for(var d=0,p=0,g=0;p<u;p++){var v=1<<p
v&o||(d+=(g%2?-1:1)*t[r][p]*i(t,e-1,f,c,o|v,s),g++)}return s[l]=d,d}e.buildTransformer=function(t,e){var n=[[t[0],t[1],1,0,0,0,-e[0]*t[0],-e[0]*t[1]],[0,0,0,t[0],t[1],1,-e[1]*t[0],-e[1]*t[1]],[t[2],t[3],1,0,0,0,-e[2]*t[2],-e[2]*t[3]],[0,0,0,t[2],t[3],1,-e[3]*t[2],-e[3]*t[3]],[t[4],t[5],1,0,0,0,-e[4]*t[4],-e[4]*t[5]],[0,0,0,t[4],t[5],1,-e[5]*t[4],-e[5]*t[5]],[t[6],t[7],1,0,0,0,-e[6]*t[6],-e[6]*t[7]],[0,0,0,t[6],t[7],1,-e[7]*t[6],-e[7]*t[7]]],r={},a=i(n,8,0,0,0,r)
if(0!==a){for(var o=[],s=0;s<8;s++)for(var l=0;l<8;l++)null==o[l]&&(o[l]=0),o[l]+=((s+l)%2?-1:1)*i(n,7,0===s?1:0,1<<s,1<<l,r)/a*e[s]
return function(t,e,n){var i=e*o[6]+n*o[7]+1
t[0]=(e*o[0]+n*o[1]+o[2])/i,t[1]=(e*o[3]+n*o[4]+o[5])/i}}}},function(t,e,n){var i=n(222),r=function(){this._track=[]}
function a(t){var e=t[1][0]-t[0][0],n=t[1][1]-t[0][1]
return Math.sqrt(e*e+n*n)}r.prototype={constructor:r,recognize:function(t,e,n){return this._doTrack(t,e,n),this._recognize(t)},clear:function(){return this._track.length=0,this},_doTrack:function(t,e,n){var r=t.touches
if(r){for(var a={points:[],touches:[],target:e,event:t},o=0,s=r.length;o<s;o++){var l=r[o],u=i.clientToLocal(n,l,{})
a.points.push([u.zrX,u.zrY]),a.touches.push(l)}this._track.push(a)}},_recognize:function(t){for(var e in o)if(o.hasOwnProperty(e)){var n=o[e](this._track,t)
if(n)return n}}}
var o={pinch:function(t,e){var n=t.length
if(n){var i,r=(t[n-1]||{}).points,o=(t[n-2]||{}).points||r
if(o&&o.length>1&&r&&r.length>1){var s=a(r)/a(o)
!isFinite(s)&&(s=1),e.pinchScale=s
var l=[((i=r)[0][0]+i[1][0])/2,(i[0][1]+i[1][1])/2]
return e.pinchX=l[0],e.pinchY=l[1],{type:"pinch",target:t[0].target,event:e}}}}},s=r
t.exports=s},function(t,e,n){var i=n(207),r=n(211),a=n(228),o=n(241)
function s(t,e){return t.zlevel===e.zlevel?t.z===e.z?t.z2-e.z2:t.z-e.z:t.zlevel-e.zlevel}var l=function(){this._roots=[],this._displayList=[],this._displayListLen=0}
l.prototype={constructor:l,traverse:function(t,e){for(var n=0;n<this._roots.length;n++)this._roots[n].traverse(t,e)},getDisplayList:function(t,e){return e=e||!1,t&&this.updateDisplayList(e),this._displayList},updateDisplayList:function(t){this._displayListLen=0
for(var e=this._roots,n=this._displayList,i=0,a=e.length;i<a;i++)this._updateAndAddDisplayable(e[i],null,t)
n.length=this._displayListLen,r.canvasSupported&&o(n,s)},_updateAndAddDisplayable:function(t,e,n){if(!t.ignore||n){t.beforeUpdate(),t.__dirty&&t.update(),t.afterUpdate()
var i=t.clipPath
if(i){e=e?e.slice():[]
for(var r=i,a=t;r;)r.parent=a,r.updateTransform(),e.push(r),a=r,r=r.clipPath}if(t.isGroup){for(var o=t._children,s=0;s<o.length;s++){var l=o[s]
t.__dirty&&(l.__dirty=!0),this._updateAndAddDisplayable(l,e,n)}t.__dirty=!1}else t.__clipPaths=e,this._displayList[this._displayListLen++]=t}},addRoot:function(t){t.__storage!==this&&(t instanceof a&&t.addChildrenToStorage(this),this.addToStorage(t),this._roots.push(t))},delRoot:function(t){if(null==t){for(var e=0;e<this._roots.length;e++){var n=this._roots[e]
n instanceof a&&n.delChildrenFromStorage(this)}return this._roots=[],this._displayList=[],void(this._displayListLen=0)}if(t instanceof Array){e=0
for(var r=t.length;e<r;e++)this.delRoot(t[e])}else{var o=i.indexOf(this._roots,t)
o>=0&&(this.delFromStorage(t),this._roots.splice(o,1),t instanceof a&&t.delChildrenFromStorage(this))}},addToStorage:function(t){return t&&(t.__storage=this,t.dirty(!1)),this},delFromStorage:function(t){return t&&(t.__storage=null),this},dispose:function(){this._renderList=this._roots=null},displayableSortFunc:s}
var u=l
t.exports=u},function(t,e,n){var i=n(262),r=n(264),a=n(207),o=a.isString,s=a.isFunction,l=a.isObject,u=a.isArrayLike,h=a.indexOf,c=function(){this.animators=[]}
function f(t,e,n,i,r,a,h,c){o(i)?(a=r,r=i,i=0):s(r)?(a=r,r="linear",i=0):s(i)?(a=i,i=0):s(n)?(a=n,n=500):n||(n=500),t.stopAnimation(),function t(e,n,i,r,a,o,s){var h={},c=0
for(var f in r)r.hasOwnProperty(f)&&(null!=i[f]?l(r[f])&&!u(r[f])?t(e,n?n+"."+f:f,i[f],r[f],a,o,s):(s?(h[f]=i[f],d(e,n,f,r[f])):h[f]=r[f],c++):null==r[f]||s||d(e,n,f,r[f]))
c>0&&e.animate(n,!1).when(null==a?500:a,h).delay(o||0)}(t,"",t,e,n,i,c)
var f=t.animators.slice(),p=f.length
function g(){--p||a&&a()}p||a&&a()
for(var v=0;v<f.length;v++)f[v].done(g).start(r,h)}function d(t,e,n,i){if(e){var r={}
r[e]={},r[e][n]=i,t.attr(r)}else t.attr(n,i)}c.prototype={constructor:c,animate:function(t,e){var n,a=!1,o=this,s=this.__zr
if(t){var l=t.split("."),u=o
a="shape"===l[0]
for(var c=0,f=l.length;c<f;c++)u&&(u=u[l[c]])
u&&(n=u)}else n=o
if(n){var d=o.animators,p=new i(n,e)
return p.during((function(t){o.dirty(a)})).done((function(){d.splice(h(d,p),1)})),d.push(p),s&&s.animation.addAnimator(p),p}r('Property "'+t+'" is not existed in element '+o.id)},stopAnimation:function(t){for(var e=this.animators,n=e.length,i=0;i<n;i++)e[i].stop(t)
return e.length=0,this},animateTo:function(t,e,n,i,r,a){f(this,t,e,n,i,r,a)},animateFrom:function(t,e,n,i,r,a){f(this,t,e,n,i,r,a,!0)}}
var p=c
t.exports=p},function(t,e,n){var i=n(312)
function r(t){this._target=t.target,this._life=t.life||1e3,this._delay=t.delay||0,this._initialized=!1,this.loop=null!=t.loop&&t.loop,this.gap=t.gap||0,this.easing=t.easing||"Linear",this.onframe=t.onframe,this.ondestroy=t.ondestroy,this.onrestart=t.onrestart,this._pausedTime=0,this._paused=!1}r.prototype={constructor:r,step:function(t,e){if(this._initialized||(this._startTime=t+this._delay,this._initialized=!0),this._paused)this._pausedTime+=e
else{var n=(t-this._startTime-this._pausedTime)/this._life
if(!(n<0)){n=Math.min(n,1)
var r=this.easing,a="string"==typeof r?i[r]:r,o="function"==typeof a?a(n):n
return this.fire("frame",o),1===n?this.loop?(this.restart(t),"restart"):(this._needsRemove=!0,"destroy"):null}}},restart:function(t){var e=(t-this._startTime-this._pausedTime)%this._life
this._startTime=t-e+this.gap,this._pausedTime=0,this._needsRemove=!1},fire:function(t,e){this[t="on"+t]&&this[t](this._target,e)},pause:function(){this._paused=!0},resume:function(){this._paused=!1}}
var a=r
t.exports=a},function(t,e){var n={linear:function(t){return t},quadraticIn:function(t){return t*t},quadraticOut:function(t){return t*(2-t)},quadraticInOut:function(t){return(t*=2)<1?.5*t*t:-.5*(--t*(t-2)-1)},cubicIn:function(t){return t*t*t},cubicOut:function(t){return--t*t*t+1},cubicInOut:function(t){return(t*=2)<1?.5*t*t*t:.5*((t-=2)*t*t+2)},quarticIn:function(t){return t*t*t*t},quarticOut:function(t){return 1- --t*t*t*t},quarticInOut:function(t){return(t*=2)<1?.5*t*t*t*t:-.5*((t-=2)*t*t*t-2)},quinticIn:function(t){return t*t*t*t*t},quinticOut:function(t){return--t*t*t*t*t+1},quinticInOut:function(t){return(t*=2)<1?.5*t*t*t*t*t:.5*((t-=2)*t*t*t*t+2)},sinusoidalIn:function(t){return 1-Math.cos(t*Math.PI/2)},sinusoidalOut:function(t){return Math.sin(t*Math.PI/2)},sinusoidalInOut:function(t){return.5*(1-Math.cos(Math.PI*t))},exponentialIn:function(t){return 0===t?0:Math.pow(1024,t-1)},exponentialOut:function(t){return 1===t?1:1-Math.pow(2,-10*t)},exponentialInOut:function(t){return 0===t?0:1===t?1:(t*=2)<1?.5*Math.pow(1024,t-1):.5*(2-Math.pow(2,-10*(t-1)))},circularIn:function(t){return 1-Math.sqrt(1-t*t)},circularOut:function(t){return Math.sqrt(1- --t*t)},circularInOut:function(t){return(t*=2)<1?-.5*(Math.sqrt(1-t*t)-1):.5*(Math.sqrt(1-(t-=2)*t)+1)},elasticIn:function(t){var e,n=.1
return 0===t?0:1===t?1:(!n||n<1?(n=1,e=.1):e=.4*Math.asin(1/n)/(2*Math.PI),-n*Math.pow(2,10*(t-=1))*Math.sin((t-e)*(2*Math.PI)/.4))},elasticOut:function(t){var e,n=.1
return 0===t?0:1===t?1:(!n||n<1?(n=1,e=.1):e=.4*Math.asin(1/n)/(2*Math.PI),n*Math.pow(2,-10*t)*Math.sin((t-e)*(2*Math.PI)/.4)+1)},elasticInOut:function(t){var e,n=.1
return 0===t?0:1===t?1:(!n||n<1?(n=1,e=.1):e=.4*Math.asin(1/n)/(2*Math.PI),(t*=2)<1?n*Math.pow(2,10*(t-=1))*Math.sin((t-e)*(2*Math.PI)/.4)*-.5:n*Math.pow(2,-10*(t-=1))*Math.sin((t-e)*(2*Math.PI)/.4)*.5+1)},backIn:function(t){var e=1.70158
return t*t*((e+1)*t-e)},backOut:function(t){var e=1.70158
return--t*t*((e+1)*t+e)+1},backInOut:function(t){var e=2.5949095
return(t*=2)<1?t*t*((e+1)*t-e)*.5:.5*((t-=2)*t*((e+1)*t+e)+2)},bounceIn:function(t){return 1-n.bounceOut(1-t)},bounceOut:function(t){return t<1/2.75?7.5625*t*t:t<2/2.75?7.5625*(t-=1.5/2.75)*t+.75:t<2.5/2.75?7.5625*(t-=2.25/2.75)*t+.9375:7.5625*(t-=2.625/2.75)*t+.984375},bounceInOut:function(t){return t<.5?.5*n.bounceIn(2*t):.5*n.bounceOut(2*t-1)+.5}},i=n
t.exports=i},function(t,e,n){var i=n(234).devicePixelRatio,r=n(207),a=n(264),o=n(215),s=n(241),l=n(314),u=n(267),h=n(243),c=n(211)
function f(t){return parseInt(t,10)}var d=new o(0,0,0,0),p=new o(0,0,0,0),g=function(t,e,n){this.type="canvas"
var a=!t.nodeName||"CANVAS"===t.nodeName.toUpperCase()
this._opts=n=r.extend({},n||{}),this.dpr=n.devicePixelRatio||i,this._singleCanvas=a,this.root=t
var o=t.style
o&&(o["-webkit-tap-highlight-color"]="transparent",o["-webkit-user-select"]=o["user-select"]=o["-webkit-touch-callout"]="none",t.innerHTML=""),this.storage=e
var s=this._zlevelList=[],u=this._layers={}
if(this._layerConfig={},this._needsManuallyCompositing=!1,a){var h=t.width,c=t.height
null!=n.width&&(h=n.width),null!=n.height&&(c=n.height),this.dpr=n.devicePixelRatio||1,t.width=h*this.dpr,t.height=c*this.dpr,this._width=h,this._height=c
var f=new l(t,this,this.dpr)
f.__builtin__=!0,f.initContext(),u[314159]=f,f.zlevel=314159,s.push(314159),this._domRoot=t}else{this._width=this._getSize(0),this._height=this._getSize(1)
var d=this._domRoot=function(t,e){var n=document.createElement("div")
return n.style.cssText=["position:relative","width:"+t+"px","height:"+e+"px","padding:0","margin:0","border-width:0"].join(";")+";",n}(this._width,this._height)
t.appendChild(d)}this._hoverlayer=null,this._hoverElements=[]}
g.prototype={constructor:g,getType:function(){return"canvas"},isSingleCanvas:function(){return this._singleCanvas},getViewportRoot:function(){return this._domRoot},getViewportRootOffset:function(){var t=this.getViewportRoot()
if(t)return{offsetLeft:t.offsetLeft||0,offsetTop:t.offsetTop||0}},refresh:function(t){var e=this.storage.getDisplayList(!0),n=this._zlevelList
this._redrawId=Math.random(),this._paintList(e,t,this._redrawId)
for(var i=0;i<n.length;i++){var r=n[i],a=this._layers[r]
if(!a.__builtin__&&a.refresh){var o=0===i?this._backgroundColor:null
a.refresh(o)}}return this.refreshHover(),this},addHover:function(t,e){if(!t.__hoverMir){var n=new t.constructor({style:t.style,shape:t.shape,z:t.z,z2:t.z2,silent:t.silent})
return n.__from=t,t.__hoverMir=n,e&&n.setStyle(e),this._hoverElements.push(n),n}},removeHover:function(t){var e=t.__hoverMir,n=this._hoverElements,i=r.indexOf(n,e)
i>=0&&n.splice(i,1),t.__hoverMir=null},clearHover:function(t){for(var e=this._hoverElements,n=0;n<e.length;n++){var i=e[n].__from
i&&(i.__hoverMir=null)}e.length=0},refreshHover:function(){var t=this._hoverElements,e=t.length,n=this._hoverlayer
if(n&&n.clear(),e){s(t,this.storage.displayableSortFunc),n||(n=this._hoverlayer=this.getLayer(1e5))
var i={}
n.ctx.save()
for(var r=0;r<e;){var a=t[r],o=a.__from
o&&o.__zr?(r++,o.invisible||(a.transform=o.transform,a.invTransform=o.invTransform,a.__clipPaths=o.__clipPaths,this._doPaintEl(a,n,!0,i))):(t.splice(r,1),o.__hoverMir=null,e--)}n.ctx.restore()}},getHoverLayer:function(){return this.getLayer(1e5)},_paintList:function(t,e,n){if(this._redrawId===n){e=e||!1,this._updateLayerStatus(t)
var i=this._doPaintList(t,e)
if(this._needsManuallyCompositing&&this._compositeManually(),!i){var r=this
u((function(){r._paintList(t,e,n)}))}}},_compositeManually:function(){var t=this.getLayer(314159).ctx,e=this._domRoot.width,n=this._domRoot.height
t.clearRect(0,0,e,n),this.eachBuiltinLayer((function(i){i.virtual&&t.drawImage(i.dom,0,0,e,n)}))},_doPaintList:function(t,e){for(var n=[],i=0;i<this._zlevelList.length;i++){var a=this._zlevelList[i];(l=this._layers[a]).__builtin__&&l!==this._hoverlayer&&(l.__dirty||e)&&n.push(l)}for(var o=!0,s=0;s<n.length;s++){var l,u=(l=n[s]).ctx,h={}
u.save()
var f=e?l.__startIndex:l.__drawIndex,d=!e&&l.incremental&&Date.now,p=d&&Date.now(),g=l.zlevel===this._zlevelList[0]?this._backgroundColor:null
if(l.__startIndex===l.__endIndex)l.clear(!1,g)
else if(f===l.__startIndex){var v=t[f]
v.incremental&&v.notClear&&!e||l.clear(!1,g)}-1===f&&(console.error("For some unknown reason. drawIndex is -1"),f=l.__startIndex)
for(var m=f;m<l.__endIndex;m++){var _=t[m]
if(this._doPaintEl(_,l,e,h),_.__dirty=_.__dirtyText=!1,d&&Date.now()-p>15)break}l.__drawIndex=m,l.__drawIndex<l.__endIndex&&(o=!1),h.prevElClipPaths&&u.restore(),u.restore()}return c.wxa&&r.each(this._layers,(function(t){t&&t.ctx&&t.ctx.draw&&t.ctx.draw()})),o},_doPaintEl:function(t,e,n,i){var r=e.ctx,a=t.transform
if((e.__dirty||n)&&!t.invisible&&0!==t.style.opacity&&(!a||a[0]||a[3])&&(!t.culling||!function(t,e,n){return d.copy(t.getBoundingRect()),t.transform&&d.applyTransform(t.transform),p.width=e,p.height=n,!d.intersect(p)}(t,this._width,this._height))){var o=t.__clipPaths,s=i.prevElClipPaths
s&&!function(t,e){if(t===e)return!1
if(!t||!e||t.length!==e.length)return!0
for(var n=0;n<t.length;n++)if(t[n]!==e[n])return!0
return!1}(o,s)||(s&&(r.restore(),i.prevElClipPaths=null,i.prevEl=null),o&&(r.save(),function(t,e){for(var n=0;n<t.length;n++){var i=t[n]
i.setTransform(e),e.beginPath(),i.buildPath(e,i.shape),e.clip(),i.restoreTransform(e)}}(o,r),i.prevElClipPaths=o)),t.beforeBrush&&t.beforeBrush(r),t.brush(r,i.prevEl||null),i.prevEl=t,t.afterBrush&&t.afterBrush(r)}},getLayer:function(t,e){this._singleCanvas&&!this._needsManuallyCompositing&&(t=314159)
var n=this._layers[t]
return n||((n=new l("zr_"+t,this,this.dpr)).zlevel=t,n.__builtin__=!0,this._layerConfig[t]?r.merge(n,this._layerConfig[t],!0):this._layerConfig[t-.01]&&r.merge(n,this._layerConfig[t-.01],!0),e&&(n.virtual=e),this.insertLayer(t,n),n.initContext()),n},insertLayer:function(t,e){var n=this._layers,i=this._zlevelList,r=i.length,o=null,s=-1,l=this._domRoot
if(n[t])a("ZLevel "+t+" has been used already")
else if(function(t){return!!t&&(!!t.__builtin__||"function"==typeof t.resize&&"function"==typeof t.refresh)}(e)){if(r>0&&t>i[0]){for(s=0;s<r-1&&!(i[s]<t&&i[s+1]>t);s++);o=n[i[s]]}if(i.splice(s+1,0,t),n[t]=e,!e.virtual)if(o){var u=o.dom
u.nextSibling?l.insertBefore(e.dom,u.nextSibling):l.appendChild(e.dom)}else l.firstChild?l.insertBefore(e.dom,l.firstChild):l.appendChild(e.dom)}else a("Layer of zlevel "+t+" is not valid")},eachLayer:function(t,e){var n,i,r=this._zlevelList
for(i=0;i<r.length;i++)n=r[i],t.call(e,this._layers[n],n)},eachBuiltinLayer:function(t,e){var n,i,r,a=this._zlevelList
for(r=0;r<a.length;r++)i=a[r],(n=this._layers[i]).__builtin__&&t.call(e,n,i)},eachOtherLayer:function(t,e){var n,i,r,a=this._zlevelList
for(r=0;r<a.length;r++)i=a[r],(n=this._layers[i]).__builtin__||t.call(e,n,i)},getLayers:function(){return this._layers},_updateLayerStatus:function(t){function e(t){r&&(r.__endIndex!==t&&(r.__dirty=!0),r.__endIndex=t)}if(this.eachBuiltinLayer((function(t,e){t.__dirty=t.__used=!1})),this._singleCanvas)for(var n=1;n<t.length;n++)if((s=t[n]).zlevel!==t[n-1].zlevel||s.incremental){this._needsManuallyCompositing=!0
break}var i,r=null,o=0
for(n=0;n<t.length;n++){var s,l,u=(s=t[n]).zlevel
i!==u&&(i=u,o=0),s.incremental?((l=this.getLayer(u+.001,this._needsManuallyCompositing)).incremental=!0,o=1):l=this.getLayer(u+(o>0?.01:0),this._needsManuallyCompositing),l.__builtin__||a("ZLevel "+u+" has been used by unkown layer "+l.id),l!==r&&(l.__used=!0,l.__startIndex!==n&&(l.__dirty=!0),l.__startIndex=n,l.incremental?l.__drawIndex=-1:l.__drawIndex=n,e(n),r=l),s.__dirty&&(l.__dirty=!0,l.incremental&&l.__drawIndex<0&&(l.__drawIndex=n))}e(n),this.eachBuiltinLayer((function(t,e){!t.__used&&t.getElementCount()>0&&(t.__dirty=!0,t.__startIndex=t.__endIndex=t.__drawIndex=0),t.__dirty&&t.__drawIndex<0&&(t.__drawIndex=t.__startIndex)}))},clear:function(){return this.eachBuiltinLayer(this._clearLayer),this},_clearLayer:function(t){t.clear()},setBackgroundColor:function(t){this._backgroundColor=t},configLayer:function(t,e){if(e){var n=this._layerConfig
n[t]?r.merge(n[t],e,!0):n[t]=e
for(var i=0;i<this._zlevelList.length;i++){var a=this._zlevelList[i]
if(a===t||a===t+.01){var o=this._layers[a]
r.merge(o,n[t],!0)}}}},delLayer:function(t){var e=this._layers,n=this._zlevelList,i=e[t]
i&&(i.dom.parentNode.removeChild(i.dom),delete e[t],n.splice(r.indexOf(n,t),1))},resize:function(t,e){if(this._domRoot.style){var n=this._domRoot
n.style.display="none"
var i=this._opts
if(null!=t&&(i.width=t),null!=e&&(i.height=e),t=this._getSize(0),e=this._getSize(1),n.style.display="",this._width!==t||e!==this._height){for(var a in n.style.width=t+"px",n.style.height=e+"px",this._layers)this._layers.hasOwnProperty(a)&&this._layers[a].resize(t,e)
r.each(this._progressiveLayers,(function(n){n.resize(t,e)})),this.refresh(!0)}this._width=t,this._height=e}else{if(null==t||null==e)return
this._width=t,this._height=e,this.getLayer(314159).resize(t,e)}return this},clearLayer:function(t){var e=this._layers[t]
e&&e.clear()},dispose:function(){this.root.innerHTML="",this.root=this.storage=this._domRoot=this._layers=null},getRenderedCanvas:function(t){if(t=t||{},this._singleCanvas&&!this._compositeManually)return this._layers[314159].dom
var e=new l("image",this,t.pixelRatio||this.dpr)
if(e.initContext(),e.clear(!1,t.backgroundColor||this._backgroundColor),t.pixelRatio<=this.dpr){this.refresh()
var n=e.dom.width,i=e.dom.height,r=e.ctx
this.eachLayer((function(t){t.__builtin__?r.drawImage(t.dom,0,0,n,i):t.renderToCanvas&&(e.ctx.save(),t.renderToCanvas(e.ctx),e.ctx.restore())}))}else for(var a={},o=this.storage.getDisplayList(!0),s=0;s<o.length;s++){var u=o[s]
this._doPaintEl(u,e,!0,a)}return e.dom},getWidth:function(){return this._width},getHeight:function(){return this._height},_getSize:function(t){var e=this._opts,n=["width","height"][t],i=["clientWidth","clientHeight"][t],r=["paddingLeft","paddingTop"][t],a=["paddingRight","paddingBottom"][t]
if(null!=e[n]&&"auto"!==e[n])return parseFloat(e[n])
var o=this.root,s=document.defaultView.getComputedStyle(o)
return(o[i]||f(s[n])||f(o.style[n]))-(f(s[r])||0)-(f(s[a])||0)|0},pathToImage:function(t,e){e=e||this.dpr
var n=document.createElement("canvas"),i=n.getContext("2d"),r=t.getBoundingRect(),a=t.style,o=a.shadowBlur*e,s=a.shadowOffsetX*e,l=a.shadowOffsetY*e,u=a.hasStroke()?a.lineWidth:0,c=Math.max(u/2,-s+o),f=Math.max(u/2,s+o),d=Math.max(u/2,-l+o),p=Math.max(u/2,l+o),g=r.width+c+f,v=r.height+d+p
n.width=g*e,n.height=v*e,i.scale(e,e),i.clearRect(0,0,g,v),i.dpr=e
var m={position:t.position,rotation:t.rotation,scale:t.scale}
t.position=[c-r.x,d-r.y],t.rotation=0,t.scale=[1,1],t.updateTransform(),t&&t.brush(i)
var _=new h({style:{x:0,y:0,image:n}})
return null!=m.position&&(_.position=t.position=m.position),null!=m.rotation&&(_.rotation=t.rotation=m.rotation),null!=m.scale&&(_.scale=t.scale=m.scale),_}}
var v=g
t.exports=v},function(t,e,n){var i=n(207),r=n(234).devicePixelRatio,a=n(242),o=n(266)
function s(){return!1}function l(t,e,n){var r=i.createCanvas(),a=e.getWidth(),o=e.getHeight(),s=r.style
return s&&(s.position="absolute",s.left=0,s.top=0,s.width=a+"px",s.height=o+"px",r.setAttribeftight=o+"px",r.setAttreight=o+"gpx",st=ob2),o=ntstio,+{var l=i[a
x",g)returULreturn sManuassu,=typeof r?i[r]:r,t?a=var r=i.:t,o=i.map
.get(t))===t)r&&(lrtLayedheight=etre=ais.roota&(o["-webkia.ono["-wenrestasit-user-select"]=o["user-sinnerHTelect"]=o["-webkiinnerHTeleouch-callout"]="none",t.innerHTt-tap-highlight-color"]="transparergba,g=functiHTt.ttom"][h=ao.,"bordh=ao[idth:0"].join"+=((sght=etredCols._hoverElere(dCols._hoverEle,this.painterRoer:funs._hoverEler0,0,configayerConmo)reta.shloop=null!astF1===Alpha=.7=n.devicePi)
va={constructor:g,getTypeu,t.__dra:urn.getEltX:nex=t.__star:rn.gx:l.__drawIrn.gt.__drawn}})l&&l.__dratX:ntCount()>0&&(t.(){return this._height},_gt.__drawusedTimgx:l.__drawayer(),e.clea(){this.root.innere(=ght=etrext("2d"),r=t.getBo.innere(vicePn.deviceyerisModeColBuffon(){var t=this._hoverEle=docght=etredCols,thdCol-"+rtLayedverEle,this.pdispatchTre(dColsght=etredColxt("2d"),r=t.getBo1__dirtatchTre(dCole),i.clteout:nction(t,e){if(this._s._domRoot
_widisght=etreth,o=.shadoasght=etredCol
ndIndepx",n.style.hr+"px",this._la
varpx",n.s{vae),t=this.{vaabkia.px",n.s{vaa),t=this.{va1__dirtatchTre(dCole),i.clnn!1
unction(){return n,i,r,a=thissght=etreth,atchTre(ElCli.dom.hu/e,e.ctx
tu=(.dpr
var nr0,0,confiyerConmo)reta.shcomp),c==null!astF1===Alphaht
nrEle=doce[nuelFromStoredColr
var nrisModeColBuffon(spatchTre(dCol.",evenng),l.__eOpdCoulute"tBou"patchTre(dCol.(i.dom,0,0,=funcs/c,l/c+"gpx(0,0,g,v),i.dps,lirtuaent",o["-webk&this..ctxonfiSidts1):e||n)i=n.geGradt"][||axt("Gradt"][th)),image:n}}.join(s,e+"px",e=o.||n)i=n.geGradt"][=i.:texm,0,lse noe.dispose=ft("2=n.gePats.pn,i)},getr+"gpxrenderTr.fillreturuasseTr.fillg,v),i.dps,lir(),i.prevEl),uf(!(f=csght=etredCol
nxrenderTr.",evenAlpha=h,ge(t.dom,0,0f,i.dps,lir(),i.prevEl={pinch:h=us=v},functihn(t,e,n){var i=n(262),r=n(268),a=n(225),o=n(235).WILL_BE_RESTORED
funle:r,s(){}
var c=["csa={constructor:g,getTypes,(t.dg,v)Tlea(){this.rohis._s._domRoot
(o["-wrua.),r=g,v)sseTsedTimg__drawIze(t),this.Tleareturnn!=n&&],a=thi.),r==e[n]&&"aundInd+.storiect,tDt.dTleath)ar itar f=e?l.__slevelLi
if((e.__dni
if((e.__Tleackgrouorm(e),e.begit):itiooetBoune),tnsform(t.transfos_getoreTranvas(eleatxelRat,rordTgger&&,i.prevEl={pinch:lrts=c},functiln(t,e,n){var i=n(207),r=n(234).devic22).DElementer,o=n(217)
functi2),s(){}
var ciltiis._singleCax:lg=m.sc:lg=._singleCa.onframe,this.ondle[{}
var c=[",arLayer)ip._displayLirunn{var h=playLitindestroyme=0,this._estroyme=0,tS._pausedTime=0,thr h=rs),this.set"csa={constructor:g,getTypes,enTo)ip(t){this._backgrounr)ip.},delRoor:funp),p}r('(t){t.clear()},.addAnimafuncti=t.target;e&t("2)ip.-e[0]gth;n++){var i=e[kgrouenTo)ipr o=thover:funo)ip(t){this._bacarget;(this._roots,t)
r)ip.&(thelice(kgrounr)ip.}indexOfepushver:funp),p}r('(t){t.clear()=t.target;e&t("2)ip.-e[0]gth;n++){var i=e[kgrouer:funo)ipr o=thi},.addAnimafRenderyerStat(){var t=thi=t.targe))=nle:)-p>)odel()mvElusedTime)%this._lgetS-playLitindeomRoot
nr)ip.&ntexnull,s=r_disa_diso]gto<i l=r[o],u=s=nlientypetionach(thldIndeor(var aa)or(vaion ht.to]gto<i )nliemove=!1},fire1):lieif(i-1e(r.&d(o.,i--):or d=0,pi;o<s;o++)so]gto<i l=r[aliemme",ocliepts=n=r.this.gngleCa.onfram_hoverEleglobalout,1===n?e)ngleCax:lg=ansforme(kgroux:lg=ansformse:fgx:l._Loop(){var t=this._hoverEl
playLirunn{var 0,an(t){t.__b e(ltin_runn{vabkia_hov&&t.e)%thiwIndensformsear:function(t){var e=arget=t.this.=nle:)-p>)odel()mvElusedTime=0,this._needsRemox:l._Loop(imation(){this._renderListunn{var hunction(){this._paused=!0},resustartTimee=0,tS._pa.=nle:)-p>)odel()mvElusedTime=0,thstarfunction(){this._paused=!1}}
vardraggingTe+=e
else{va=nle:)-p>)odel()mvElusedTime)%thS._pausedTime=0,thr hfunction(){return tharLayer)ip._dieCan&&(sshed(){return this._he!kgrounr)ip.}s;o++)}function(t,e){var n,a=!1,o=t0,0,0),t,(.dpr
s||r.gap==ft("s.pdor(t)s.pthis.scale.scaor(p),p}r('PmoveHov,a)
var s==a)nch:lrts=c},functiln(t,e,n){var i=n(207),r,r,o=n(222tring,or(his.ds=0;enerowOffer:funhis.ds=0;enerowOff(t),this.chX:n.rokeossZidth:chX:n.h=n(234).c=n(222),f=n(228),d=fetre&&o(n,s)},pfind],toucers._d:1,,toucerup:1,,toucertion(1,,toucerion(hun{this.:i,"dblclick","mousewheel","mouseout","mouseup","mousedown","mousemove","contextmenu"],f=functiolout":["lout"event))"lout"ent),"lout"ntext],,toucer:,l+op0,=(t){var e=this._optsferplaxOfe","cogBottoucer n.style.croperty(f)&&(nulle)?is)}ear:,g,"d","contextme"mousedo],von:reoucertiongBottouceredo] s(){returmn!!t&&(!!tel","mouseou(i=(n=f.browsermme",fox?"DOMM","mScroll"s)}s(){retur_=this._optsfttoucertion.style."peis._dS"==lout"s._dS}s(){returyctx&&t.zrY,nhich:n.starfs(){returx(var n=0;n<t.lene&nt!1;irt9__di.toUpTn.sli!(ntextredelo],a=Zr||n&this.nName.ot=i,n=n||n) )ntexe.removeCh.style.cifs(){returws._singleCastructurn[]verElegarget,ttchTrurremoTarget,thtreterEle,toucertion
e&&toucertionverEler0t"][X=eer0t"][XverEler0t"][Y=eer0t"][Y l=i[b=wa={constru
breturf)&&agAnimafbreturImmediionf)&&agAnimafbrt.af"][Dw.getC=hRange)nch:S={","mousem(t){t.clear()}=lFromStoredispatchT_mayPtoucerCap=r,t=[rY,null).ta]verEleglobalout",this._drag)ve:function(t){var e=t.z}=lFromStoredisis.scale.get_mayPtoucerCap=r,t
gth!==,nu._dS[0](th).ta._dS[ointktxelRa_paused)tglobalout",this&&s!==ave:funcup(t){t.clear()}=lFromStoredispktxelRa_1aused)tglobalout",thi_dragut:function(t){var e=t.z}=lFromStoredispatchT_ptoucerCap=r,14159)
ontrol,n=t.zrIs=lout"!==e&&!n&sis.scale.ti(this._h!==,"wid
els._dropcalDOM
"only_gl=x,disposeused)tglobalout",thino_glob},lout"event(t){var e=t.zyct=lFromStoredisspatchT_Moment,this._la=nle:)-p>patchThis),th.sture:function,n,ithis._n,S.",this&&ss,e)},dispotn,S.",this._ds,e)},dispotn},lout"tion(t){var e=t.zyct=lFromStoredisspatchThis),th.sture:function,n,ichull}_n,S.",this&&ss,e)},dispotn},lout"eon(t){var e=thiyct=lFromStoredisspatchThis),th.sture:function,n,ient)n,S.",thiups,e)},dispotn,+nle:)-p>-atchT_Moment,this._la<30ce(S.ousews,e)},dispotn},,toucers._d:t){var e=thiS.",this._ds,e)},dispotn},,toucertion(t){var e=thi_=th||S.",this&&ss,e)},dispotn},,toucerup:t){var e=thiS.",thiups,e)},dispotn},,toucerion(t){var e=thi_=th||S.",thiions,e)},dispotn}}
hlick","mousedown","moblclick","contextmenu"],(function(t){f.prototySion(e){var n,i,ae=lFromStoredseused)tglobaloui.mixin(is.scTd],toucertion(t){var e=thi_=th||T.",this&&ss,e)},dispotn},,toucerup:t){var e=thiT.",thiups,e)},dispotn},:function(t){var e=t.z}ed)tglobalout",this&&s!==ave:funcup(t){t.clear()s.scale.get_ptoucerCap=r,141
ktxelRa_1aused)tglobalout",thi_dragurtual
ontrol,n=t.zrIs=lalout"!==e&&thiused)tglobalout",thino_globn}}
s(){returM{var r=e.ct.",tucede][nn,e3,t0;enerOpnstan=i,o0,n,i),"drop"ginPaLayers(){returC=this._optsf",tucedn=0;n<t.lent '+)eoperty(f)&&(nullvisis0,n,i),"drop"gimov o=t,e3,t0;enerOpnst=thi},",tucedatchs(){returkthis._domRT_mayPtoucerCap=r,t=._hoviwIndeptoucerCap=r,141^rty=t.ptoucerCap=r,141{positiion=t"!==e&oxy:funSc&&(
e?t,e){for(var n=(){retursize(MgetLa(i){i.virtual&=utua,x(va,r,i.eve)his.ft,e){for(var nstyle.cl0,n,i):nle:ws._sidelLa(va,o.||,i)oxy:funerse(,t.trigiear:,{cap=r,t:!0}type=toucerrol,nd&&o(n,s)}?hlick",v=i.:fpush(lrol,nd&&o(n,s)}||hlick",gBuilnitCo:Ctionhs(){returDs._singleCa,i),"dropheight=etreoxy:funeainterRo",tucedatcp=null!t0;enerOpnsatcp=nullush(l()mvis._hoverEleush(l{var hus(){returIs._sincs),this.setHandledhoverMrEle,this.p._layayers[n],onlyoxy:funSc&&(=nle:)s._S),rdraggingT"!==e&oxy:funSc&&(=nle:)screateEl,T)spatchT_ptoucerCap=r,141r h=playLimayPtoucerCap=r,t=._hovt,e){var n,a=!1,o=t0||,i)oxy:fune
pe=toucerrol,nd&&o(n,s)}?hlick",pe=toucera(i){i.virtualMgetin(e){t.on&&t.ois._(,t.trigs.ref}ice(fpush(lrol,nd&&o(n,s)}&&hlick",peush(la(i){i.virtualMgetin(e){t.on&&r.ois._(,t.trigrn(t,e){for(vty=tush(l{var 0,oop&&t.lush(l()mvie.ertion()mvno_(.lush(l()mviform&sh(l()mvis._hoform&sh(l()mvissel()mvno_((){r._paintL=tush(l{var 1orm&sh(l()mvis._hor:,700(r>0&ref}ic,hlick",pe",thia(i){i.virtualMgetin(e){t.on&&r.or=utro.||ush(l{va||ns._(,t.trigrnref}ic)},dispotrs[n],onlyoxy:funSc&&(ew o(0A=Ia={constru
Afunction(){}
var c=[C(trs[n],onlyoxy:funSc&&(e,rdrCaggingT"!==e&oxy:funSc&&(aveAr(t)},disp=t){var e=t.z}ed)ttrex(o["-elFromStoresText=[",disp=_h!),a&&s!==a},ha)
var I=t.animaO=Is=c},functiOn(t,e,n){var i=n(207),r=n(245)([[":0,c=Math"+t+"px"ion[=typokxtmenuanspan[=(!a||a[ion[=t*e,s=a.shion[=t*e,s=,l=a.shion[=t*e,s=,l=a.sYion[=t*e,s=Cuanspa]y:e},31410,cction(t){var e=this.proxi,dispotn.length=0,t0,cDashLayer(u+(o0,cDash(eh:0,c=Matho.|rs:fun0,cDash(t){var e=thinull==et(t))1sis.scale.get:fu("stru"e[0]u/2,l+o),t,2Cont4*t.style."sochLa&this.ni.height="dasheds._dS?[i,i]:[n,=tho}s=r},function(t,e){var n=M=n(207),r=n(245)([["filltmenuanspan[=t*e,s=a.shion[=t*e,s=,l=a.shion[=t*e,s=,l=a.sYion[=(!a||a[ion[=t*e,s=Cuanspa]y:e},314Areaction(t){var e=tar nstyle.ci,dispot.mixis=r},function(t,e){var n=M=n(207),r=n(214).devic09)ingRitleareturtmenuanspano},314eleaction(t){this._bacs.scale.getecModelhis.scale.scauncth"nonw(enuansp)his__bu():[:fu(a,restaers:fuFot.(){return this._heir.:fuFot.({fot.ction(e.scauncth"nonw(efot.ctionstarot.W+"px",e.scauncth"nonw(efot.W+"px"starot.tion(e.scauncth"nonw(efot.cionstarot.Family(e.scauncth"nonw(efot.Family=a},e.getecModelers:fuT,r=g,v)(t){return t<.5?.5*niingRect(),a=t.stytLayer(314Fot.(),e.scauncth"nonw(ealign"),e.scauncth"nonw(eve:funenAlign")r
var nuncth"nonw(ebase:0,c"),e.scauncth"nonw(ettom"]["),e.scauncth"nonw(e:0,cH+"px"stae.scauncth"nonw(erichstae.scauncth"nonw(etr){rorm(,r=")ixis=r},function(t,e,n){var i=n(234).device4).devi322traevi323)
func324),l=n(325),u=n(272)f(t),this.Radian,h=n(223)
h=n(271)
fui.CMD,f=)/.4)*.5+,d=[-1,-1,-1],p=[-1,-1] g(){--p||a&,a,!0)}}
varops,l,h._domh>ghth>ihth>ahth>s||h<ghth<ihth<ahth<sarseFloa0is.scc,f=u.t:fun._laAtgetinaps,h,da){fornsolarseFloa0i=0;n<t.lg,v,m=0,_s._dy=0;y<f;y=r[o],u=x=d[y],wis._bx||onsox?.5:1
u.t:funAtytLrgeto,x)<lhis_drawI_=u.t:funExtremagetinaps,rope[1]<p[0](t_leng(._di max(p[0],p[0]=e[1]pe[1]=c:,g,u.t:funAtyetinaps,rs=0;,_leng(.,u.t:funAtyetinaps,rs1]ic),2nso_?x<p[0]?m+=g<e?w:-w:x<p[1]?m+=v<g?w:-w:m+=s<v?w:-w:x<p[0]?m+=g<e?w:-w:m+=s<g?w:-we.dom},gemus(){returv&,a,!0)}}
varops._doms>ghts>ihts>a||s<ghts<ihts<aarseFloa0is.scl,u.InOut:fun._laAtgetinaps,da){fornsolarseFloa0is.sch,u.InOut:funExtremumgetinaa){fohlice(h<)1sn=0;n<t.length;u.InOut:funAtgetinaphmax(){val v=1<<p
v&gis._bd[p]||onsod[p]?.5:1
u.InOut:funAtgtLrgetd[p])<%2?-1[p]<h?c+=f<e?g:-g:c+=a<f?g:-gc.wxa&&r.e.wxa&&r.gis._bd[0]||onsod[0]?.5:1,u.InOut:funAtgtLrgetd[0])<%?0:a<e?g:-gus(){returm&,a,!0)}}
varops._dom(s-=e)>n||s<-narseFloa0is.scu=(1-(t-=2)*n*n-s*s)
d[0]=-utd[1]=uis.sch,(1/n)/bs(i-nitConh<1e-4arseFloa0iConh%f<1e-4a{engtp=tis.scc=a?1:-0===t?0:1o>od[0]+_buo<=d[1]+t?c:0}a?(u(n)?(ltro.r(ltuice(?(ltio.r(ltr+"gi>ndInd+.f m=f;m<l._<u;p++){g<2;g=1<<p
v&o|d[g!=e[nv+t>o.dom
um,(1/n)/tan2(s,v)
c=a?1:-0,mdrawIm=f+m),(m>=ihtm<=r||m+f>=ihtm+f<=ret(tm>)},sinusohtm<1ow(1024,PIight)-c:,p+=c:this.refrp}s(){retur_=ta,!0)}}lsn=0;n<t.lu,f,=0;p<u;p_u;py=0,x=0,wis;w;n++){var .dom
ub=t[w++]
switk",bnsoc.M&&wleng(n2?-1:1",p,_,y,x)}}ls)his.lowng(y=p=t[w],x=_=t[w+1]i,bincase c.M:p=y=t[w++]p_ux=t[w++]
 i,r=
case c.L: d=o.a>i[0oer:tthia.lineWp,_,t[w],t[w+1],e)}}ls)return!1(var a1:1",p,_,t[w],t[w+1],}}ls||0
p=t[w++]p_ut[w++]
 i,r=
case c.C: d=o.a>i[aoer:tthia.lineWp,_,t[w++]pt[w++]pt[w++]pt[w++]pt[w],t[w+1],e)}}ls)return!1(var a1:1gWp,_,t[w++]pt[w++]pt[w++]pt[w++]pt[w],t[w+1],}}ls||0
p=t[w++]p_ut[w++]
 i,r=
case c.Q: d=o.a>i[ooer:tthia.lineWp,_,t[w++]pt[w++]pt[w],t[w+1],e)}}ls)return!1(var a1:1vWp,_,t[w++]pt[w++]pt[w],t[w+1],}}ls||0
p=t[w++]p_ut[w++]
 i,r=
case c.A:nch:S=t[w++]pT=t[w++]pM=t[w++]pC=t[w++]pk=t[w++]pDut[w++]
w+=1is.scI=1-t[w++]pA=Math.PI*tk)*M+S,O=(t-e)*(2*k)*C+T
wle?1:1",p,_,A,O,}}ls:(y=A,x=Osis.scP=(i-S)*C/M+S
 d=o.a>i[soer:tthia.lineWS,T,C,k,k+D,I,e)P}ls)return!1(var a1:1mWS,T,C,k,k+D,I,P}ls
p=Math.PI*tk+D)*M+S,_=(t-e)*(2*k+D)*C+T
 i,r=
case c.R: d=y=p=t[w++]px=_=t[w++]pA=y+t[w++]pO=x+t[w++]po.a>i[0oer:tthia.lineWy,x)A,x,e)}}lsthiser:tthia.lineWA,x)A,O,e)}}lsthiser:tthia.lineWA,O,y,O,e)}}lsthiser:tthia.lineWy,O,y,x,e)}}ls)return!1(var a1:1",A,x)A,O,}}ls,1:1",y,O,y,x,}}ls
 i,r=
case c.Z: d=o.a>i[0oer:tthia.lineWp,_,y,x,e)}}ls)return!1(var a1:1",p,_,y,x)}}ls
p=yp_uxthis.refrn2?-u=_th;x,(1/n)/bs(u-f)<1e-4a2?-1:1",p,_,y,x)}}lsathT,le.oTraner:tthi
x",g)returULretuis.refr_=ta0,!1,_doPa,eoer:tthia.line
x",g)returULre=e.cis.refr_=taeturnLayern(t,e){var n={lieoer:tthia.line
x",g)returULre=e}
varo.a>i[s._br
if(!t||!e=(s=t[n=.lengt>e+lbuo>i+lhio<e-lbuo<i-lhia>t+lbua>n+lhia<t-lbua<n-l
if(!t||!e||tt||!1,th.sqrt(1- -/bs(a-t)<=l/2is.scu=(s=(e-i)/(t-na)*a-o+(t*i-n*e)/(t-na===t?0:1u*u/(s*s+1)<=l/2*l/2on(t,e,n){var i=n(222),r=func3)
eoer:tthia.line
x",g)returULre=
varops,l,u)?(a=r>i[s._bu
if(!t||!e=(s=h;u}(o,s)||(c>e+f&&c>r+f&&c>o+f&&c>l+f||c<e-f&&c<r-f&&c<o-f&&c<l-f||h>t+fhth>n+fhth>a+fhth>s+f||h<t-fhth<n-fhth<a-fhth<s-!=i[i.t:funPromap
PtoucurULre=
varops,l,?(a,oop&)<=f/2on(t,e,n){var i=n(222),r=func3).InOut:funPromap
Ptouc
eoer:tthia.line
x",g)returULre=
varops,l,u=r>i[s._bs
if(!t||!e=(s=h=s}(o,s)||(u>e+h&&u>r+h&&u>o+h||u<e-h&&u<r-h&&u<o-h||l>t+h&&l>n+h&&l>a+h||l<t-h&&l<n-h&&l<a-h=i[iurULre=
varopl,u)oop&)<=h/2on(t,e,n){var i=n(222),r=fun72)f(t),this.Radian,r=)/.4)*.5+
eoer:tthia.line
x",g)returULre=arops,l,u)?=r>i[s._bl
if(!t||!e=(s=c=l
u-=t,h-{positif=(1-(t-=2)*u*u+h*hitConf-c>n||f+c<n
if(!t||!e||t(1- -/bs(a-o)%r<1e-4arseFlo!0iCons.animatoa
,0,0o)
fui_hovayer oui_a)
fui_o)
a>ebkit+==a)nch:p,(1/n)/tan2(h,u=.during((drawIp+==a,p>=ahtp<=%2?p+r>=ahtp+r<=%on(t,e,n){var i=n(222),r=fun31),a=n(222)fsform(t.transf0,0,.CMD,o=[[],[],[];s++(1-(t-=2)[n=(1/n)/tan2s=r},functit,e){var n,i,r,a=this.u)?(a,tors,r.s,=0a.Mp<ua.Cp++a.L,v+a.R,m=a.Ap_ua.Qm=f;mu=0,his;u;v++)f[v].){switk",i
x[u++]ph,ulengtnincase d:case g:i=1i i,r=
case p:i=3i i,r=
case _:i=2i i,r=
case m:nch:y=],[0px=],[t,wis(S[0]*S[0]+S[oi*S[oii,bis(S[2i*S[2]+S[3i*S[3ii,S(lt-S[oi/b,S[0]/w m=[u]*=w,x[u++]+=yp=[u]*=b,x[u++]+=x,x[u++]*=w,x[u++]*=b,x[u++]+=S,x[u++]+=S,h,u+=2i i,r=
case v:T[0]=x[u++]pT[1]=x[u++]pr(T,T,e),x[hddRoT[0],x[hddRoT[1]pT[0]+=x[u++]pT[1]+=x[u++]pr(T,T,e),x[hddRoT[0],x[hddRoT[1] ht.teng;c<iu=u[lr,a=tT;(T=o[c])[0]=x[u++]pT[1]=x[u++]pr(T,T,e),x[hddRoT[0],x[hddRoT[1]tion(t,e,n){var i=n(222),r=fun13),a=n(275),o=i},n||{}),ch",tat,thor"shape,z{cmagec:n}}r0n}}rn}}this.As&&!n}}|{}As&&!n)/.4)*.5+,clockwist:!0},var _:r(ie.dispose=fvar _i,be,i.shap(t,e){var n,a=!1,o=t0eoexheighcy,a=u/2,l+o),e.r0tTop0),o=u/2,l+o),e.rp0),ightthis.As&&!s++e.|{}As&&![n=eer0ockwist,u=Math.PI*to)
h=(t-e)*(2*ohi},",veTo*u*r+n,h*r+i),e3,tneTo*u*a+n,h*a+i),e3arcroto=arops,!l),e3,tneTo*Math.PI*ts)*r+n,(t-e)*(2*s)*r+iT,le.orBrushrcroto=rps,o,l),e3r0osebuildPn nu=a},function(t,e){var n={=n(222),r=fun13)},n||{}),ch",tapeof shape,z{cmagec:n}}rn}}r0n}},be,i.shap(t,e){var n,a=!1,o=t0eoexheighcy,a=)/.4)*.5+
},",veTo*n+e.rpi),e3arcroto=e.rp0=rp_1aus,",veTo*n+e.r0pi),e3arcroto=e.r0p0=rp_0Pn nu=a},function(t,e,n){var i=n(234).devic22)fdia&&t.d r(t){this._tULre=e}
varo.a],u=s=)*t*n-t)[n=)*t*i- p.during(2*(e-n)+s+l)*o+(-3*(e-n)-2*s-l
*a+s*r+e}=r},functit,e){var n,i,r=0;n<t.lenn=this._ha_diso]gs++1th;s u=o[t+=iur[s-1],th={}is.scl,o/2i=0;nl=l<n?n:llength;l u=o[s]
thi)?(a,tos/(l-1)*(e?n:n-1max(u/2,-flo0;nfgth
f-dp++t[d%n]
e?(u(t[(d-1+n)%n],c==[(d+1)%n],c==[(d+2)%n]s:(u(t[s._bd?d:d-1],c==[d>n-2?n-1:d+1],c==[d>n-3?n-1:d+2{}is.scv=p*p,m=p*v
a)or(va[;mu[0],g[0],h[0],c[0],p,v,m),amu[1],g[1],c[1],c[1]pe,v,m)]c.wxa&&r.aon(t,e,n){var i=n(222),r=fun14),a=,a)
n,o=i}+o)
fuie),i.cElClidia&&t.dhu/e,add,u=ct(0onexOfie)ubs=r},functit,e){var n,i r=e.ctx,ac,f,=pe,gthis.thismthis_thie?e.slid=[1/0,1/0],p=[-1/0,-1/0 c=0,f=l.ly=0,x=n++){var y<x;y=r[r(d,=pt[yii,a,p,ppt[yii
r(d,=p(s=0;,a,p,ppi[oii ht.ty=0,x=n++){var y<x;y=r[ctx,aw=t[yi
 d=o.c==[y?y-1:x-1],f==[(y+1)%x]
ull==t||s._by||ynsox-1m{g)or(vau(t[yii)
er:tinue}c==[y-1],f==[y+1]}",v=f(a=,o,v=vh(thom
ub=s(w(a=,S=s(w(fgtT=b+S
le.oTawIb/=T,S/=T=,o,m=vh-b=,o,_=vhSthom
uM(lthisw,m),C(lthisw,_)m.para(M,M,d),amM,M,p;,a,C,C,d),amC,C,p)),g)or(vaM),g)or(vaCc.wxa&&r.n&&g)or(vag.shifnsertgon(t,e,n){var i=n(222),r=fun13),a=n(212traevi223)
fua.InOut:funSubdividdowOfft:funSubdividdolua.InOut:funAn.roket:funAtxOf,cInOut:funDerividth:Atxcoket:funDerividth:Atxfthier(t){thisdar i=n(222),r=e3rpx2oundicpy2ull!=m.posit._ba)return
=r?[(n?c:u)(t.x1ormrpx1ormrpx2ormx2oe),(n?c:u)(t.y1ormrpy1ormrpy2ormy2oe)]:[(n?h:l)(t.x1ormrpx1ormx2oe),(n?h:l)(t.y1ormrpy1ormy2oe)]}nch:p,i},n||{}),ch",tabezier-cur&s!=hape,z{x1age:1agex2age:2agerpx1agerp:1agepercent}1matiy:0,itypokx:"#000",fillrestar,be,i.shap(t,e){var n,a=!1,o=t0eox1oeighy1ohis.x2odth(y2on=eerpx1ou=eerpy1oh=eerpx2xcoemrpy2od
e&&ercent
le.ordrag,",veTo*npi),eturn
h)return
c?(d<eng(o*nplgetd(fgtl=x[1dingf[2],o,s.u)atd(fgtu=x[1diagf[2]),e3InOut:funCur&sTo*l,u)is,ts:(d<eng(s*nplghgetd(fgtl=x[1dihgf[2],ngf[3;s+,s.u)c)atd(fgtu=x[1dicgf[2],agf[3;eBrushzierCur&sTo*l,u)?(a,is,tsn},,toucA)(t){return t<.5?.5*ndFromSt.z,z2:t, hfuntull}ucA)(t){return t<s.scaldFromSt.z,z2:t, 0n.style.cro(t),this.learRn nu=a},function(t,e,n){var i=n(312)
funcn13)},n||{}),ch",taarc shape,z{cmagec:n}}rn}}this.As&&!n}}|{}As&&!n)/.4)*.5+,clockwist:!0},tiy:0,itypokx:"#000",fillrestar,be,i.shap(t,e){var n,a=!1,o=t0eoexheighcy,a=u/2,l+o),e.rp0),o=htthis.As&&!so+e.|{}As&&![s=eer0ockwist,l=Math.PI*ta),u=Math.*(2*ahi},",veTo*l*r+n,u*r+i),e3hrcroto=rparop!sPn nu=a},function(t,e,n){var i=n(234).devic23),a=,a,n||{}),ch",taManuaunt),hape,z{ge:fs:RenderyerStatshapD_dra:){var t=thi=t.targe))ggingTg__drashapgetSize(hape,.ge:fs[0]gth;n++){var i=e[khis._m
i&&(__drashap
ggingTg__drashapheight=e,__used=!ht=e,__used||tr,bh(r),t.bru(){return tharLayeerStatshapD_drar r=0;r<e;)ttSize(hape,.ge:fs||hisale.get:fuG!==e&S,i.cle[0]gth;n++){var s,l,vel
.ge:f||trse(,isModshapProxar rvel
.ge:f(e),t,i.cle[0],S[oirvel
.segteElIgnorm(hr n=olnimabe,i.shap(t,e){var n,a=!=0;n<t.lene.ge:fs||hisength;i++){var r=n[ns._((e,i.shapet,ns._(.z,z2:tarfuh(r)}},get:){var t=thi=t.targe))gginghape,.ge:fs||hisal0;e;n++){var e,l,veei&&(__drashapr hunngRect(),a=t.st(){return this._height},_erStatshapD_drar ,ie.dispose=ft("ect(),a=t.sts),this.set" nu=a},function(t,e){var n=M=n(207),r=n(234).devic49)ingx",g)returULre=e}atharLayx=null==e?.5:eight=ey=null==e?.5:ayers[nr=null==n?.5:ayerConvas"
vradtaliused)t"!==e&=a._updrs),this.seayer
a)o{constructor:g,getTypeaov,ainherit*ta==a)nch:fuas=r},function(t,e,n){var i=n(234).devic34)ainherit*.device6traevi215n s(){returon t<.s,e)},dispotn,ght},_leSortFunc)._displayLitenuararyDeSortFunc)._displayLi",disp=eedsRem&!e||l.cme:foe.dispose=fal=!0,o=1):l=thie.dispose=frtionDeSortFnc)._){return tharLayeleSortFunc)._displayLitenuararyDeSortFunc)._displayLi",disp=eedsRemd_drar ,dsRem&!e||l.cmehunie.dispose=faddDeSortFunc)it,e){var n,i,re?playLitenuararyDeSortFunc).},delRoo:arLayeleSortFunc).},delRooedsRemd_drar unie.dispose=faddDeSortFunc)tit,e){var n,i,rhis._upn=0;n<t.length;n++)if(t[n]!=e.scaor(DeSortFunc)[n])re:funie.dispose=fick"Pe(),a=DeSortFunc)it,e){var n e=this._hoverElem",disp;e;nrLayeleSortFunc).}+){var e,l,v&&t(nrLayeleSortFunc).eei r=0;ral0;e;nlayLitenuararyDeSortFunc).}+){var e,l,v&&t(nrLayetenuararyDeSortFunc).eei unie.dispose=ferStat_){return tharLaynsform(),t&&t.brur=0;r<e;)ttSize(m",disp;t;nrLayeleSortFunc).}+){var t,l,(omRoot=theSortFunc).et])xe.remo=disposansformse,exe.remo=.__st=0;rtl0;t;nlayLitenuararyDeSortFunc).}+){var t=r[ctx,ae;(omRoot=ttenuararyDeSortFunc).et])xe.remo=disposansformse,exe.remo=.__s}unie.dispose=fvar _it,e){var n,i,r=0;n<t.lennize(m",disp;n;nrLayeleSortFunc).}+){var n]!=(imRoot=theSortFunc).el
i!sh&&t.beforeBiush(r),t.brustPath(.brust,nzlevelLis",disp?.__s:arLayeleSortFunc).vel||Pathh&&t.afterBrthh&&t.after=thi=0;rtlayLi",disp=n[0]gth;nlayLitenuararyDeSortFunc).}+){var i=t[n]
i.s;(imRoot=ttenuararyDeSortFunc).el
i!sh&&t.beforeBiush(r),t.brustPath(.brust,s._bn?.__s:arLayetenuararyDeSortFunc).ell||Pathh&&t.afterBrthh&&t.after=th}playLitenuararyDeSortFunc)._displayL&!e||l.cme:fl.__slehieoe.dispose=ft("ect(),a=t.st_){return th||t.llayLir.sthi=t.targe))nle:a(1/0,1/0,-1/0,-1/0),al0;e;nlayLileSortFunc).}+){var e,l,is._domRoot
n.eSortFunc).eeiontext("ect(),a=t.stylt(0onerurnect,t"only(),t&&t.bruBrthhform(t.transfoext(""only(),t&&t.brsreBruunvirtua}llayLir.st=this.refreshHoir.stunie.dispose=fer:tthi
x",g)returUL,is._domRoot

if((e.__CoordM
"onlythis._needsMant("ect(),a=t.stylt(r:tthi(n[0],ns1]ic=0;i<this._zlevelLisleSortFunc).}+){var i]!==e[noot
n.eSortFunc).e._(,r:tthi(his.
return!1}(o,s)||(s,irevElis.scl,os=c},functiln(t,e,n){var i=n(207),r=n(245)([["filltmenuanspan[=typokxtmedth:0"Cuanspan[=:0,c=Math"+tdth:0"W"px"ion[=(!a||a[ion[=t*e,s=a.shion[=t*e,s=,l=a.shion[=t*e,s=,l=a.sYion[=t*e,s=Cuanspa,RitleaPabsolutpa,RitleaAlign"a]y:e},314Itenction(t){var e=tar ns._domi,dispot.mi,tLayer(1e5Bth:0"o0,cDash(n.style.crual=et0,cDashLrrtLay1e5Bth:0"o0,cDash(){var t=this.getLayer(314(tdth:0"Ttru"e.style."sochLa===e)return
t?.__s:"dasheds._dt?[5,5]:pdatexis=r},function(t,e){var n=MtL=t},functi{1e5BtxLayoutParamn(){return this._la{lsetLeyer(314(tlsetstaeetTo.get:fu("soptBou"px",e.scaunc(eripx"stab]
if(:ayer(314(tdt
if(n)}.join(ayer(314(t+"px"i),e+"px",ayer(314(tt],i=[")tion(t,e,n){var i ns._dom""
"t()ef0,cLa&ti[r]:r,navig}r('lse nnavig}r('.ortte.__||""}
n.ctx.snuans:["#c23531"+t#2f4554"+t#61a0a8"+t#d48265"+t#91c7axtme#749f83tme#ca8622tme#bda29a"+t#6e7074"+t#546570tme#c4ccd3pa,gradt"][Cuans:["#f6efa6"+t#d88273tme#bf444ctiollearetur:{rot.Family(n.mment(/^Win/)?"Microsoft YaHei":"sf((-serif"arot.tion(12,fot.ction("(t),th"arot.W+"px","(t),th"mab+){dMode:Rend,.addAnima:e[n])r,.addAnimaDuCoulut:1e3,.addAnimaDuCoulutUrStat(300,.addAnimaEavas&:"},fun"][talOo_gl.addAnimaEavas&UrStat("t:funOo_gl.addAnima(hr n=oln:2e3,veLayers,(f(hr n=oln:3e3,veLayers,(f:400,h:function(hr n=oln:3e3,useUTC:|(su=a},function(t,e,n){var i=n(234).devic34).devic08traevi220),igifick"ElCli(0onexl=i}+op,u=ct[t],!,h=/^(min|max)?(.+)$/ s(){returc_backgrounapiheight=e,thist0,cOpretu._displayLimedii=this._lplayLimediiDw.getCsplayLi",dremoMediiI(),c)._displayLiopretudColupedsManualwBascOpretu}s(){returfar r=i.createnaps_disls._laye.thist0,c_need.bascOpretupara=d.bascOpretu),(uh!==opretus)para=a._sins=(==opretus||hi).sdexOfreBrumedii){a=a._sie=(s=h=rumedii
o(hn(t){t&&t.ctx&&t.ctopretupare3Inery?l},delRoo:r||(tLaear:fuwxa&&r.asfor=e&&a.thist0,csform=hist0,c=u=,o,e(t,,r:catrsr,,r:catri}+op(l,(t){return!!t&&(!!t ctopretu}ic),(t){return!!to(en(e){t.on&&t.oenitCoref}ic,{bascOpretu:a,thist0,cOpretu.:s,mediiDw.getC:r,medii=thi:lnhs(){returdar i=n(222),e},.join(e,e+"px",n,asp.stCoulu:e/Laya=!1}(o,s)| is._prog,(t,e,n){var i ns._dome.mment(hitConr(),[ge(nn[2])234).dev[oir}if(2].t
"owerCasOfr;(t,e,n){var i=n(2&&(!!teliis._dn?t>=t("maxs._dn?t<=t(urn!1})oclie,igiesfor= hfu}ic,a}c)o{constructor:g,getTypecrounOpretu:t,e){var n=MtL=Brth._proro(t),this.ToArraundiseries)n(t){t&&t.ctx&&t.ct,r.sBrthisTtrudArraundi,r.suBrtheftisPrimidth:ndi,r.surefre=i=this._dn)?(a=playLiopretudColuped=fe,e)},dispotaetucpts=n=r.alwBascOpretu=d.bascOpretu,c1):ec.bascOpretu,h=d.bascOpretu,o(h
h)rsin(t,e,n){var i nt&&(i.widt)234).dev[et||a==operClass>0&&tt=ro(t),this.ToArraund)xOf(n(t),this.ToArraunia)nch:fur}+oppt],a=Exthi+,s.thiv[et=lrev(t){return!!t&&(!!t ctopretut.ctexthi?u(ctexthi,ctopretu._layetexthih!==opretufor(var av[et=u,s.tp_0Pn n),d.thist0,cOpretu.}+){varight.thist0,cOpretu.=d.thist0,cOpretu.),d.medii=thi}+){varight.medii=thisd.medii=thi),d.mediiDw.getCight.mediiDw.getC=d.mediiDw.getC)o:arLayeopretudColup=dve:funnOpretu:t,e){var nhis._opts,n=["widetudColuphis.scale.sca,thist0,cOpretu._l(e.thist0,cOpretu.,etHandleimedii=thisl(e.medii=thi,etHandleimediiDw.getC=s(e.mediiDw.getC)splayLi",dremoMediiI(),c)._disi=t?e.bascOpretu:s=n=r.alwBascOpretuers:fuThist0,cOpretu:t,e){var nhis._opeomRoot
nthist0,cOpretu.tConreturn!0
222),r=e3edStyleun"][("shist0,c")m.pare=s(n[iingRC,dremo_draw(),delLe.dom},getrs:fuMediiOpretu:t,e){var nhis._opeozlevelLisapi(),o=e.getHerevelLisapi(),os=r.stylelevelLismedii=thi,o=playLimediiDw.getCsu_dishthie?e.!a}+){varig!o,th.sqrthr=0;r<e;)ength;r++)i=a[rc<fu=u[ld(a[c]3Ineryto=r)re(),delRce.style.!u}+){varigebkiu=[-1]re()+){varighc=u,ennize(m",dremoMediiI(),c).,e.johi(tme)__di.johi(tme))parh(ltuv(t){return!!t&&(!!t s(consot?o=opretu:a[t]=opretuf}ic)splayLi",dremoMediiI(),c)._u,h{pinch:p=cu=a},function(t,e,n){var i=n(312)
funcn34).deifick"Eo=i}isArrau,igifo=i.map
,l=n(341),u=n(208tn(t),this.ToArrau s(){returun!!t&(hn(t){t&&t.ct.oe[0]ialeli!(S[oiialeet(t)[S[oi]=)[S[0a]yfor(=(s=h=[["xtmelsetsa,Riy),"lopsa,Rix2tmeripx"sa,Riy2"+tdt
if(nudicg["grght="geogBottre)}lick"legent),"loolboxtmetiturtmevisualMadown,r.sZof(n,"shist0,c"]s=r},functit,e){var n,i,rss._siddiseries=lFriseries)nrFriseriesv(t){return!!tengtn!!his._optsfstru
eng=:0,cs._dS)oop&&t.lr)ipOfunflowpare3r)ipt.lr)ipOfunflow(function("pies._dS"==gaugcs._dS)oop&&t.lr)ockWisepare3r)ockwistt.lr)ockWise(function("gaugcs._dS)ns._domt,e){var n,i,rhis}indet(tme)n=0;n<t.lentsength;e)+){varigoop&&te nn(nn[e[ia]y i]!=;ll!=m.polnitottoucer.nuansp)
oop&&tn(nt,e){var n,i r=e.chis}indet(tme)n=0;n<t.l_zlevso]gto<e)+){var-1 l=r[eturn
a[r=elie]para[r]={}lelea[r]
eturn
a[elie]para[elie]=uilnit"itenction.nuansptCorun!!n n),di,r.sRull}pare3visualMad=di,r.sRull})nrFcn(t){t&&t.ct.o<t.lent[et|upara(nesfon=el
inrFnv(t){return!!tun!!n)ear:fun(t,e,n){var i=n(234).devic34).devic08traeifick"Eigifo=i.map
,l=["areactionck"l0,cctionck"toUpctionck"l0,kreturtmenhordctionck"lablick"labliL0,c"]ss(){returl nhis._optst.ctitenctiontContn=1;n<t.lengtp=.}+){var i<r i=t[n]
i.a=eachBo+e.(t),thon=eeempperiswebkoe(tt(t)[a]=)[a]._singe(t,(t),th?ct[t],!(ge(t,(t),th,oe(to:ae(t,(t),th=oe(t,oe(ts._hofoawIne(tt(t)[a]=)[a]._singe(t,empperis?ct[t],!(ge(t,empperis,le(to:ae(t,empperis=le(t,le(ts._hofnhs(){returuar i=n(2needt.c[ett(t)[St,(t),th||tret,empperis)(222),e})[St,(t),thzlevret,empperis
ndInn?t)[St,(t),thevret,empperisrevEl=nu,a&&s!=st)[Sttr+":)[StLrrtapare3empperisre3empperis._sing3empperis[StLafnhs(){returhn!!tun!t"itenction"re(n!t"l0,cctioncre(n!t"areactioncre(n!t"lablicre(n!t"labliL0,c"),(n!t"uppunctblicre(n!t"edgectblicr}s(){returc_b i ns._domo.get(teeiontolvisii.),r=ctiontConin=1;n<t.la]gs++r.TEXT_STYLE_OPTIONS}+){var a<s;a=t[e+r.TEXT_STYLE_OPTIONSe(t,ioperty(f)&&(nulle)dInntan=ieei us(){returfarx&&t.zustPacn!t"lablicreg3empperis&&cre3empperist"lablicr)hs(){returdart<.5?.5*niiisArrauart?t:t?[t]:[]hs(){returpart<.5?.5*(iiisArrauart?t[0a:e)hi{}}=r},functit,e){var n,i,ra(dndiseries)n(t){t&&t.ctx&o.get(t){return!!tengtn!!hil nh,ustPacn!t"lablicrecn!t"uppunctblicrecn!t"edgectblicreg3empperis&&(cre3empperist"lablicr,cre3empperist"uppunctblicrecn!3empperist"edgectblicr)_laye.,"bkPtouc)dInlimovd=o.)_lrye.,"bkL0,c)dInlirn(ttr+"is.scale.,"bkAreaar()ontnis._dn)_zlevi,r.s
eng=grap"s._dsfstru){a=a._t.toUpsl.__slevet0,ks._t.edge.tCon_comthisTtrudArraunsic=0;i<thid]gtd<.}+){var d=t[0)|0d])m.s._prog.rormgoriesv(t){return!!thn!!n)eeachacomthisTtrudArraunaic=0;id]gtd<a}+){var d=t[0)a0d])m.f(laye.,"bkPtouc)dIni,r.su{nch:p=ni,r.s
=0;id]gtd<p}+){var d=t[0)p0d])eachlrye.,"bkL0,c)dIri,r.su{nch:+c+f,r.s
=0;id]gtd<g}+){var d=t[iiisArrauag0d])?(fag0d]s=0;,fag0d]s1]ic:fag0d])}"gaugcs._dsfstru?(cn!t"axthctblicrecn!t"titurtrecn!t"detaiicr):"tree+ops._dsfstru?(u(ct i,rdcrumbt"itenction"re.s._prog.,i=e[sv(t){return!!thn!!n)e):"trees._dsfstru&&rog.,iaveet" n!!n)eositiioRixAxthck"yAxthck"radtusAxthck"as&&!Axthck"vas&&!Axthck"ttre)}liAxthck"radar"ear()n),delR"valu!Axthck"rormgoryAxthck"logAxthck"shisAxthc;,a,nn(t){t&&t.ct.oa(dndeei n(t){t&&t.ctx&&t.(cn!t"axthctblicrecn!.axthPtoucert"lablicr)hef}ic,a(dndittre)}li)=(t){var e=this._optst.ctttre)}liAxthDw.getC
c(et"axthctblicrecnr()},axthPtoucert"lablicr}ic,a(dndi,i.cndar)v(t){return!!tun!t"itenction"recn!t"dayctblicrecn!t"monthctblicrecn!t"yfunctblicr}ic,a(dndiradar)v(t){return!!tcn!t"n===nr}ic,a(dndigeo)n(t){t&&t.ctx&o.get((farx,a(dndiregetu.),(t){t&&t.ctx&fn!!n)ear:f,a(dndishist0,c),(t){t&&t.ctx&fn!!e(n!t"lablicre(n!t"itenction"re(n!t"ct.zrIsctionck=n&&],a=eevi,r.s
eiisArrauae)Brth._proev(t){return!!te,o=i.map
.get(t(n!t"lablicre(n!t"itenction"r)hef}ic,a(dndiloolbox)v(t){return!!tun!t"ict.ction"reandifea=r,tv(t){return!!tun!t"ict.ction"rhef}ic,c(pn!.axthPtoucer)t"lablicr,crpndilooltip),axthPtoucert"lablicr}n(t,e,n){var i=n(312)
funcn34).deif,isModHashMadraeifick" s(){returon t<aog,(t,e,n){vai=n(312)
fu[dingLNaN,NaNisa_dhtthickResetCDhisnsetu.htthickedOfunDhisnsetuhBo+e.,r.s,s=eeisShickedBy_drawon=o}+op(a,(t,e,n){vaa,l,u=r=(s=h(a,too(314(htthickedDhisnsetu.u)m.f(isNaN(f.
return r
s?coo(314R.__star(u):hoo(314(htthickedByDhisnsetu.u)m=0;i<thid]NaN,p=n-1 p>(){v--u{nch:+ct[pie?e.s._(c=g.,r.s.t.__starOfag.shickedByDhisnsetu.hic,c>()<<p
v&o|g.,r.s.1e5ByR.__star(gtthickResetCDhisnsetu.citConflice(v>0||f<ice(v<)<<f+=v,d=vi i,r=}this.refri[0]=xpi[oi=d,in)eoo.hostModelheftDr.sar ae.,r.s=lhef}=r},functit,e){var nhis._optr(nu=a}ck"Series((t){var e=this._on=e3edS("thick")
 d=o.a12)
fu:[:fu(nesfor(t),nn[]BoundingRDr.satrae{thickResetCDhisnsetu:rft("2=lculAnimaInfo("thickResetCDhisnsetucr,thickedOfunDhisnsetu:rft("2=lculAnimaInfo("thickedOfunDhisnsetucr,thickedDhisnsetu:rft("2=lculAnimaInfo("thickedDhisnsetucr,thickedByDhisnsetu:rft("2=lculAnimaInfo("thickedByDhisnsetu"re.sShickedBy_draw:rft("2=lculAnimaInfo(".sShickedBy_draw"re,r.s:r,seriesModel:t}e?e.!a}thickedDhisnsetu||!a}.sShickedBy_drawcoma.shickedByDhisnsetuhis._widi)+){varigibeft2=lculAnimaInfo("thickedOnSeries"pi[i)+){var-1].seriesModel ,ie.delRa!n n),=fick"(or}n(t,e,n){var i=n(312)
funcn33t,e)trieveR._Valu!,a=n(216traerft("TooltipM"bkertfur}e.__atTpl,l=n(208tnt("Tooltipanvas:Modeon=/\{@(.+?)\}/g,ui{1e5Dr.sParamn(){return rUL,is._domRoot
ngRDr.sarRecmRoot
ngRR._Valu!(t.mi,tLn(314R.__star(t)
funeossZime(t)[n=n(314R._Dr.sItenn!!e(=n(314ItenVisualn!t"ctansp)
h=n(314ItenVisualn!t"dth:0"Cuansp)(a=playLecModel3edStyleun"][("sooltipstar=c&&caunc(ernvas:Mode"re,=snfgth
playLmaintionvg="seriess._dp,v=n(ct"]Output.style.{cyleun"][tion:p,cyleun"][Subtion:gginghubtion,cyleun"][_draw:ggingcyleun"][_draw,seriestion:g?gginghubtion:Rend,series_draw:ggingseries_draw,series_d:g?ggingid:Rend,seriesZime:g?ggingn===:Rend,n===:oe,r.s_draw:re,r.s:le,r.stion:e,valu!:i,nuans:u,dth:0"Cuans:h,dhisnsetuZimes:v?v.dhisnsetuZimes:Rend,encode:v?v.encode:Rend,m"bker:a({nuans:u,rnvas:Mode:d}),$s._s:["seriesZime"t"n===n,"valu!"]}rs:fuFo__attedctbli:t,e,n){var i=n,is,trhis._"(t),th"l.__slevelLingRDr.san!e(=s(314ItenModel(p),c==null1e5Dr.sParamnnitCo
]&&"aundIh.valu! ina&&t.dof Arraut.zu.valu!=u.valu!(f(se=(s=c=uaunc(e(t),th"._dS?[a._"lablick"fo__atter"e:[e,a._"lablick"fo__atter"ee.style."t,e,n){v r?i[r]:r,c?zu.a&&tueainh.dhisnsetu_draw=r,crhe):"typeof r?i[r]:r,c?o(c.hiferplaxOfl,(t,e,n){vai=n(312)
rtexnull,s.style."[s._dn.charAt(0et("]s._dn.charAt(r-1)dInn=+n.sdexOf1,r-1)Rec(potauf}ic:._di mrs:fuR._Valu!(t){var e=tar nstyle.ci,disp
ngRDr.sarRe=avee.__atTooltip(){return thxis=r},functiun(t,e,n){var i=n(207),r=n(249).devic04)aisF,e,n){vrae{,isModOnAllSeries:urnpere.__R._Series:urnreeft(){return rUL,is._domRingRDr.satraere3visualCuansAcre:fPe:f||"itenction.nuansp)}indet(t.")
fut[:fu(a,,l=!r(or||o ina&&t.dof i?.__s:owebk!s._(o=e3edStyansFromPi.cttere3n===,Rend,eauncteries&&(t.(ic)snbeftVisualn"ctansp,olis.scl,re3visualBth:0"CuansAcre:fPe:f||"itenction.dth:0"Cuansp)}indet(t.")
uut[:fu(l)
 d=obeftVisualn"dth:0"Cuansp.u),!eeisSeriesFilteredart
return s()n)ick"((e){t.on&&t.oibeftItenVisualnet"ctanspsi=tl1e5Dr.sParamnne)ear:f,{,r.sEck":noperItenOpretu?){return rUL,is._domRingRItenModel(eContext("aa,_pautLn(314fl,=n&&]&&"auit.cteftItenVisualnet"ctanspsi.scale&&rt.cteftItenVisualnet"dth:0"Cuansp.r)}:Rendexis=r},function(t,e){var n={=n(222),r=fun34).devi346traevi233t,e)trieveR._Valu!s=r},functit,e){var n,i,r,a=thu:[:fuModel("aria")
 d=o3edS("thow"r) d=o3edS("descripretu"r)tbeftight=o+"px"aria-lablicko3edS("descripretu"r)
ull==nch:fu0
ea}ck"Series((t){var e=t,i,r++o})splay)e=(s=t[n=o3edS("dr.s.max&&(t.")r
10e(=n(314("series.max&&(t.")r
10eh=(t-e)m(2*o.u)m.f(!(o<1)(222),c_){return ths.getL:[:fuModel("titurtr=opretuhis.scalet.ct+){varight(t[s]ush(i)
),r=}(nus=c?drpn"general.withTiturtre{titur:c}):pn"general.withoutTiturtrositif=[]
s+=drpno>1?"series.multipon.prefix":"series.vas&&!.prefix"re{series&&(t.:o}),=fick"Series((t){var e=t,i,rCont<h,r,a=thissgaunc(e(===nr,l="series."+no>1?"multipon":"sas&&!")+t."
n=drn=p(i?s+"withZime":s+"withoutN===nr,{series_d:tgseries_draw,seriesZime:gaunc(e(===nr,leriestion:(_m.scubtion,rgseriesfstruZimes[_]||"自定义图"rheis.scu=RingRDr.sat
window.,r.s=u,u.nu(t.(i>l?n+=drpn"dr.s.par[talDr.snr,{.eSortFCn",e=o:n+=pn"dr.s.allDr.snrr=0;r<e;)en[]p++){g<u.nu(t.(i;g=1<Cong<l<<p
v&o|ueossZime(g),m=a(u,g)
ce.delRdrpnv?"dr.s.withZime":"dr.s.withoutN===nr,{n===:v,valu!:mhef}n+=c.johi(pn"dr.s.settrer('.middon"r)+pn"dr.s.settrer('.ent)n,fe.delRnr(=(s=_r:f,s+=f.johi(pn"series.multipon.settrer('.middon"r)+pn"series.multipon.settrer('.ent)n,tbeftight=o+"px"aria-lablicks)nhs(){returdar i,rCon"typeof &ti[r]:r,t
return tositiion}(o,s)| is._proen(t,e,n){var i nntexerplaxOfnle:RegExpn"\\{\\s*"+e+"\\s*\\}t="g"Re=avc)snhs(){returpart<s._optn(314(t)=e[n]&&"_dS)n=0;i<this.t}indet(t.")
aerfariaso]gto<i}+){var ++o)lea[ilie]}(o,s)| a.dom},getron(t,e,n){var i n=t},functi{legent:{sel,thor:{a_s:"全选psinverse:"反选p}},loolbox:{var _:{titur:{r.st:"矩形选择",polygma:e圈选pst0,cX:"横向选择",t0,cY:"纵向选择",keep:"保持选择",ction("清除选择"}},dr.sView:{titur:"数据视图",lang:["数据视图","关闭","刷新"]},,r.sZof(:{titur:{zof(:"区域缩放",dCol:"区域缩放还原"}},magiction:{titur:{t0,c:"切换为折线图",bon("切换为柱状图",thick("切换为堆叠",tiled("切换为平铺"}},,i.prev:{titur:"还原"},r f=Asom,0,:{titur:"保存为图片",lang:["右键另存为图片"]}rsseries:{struZimes:{pir:"饼图",bon("柱状图",t0,c:"折线图",scatter:"散点图",eff.stScatter:"涟漪散点图",radar:"雷达图",tree:"树图",treemap:"矩形树图",boxplot:"箱型图",cxy:fustick("K线图",k("K线图",hsMomap:"热力图",map:"地图",ttre)}li:"平行坐标图",t0,cs:"线图",grap":"关系图",sankey:"桑基图",t,enli:"漏斗图",gaugc:"仪表盘图",tithortalBar:"象形柱图",themeRiver:"主题河流图",sunburst:"旭日图"}rsaria:{general:{withTitur:"这是一个关于“{titur}”的图表。",withoutTitur:"这是一个图表，"rsseries:{sas&&!:{prefix:"",withZime:"图表类型是{leriestion}，表示{seriesZime}。",withoutZime:"图表类型是{leriestion}。"},multipon:{prefix:"它由{series&&(t.}个图表系列组成。",withZime:"第{series_d}个系列是一个表示{seriesZime}的{leriestion}，",withoutZime:"第{series_d}个系列是一个{leriestion}，",settrer(':{middon:"；"}|{}:"。"}}},dr.s:{a_sDr.s:"其数据是——",ttr[talDr.s:"其中，前{.eSortFCn"}项是——",withZime:"{n===}的数据是{valu!}",withoutZime:"{valu!}",settrer(':{middon:"，"}|{}:""}}}un(t,e,n){var i=n(234).devic34).devic09traevi217)
fu.4)*.5+
},},functit,e){var n,i,r.dpr
s|=nu,a&&s!=stee{t,r=:"loam"]["olleaCuans:"#000",fot.tion("12px",maskCuans:"rgba(255, 255, 255, 0.8)),haowSpienlr:urncuans:"#c23531"+spienlrRadtus:10e:0,c=Math:5,z,i=e[:0}eositiionle:r.Group,l=nle:r.t.sty{tiy:0,ifillre.mmskCuans},z,i=e[:e.z,i=e[,z:1e4}urneadd(slis.scl,e.fot.tion+" sf((-serif"au=nle:r.t.sty{tiy:0,ifillr"none"ollea:e.llea,fot.:l,tleaPabsolut:eripx"s,tleaDia&&t.d:10etleaFillre.lleaCuans},z,i=e[:e.z,i=e[,z:10001})
 d=o3add(u),=fhaowSpienlr=r=(s=h=nle:r.Arcy{tape,z{this.As&&!n-o/2}|{}As&&!n-o/2+.1,r:s}inienlrRadtus},tiy:0,itypokx:n.nuanse:0,cCap:"raunt),:0,c=Math:eh:0,c=Math},z,i=e[:e.z,i=e[,z:10001})
h.unctionSape,(=n&.when(1e3,{|{}As&&!n3*o/2})tthis.("circulArInOo_gc,hlunctionSape,(=n&.when(1e3,{this.As&&!n3*o/2})tdelay(300)tthis.("circulArInOo_gc,o3add(hc.wxa&&r.nxersion_){return ths.genokeoss=e.gete.llea,l ,i==fhaowSpienlr?s}inienlrRadtusn}}r==tl1e5=e.getH-2*i-(=fhaowSpienlr&&n?10:0)-n)/2-(=fhaowSpienlr?0:n/2)
fut[:fus=r.styl/2
=fhaowSpienlr&&f(e),tape,({cmarec:no}),u(e),tape,({mar-i,:no-i,.join(2*i,e+"px",2*i}),s(e),tape,({ma0,:n}}.join(a(),o=e.getHee+"px",a[:fus=r.styl})},nxersion(oveHovt,e,n){var i=n(312)
funcn34).deifick"Eo=i}+op,igifo=F,e,n){vrseif,isModHashMadrl=i}ange,h=n(251)f,isModTmsk
h=n(238tnt("UID.c=n(270),f=n(283re,=n(208tn(t),this.ToArrau s(){returp n,i r=e.cplayLecIna&&t.dheight=eapihayers[nunf&(sshed,ennize(mdr.sPture:foroxy:funean.sdexOfRecmRoot
_visualoxy:funeai.sdexOfRevelLisalloxy:funean.,r:catriRevelLisa&&gdTmskMad=s(r(=(s=g=pa={constru
s(){returv&,a,!0)}}su{nch:o
s(){returs=tar nstyle.ctbeftD_dra&&(!tmd_draMad._t.d_draMad(314(ht__pipst0,c.idef}a=a._sinr(en(e){t.on&&t,rth||t.a3visualtion||a3visualtion._dS3visualtionu{nch:lon=ta&&gdTmskMad(314(htuide,h=lgseriesTmskMad
h=l.:funallTmskiConh.ctx,ac,f=hlul}ucStubMad
f)ick"((e){t.on&&t,rssa,eet(t)md_drar ,cstarfic,c&&f(d_drar ,m(h,ia)nch:dut[:fuPere.__Args(h,a.b)ock)
f)ick"((e){t.on&&t,rt.pere.___hovic,o|=hlpere.___hovunctiure()ick"((e){t.on&&r}lsn*ta==adIri,_drar rs.scu=RingRPere.__Args(r,a.b)ock)
u(ekip=!e.pere.__R._Series()n)isSeriesFiltereda0oer:tlea.model ,m(rpi),o|=rlpere.___uar:funreBruunf&(sshed|=o}g.,i.prevDr.s=t,e,n){var i n=t,i.prevDr.s(eRevelLisa&&gdTmskMad)ick"((e){t.on&&t,r],a=eevi:funallTmskir()},d_drar usn},gingRPere.__Args=t){var e=t,i,rContt__pipst0,c,is._domRoot
npipst0,cMad(314(tt__pipst0,c.ideontexer:tlea.de!r()n),eLayers,(fEnunc)rdra!i||i),eLayers,(fanvas:)wInde_idxInPipst0,c>n.b)ock_draw?n.step:Rend,.uit.i.modDr.s&&(t..style.{step:r,modBy:cale&&a?Math.Peil(a/r):Rend,modDr.s&&(t.:a}un(gingRPipst0,cit,e){var nhiis.scale.sca,pipst0,cMad(314(tn},ginsformStreanModetit,e){var n,i,r,a=thuRoot
npipst0,cMad(314(ttuideontRingRDr.sat.nu(t.(iutLn(,eLayers,(fEnunc)rdr=fal=!0,o=1):Prettrfanvas:t.i>Ln(thr n=olnzlevi314(tl"dro")t.i>Lvi314(tl"dro(hr n=oln")
fu"mods._dsf314(t,eLayers,(fChunkMode"r?i:Rend
},pipst0,cCr:tleatexer:tlea={,eLayers,(fanvas::r,modDr.s&&(t.:o,l"dro:a}u,g.,i.prevPipst0,ctit,e){var nhis._optdispohu:[npipst0,cMad=s(ru=a}ck"Series((t){var e=this._ontRingRPeLayers,(ftHerevtuid
ibeft(rp{id:r,hsMd:Rend,taii:Rend,thr n=oln:RingRPeLayers,(f(hr n=olntHe,eLayers,(fEnunc)r:ili!(t.prev"][_d=!0,o=1):t.cttrev"][_d=!0,o=1):freBb)ock_draw:-0,step:Math.raunt(i||700(,nu(t.:0}e,k(2:t,vi,r.sTmsk usn},giprettrfS&&gdTmsks_){return ths.getLvelLisa&&gdTmskMad,ale.getecIna&&t.d[:fuModel(),ennize(api
;rtlayLialloxy:funea(i){i.virtual<t.la]sf314(ituide._t.s14(ituidn[]B
i.reeft(nt,e){var n,i r=e,ral<t.la]ngseriesTmskMadsfongseriesTmskMad=s(r),ightteriestionon=eet("T"dropSeries
s(){returh=o.a12)
funeuidnsokeoss(or||a.s14(o,u({ortn:bnreeft(S,nu(t.:Cn)eosxer:tlea={model:n,ecModel:}}spi:r,use||l.cVisual:eeisVisualli!eeisLayout,ortn:e.ortnnreeft(e.reeft,schedufun:t},kgtLrgs)raneisModOnAllSeries?ifick"R._Seriesnh.:o?ifick"R._SeriesBytion(o,h.:awIn(e,ra)ick"(hse=(s=c=t[npipst0,cMad
a)ick"((e){t.on&&t_sincs314(hesfotfunctionatra.re",veKeuae) usn}is.seay,a i=n(=nu:funallReeft(nt,e){var n,i r=e,a.a12)
fune:funallTmskune:funallTmsk||u({reeft(_}eoo.er:tlea={ecModel:}}spi:a,:funallReeft(e.:funallReeft,schedufun:t}is.scl,olul}ucStubMad,olul}ucStubMad||stHeeghtteriestionoc=eet("T"dropSeries,f=urnd
e&modifyOutputEnd s(){returp i,r,a=thu:[uidni=l[:fu(ne
ihis.flr(t),nnu({reeft(y,onD_dra:wvic,o,d_drar (=nuer:tlea={model:e,:funallPeLayers:f,modifyOutputEnd:d|=nuul}uc=o=nu__b)ock=f,kgtLeayerh?ifick"R._SeriesBytion(h,p):c?c(e,a.lick",pce(fr 1or(ieropSeriestHe,)eositig=t[npipst0,cMad
l)ick"((e){t.on&&t_sings314(hesfotfunctionatro,d_drar ,l.re",veKeuae) usn}is.seay,a i=n(})splay)},giprettrfViewit,e){var n,i r=e.ctx,arevtrnvas:Tmsk
aerfer:tlea
a)modelhayaLecModel=nyaLapihe,ru__b)ock=!tmal=!0,o=1):Prettrfanvas:,kgtispos.r)},gipere.__Dr.sPture:forTmsks_){return n,i,r,,dispotrs[n]dr.sPture:foroxy:funeotaet{b)ock:!0})},gipere.__VisualTmsks_){return n,i=n(31,dispotrs[n]visualoxy:fune,t,_doPa,gipere.__SeriesTmsktit,e){var nhis._opu=a}ck"Series((t){var e=thie|=vi,r.sTmsklpere.___urefrers[nunf&(sshed|=ea,giprtn_){return tharLayepipst0,cMad(ick"((e){t.on&&t,r],a=eevitaii
dorContu__b)ock n=tb)ock_drawu:[n_idxInPipst0,ci i,r=}e=eet("Upstrean_urwhi.cle usn}ositim=ginsformPayloam_){return n,i,r"remaina&this.ndi,r:tlea.payloam_e u s(){retur_&t,rt.:funallReeftn!3ecModel,e3hpi,a.payloam)hs(){retury=tar nstyle.ctb:funallPeLayers&&xhs(){returx tharLayul}ucmd_drar ,dsRemngRDownstrean_u,d_drar us(){returw tharLayul}uct.crLayul}ucmd_drar us(){returbn!!t&&(!!t ctprtnt.cttrtn(a.model,!3ecModel,e3hpi,a.payloam)hs(){returS&t,rt.use||l.cVisualt.ct,r.sfrtionAllVisualn&&],a=eevireeftDef0,cs=dndireeftn!3model,!3ecModel,e3hpi,a.payloam)n.length=0,t){var>1?aoen(t,e,n){var i nth.sqrt(le usn:T(=(s=T=M(0n s(){returMn!!t&&(!!t t,e,n){vai=n(312)
funi,r.sutLn(reeftDef0,cs[tie?e.rdIri,r.sEck"n=1;n<t.la]htthis.;a<e.|{};a=t[ri,r.sEck"(e,a.functirdIripeLayers&&ripeLayers(eayerhs(){returCn!!t&&(!!t ct,r.sfru(t.(ihs(){returkar i=n(312)
fu:[uidnr=t[npipst0,cMadf314(i)
!r.hsMddInd.hsMd=n(=ritaii&&ritaii,pips(n(=ritaii=n[0[n_idxInPipst0,cerfer(t.++[0[n_pipst0,cerhs(){returDn!!tI=.__sttry{tWA,O)}cment(!!t.wxa&&r.I}p.wrapS&&gdoxy:fun=t,e,n){var i nth.sqrto.get((a={:funallReeft(t,leriestion:Dn!!n),vtuid=h("thigdoxy:fun")
}pare3visualtion.eRev}ositiI,A={},O={} s(){returP n,i,r=0;n<t.le ih=0,={constru,vel
=l}PWA,c),P(O(fgtAa}ck"SeriesBytion=Afick"R._SeriesBytionit,e){var nhiI=t},Afick"tyleun"][it,e){var nhi"seriess._dtLmaintiont.cteubtionparIm.scubtionn}ositiL=p
},},functiLn(t,e,n){var i ns._dom["#37A2DAtme#32C5E9"+t#67E0E3tme#9FE6B8"+t#FFDB5C"+t#ff9f7f"+t#fb7293tme#E062AEtme#E690D1"+t#e7bcf3tme#9d96f5"+t#8378EAtme#96BFFF"iont{nuans:nncuansction:[["#37A2DAtme#ffd85ctme#fd7b5fsa,Ri#37A2DAtme#67E0E3tme#FFDB5C"+t#ff9f7f"+t#E062AEtme#9d96f5"a,Ri#37A2DAtme#32C5E9"+t#9FE6B8"+t#FFDB5C"+t#ff9f7f"+t#fb7293tme#e7bcf3tme#8378EAtme#96BFFF"ion]su=a},function(t,e,n){var i ns._dom["#dd6b66"+t#759aa0tme#e69d87tme#8dc1a9"+t#ea7e53tme#eedd78"+t#73a373tme#73b9bctme#7289ab"+t#91ca8ctme#f49f42"iont{nuans:nndColgrauntCuans:"#333tmsooltip:{axthPtoucer:{t0,cretur:{cuans:"#eee"},crossretur:{cuans:"#eee"},labli:{cuans:"#000"}un(legent:{llearetur:{cuans:"#eee"}},llearetur:{cuans:"#eee"},titur:{llearetur:{cuans:"#eee"}},loolbox:{ict.ction:{(t),th:{dth:0"Cuans:"#eee"}}},,r.sZof(:{tlearetur:{cuans:"#eee"}},visualMad:{llearetur:{cuans:"#eee"}},lhist0,c:{t0,cretur:{cuans:"#eee"},itenction:{(t),th:{nuans:n[1]ti,labli:{(t),th:{llearetur:{cuans:"#eee"}}},ct.zrIsction:{(t),th:{nuans:"#eee",dth:0"Cuans:"#eee"}}},shisAxth:{axthL0,c:{t0,cretur:{cuans:"#eee"}},axthTick({t0,cretur:{cuans:"#eee"}},axthctbli:{llearetur:{cuans:"#eee"}},indetL0,c:{t0,cretur:{ch",tadashedsncuans:"#aaa"}},indetArea:{areaction:{cuans:"#eee"}}},logAxth:{axthL0,c:{t0,cretur:{cuans:"#eee"}},axthTick({t0,cretur:{cuans:"#eee"}},axthctbli:{llearetur:{cuans:"#eee"}},indetL0,c:{t0,cretur:{ch",tadashedsncuans:"#aaa"}},indetArea:{areaction:{cuans:"#eee"}}},valu!Axth:{axthL0,c:{t0,cretur:{cuans:"#eee"}},axthTick({t0,cretur:{cuans:"#eee"}},axthctbli:{llearetur:{cuans:"#eee"}},indetL0,c:{t0,cretur:{ch",tadashedsncuans:"#aaa"}},indetArea:{areaction:{cuans:"#eee"}}},rormgoryAxth:{axthL0,c:{t0,cretur:{cuans:"#eee"}},axthTick({t0,cretur:{cuans:"#eee"}},axthctbli:{llearetur:{cuans:"#eee"}},indetL0,c:{t0,cretur:{ch",tadashedsncuans:"#aaa"}},indetArea:{areaction:{cuans:"#eee"}}},t0,c:{symbol:"circle"},grap":{nuans:n},gaugc:{titur:{llearetur:{cuans:"#eee"}}},cxy:fustick({itenction:{(t),th:{nuans:t#FD1050sncuans0:"#0CF49B",dth:0"Cuans:"#FD1050sndth:0"Cuans0:"#0CF49B"}}un
i.rormgoryAxth.indetL0,cfhaow=|!e=(s=r=iu=a},function(t,e){var n=M=n(207),r=n(220).devic85traevi230)tdet.stSourceFo__at
funi232).SERIES_LAYOUT_BY_COLUMN
,a,n||{}),ch",ta,r.seft",,a&&s!=Opretu:{leriesLayoutBy:o,sourceHsMder:Rend,dhisnsetus:Rend,source:RenderopretuUrStatd(){return thais.set" n=ri,n||{}),ch",ta,r.seft"})},t,e){var n=M=n(2vi210)t__DEV__
12)
funcn34).deif,isModHashMadraeif.sShpeof,igifo=Arrau,seifick"El=(i.aslert,n(353)xe.rseXMLe,h=rtHeeg{regescerMad:t,e){var n=M=n(207),r
th.sqrto.e)?fu::s}ivg?fu[,ch",tatvf shource:s}ivg,sp.sialAreas:s}in.sialAreas}]:(eet(oJstut.!eifea=r,tsdInn=s}in.sialAreas,e=eet(oJstueont[,ch",tat(oJSON shource:s,sp.sialAreas:n}])s+,s.(e){t.on&&t,r],a=eevittru
"t(oJstu"._dSighc=tnvas"
vt(oJSON ),(0,ceei n!!n)e,u(e),(igie},,itrieveMad:t,e){var n nth.sqrtu(314(tn}},ci{1eoJSON:t,e){var nhis._opts.hource
digeoJSON=s(eR?"t()ef0,cLa&ti[r]:r,JSON&&JSONxe.rse?JSONxe.rse(eR:nle:F,e,n){v(ern.sqrt("+e+");")():e},ivg:t,e){var nhit}ivgXML=lFrisource)xis=r},functihn(t,e){var n=M=n(207),r=n(228).devic43traevi247)
fun(274),l=n(279),u=n(354),h=n(280)
h=n(223),c=n(276),f=n(278re,=n(281gth
vi242),g=n(221gtv=n(271)f,isModFromShpeof,muncn34)._=mf.sShpeof,y=mf,n||{},x=mf,a&&s!=s,w=mfhpem,b=mf,ck"ES=/[\s,]+/ s(){returT n e=thi_.get((a=fnle:DOMP.rser)xe.rseFromShpeofn!t"t,n|/xmicr)_9._dtLtoUptionpartdtLfirstChild);"tvf !_dtLtoUpZime.t
"owerCasOfr||1!_dtLtoUption;[khi.nlearibt0,ghis.scale}s(){returMntharLayelefs={},eshHoirooo=.__s,eshHoithDw.0,ce!1,eshHoithTlea=!1}Me.dispose=fe.rseit,e){var n,i,r.dpr
s|ositiioT(t)=e[n!n)throw nle:Errthi"Illegal tvf )e=(s=r=nle:i
eshHoirooo=r
<t.la]nggftight=o+"px"viewBox")r
""
fue.rseFloat(nggftight=o+"px"+"px"i)sfor+"px"),u=e.rseFloat(nggftight=o+"px"t],i=[")sfort],i=[)=esNaN(oet((os._hofoesNaN(l)dInls._hofoO(n,is.__s,=n&&=0;n<t.lu)?(a]ngfirstChild;c;)arLayep.rseNoUp(c,r),c=c.nlearibt0,ghacha(207),f=wha(}indet(S)
f)t){var>=4bkiu={x:e.rseFloat(f[0]||0)
y:e.rseFloat(f[1]||0)
.join(e.rseFloat(f[2]),e+"px",e.rseFloat(f[3]yfoeachuigoop&&toigoop&&tlparh(B(u,o,l),!eeignormViewBox).animator;(r=nle:i)3add(d),d.),i.c=h.),i.c.sdexOfRed.pabsolut=hlpabsolut.sdexOfR.dom},geteignormRo!e||ip)return
o)return
l||ibeft2|ipshapenle:sy{tape,z{ma0,:n}}.join(o,e+"px",lunreB{rooo:r}.join(o,e+"px",l,viewBoxt.st(u,viewBox(),t&&t.b:h}},Me.dispose=fep.rseNoUpit,e){var n,i,r,a=this.rdtLtoUpZime.t
"owerCasOfr
eng=lefs"n
=r?eshHoithDw.0,ce!0:"t,n|"n
=rpartshHoithTlea=!0),eshHoithDw.0,c,rConi=k(f(sl<t.la]is,e)},dispotn,fut[:fuight=o+"px"id )eopartshHoilefs[otLafnhunctni=C(f(sdInn=ie,e)},dispotae),=fadd(n)&&=0;n<t.lsdtLfirstChild;s;)onsosLtoUptionpaarLayep.rseNoUp(s=n(=3nsosLtoUptionpaarLayethTleapaarLayep.rseTlea(s=n(=sosLtlearibt0,gh=lefs"n
=r?eshHoithDw.0,ce!1:"t,n|"n
=rpartshHoithTlea=!hfunMe.dispose=fep.rseTlea=t){var e=t,i,rCon1._dtLtoUption,is._domRingRight=o+"px"dx")r
0ontRingRight=o+"px"dy")r
0
playLitextX+=e.rseFloat(n),eshHoitextY+=e.rseFloat(ir(=(s=r)nle:a({tiy:0,illea:t.lleaCun||{t,
if((e.__Tlea:!0},pabsolut:[playLitextXr
0oeshHoitextYr
0]})
D&t,rtoO(t,istshHoilefsa)nch:fur}tiy:0.fot.tionwebko<9dInd.tiy:0.fot.tion=9,rgs,i.c=rgs,i.c||pdate,rgs,i.c[0]*=o/9,rgs,i.c[1]*=o/9)e=(s=terft("ect(),a=t.stylhis.scale.sca,textX+=sr+"px",=fadd(rtor|ositiCi{1(){return rUL,is._domnle:i
is.scalDai=n(oO(t,nstshHoilefsatLayr.st(){return rUL,is._domnle:s
is.scalDai=n(oO(t,nstshHoilefsatL(e),tape,({mae.rseFloat(RingRight=o+"px"x")r
0)
y:e.rseFloat(RingRight=o+"px"y")r
0)
.join(e.rseFloat(RingRight=o+"px"+"px"i)sf0),e+"px",e.rseFloat(RingRight=o+"px"t],i=[")sfarfitLaycircle(){return rUL,is._domnle:o
is.scalDai=n(oO(t,nstshHoilefsatL(e),tape,({cmae.rseFloat(RingRight=o+"px"cx")r
0)
cy:e.rseFloat(RingRight=o+"px"cy")r
0)
r:e.rseFloat(RingRight=o+"px"r")sfarfitLayt0,c:){return rUL,is._domnle:u
is.scalDai=n(oO(t,nstshHoilefsatL(e),tape,({m1ae.rseFloat(RingRight=o+"px"x1")r
0)
y1ae.rseFloat(RingRight=o+"px"y1")r
0)
x2ae.rseFloat(RingRight=o+"px"x2")r
0)
y2ae.rseFloat(RingRight=o+"px"y2")sfarfitLayel|ipsc:){return rUL,is._domnle:l
is.scalDai=n(oO(t,nstshHoilefsatL(e),tape,({cmae.rseFloat(RingRight=o+"px"cx")r
0)
cy:e.rseFloat(RingRight=o+"px"cy")r
0)
rmae.rseFloat(RingRight=o+"px"rx")r
0)
ry:e.rseFloat(RingRight=o+"px"ry")sfarfitLaypolygma:){return rUL,is._domRingRight=o+"px"ttoucsp)
odInn=I(n)&&07),r=nle:cy{tape,z{ttoucs:n||hi" nuis.scalDai=i(oO(t,istshHoilefsatiaypolyt0,c:){return rUL,is._domnle:h
Dai=n(oO(t,nstshHoilefsa
s._ontRingRight=o+"px"ttoucsp)
(o,s)| idIni=I(ic)snle:fy{tape,z{ttoucs:i||hi" n},im,0,:){return rUL,is._domnle:r
is.scalDai=n(oO(t,nstshHoilefsatL(e),tiy:0({im,0,:RingRight=o+"px"xt0,k:href ),x:RingRight=o+"px"x")
y:RingRight=o+"px"y")}.join(a(),oight=o+"px"+"px"i)ee+"px",a[:fuight=o+"px"t],i=[")fitLayllea:){return rUL,is._domRingRight=o+"px"x")r
0ormRingRight=o+"px"y")sfazlevi314ight=o+"px"dx")r
0ofut[:fuight=o+"px"dy")r
0
playLitextX=e.rseFloat(n)+e.rseFloat(a),eshHoitextY=e.rseFloat(r)+e.rseFloat(o)e=(s=tenle:i
is.scalDai=s(oO(t,sstshHoilefsatsaylspaa:){return rUL,is._domRingRight=o+"px"x")
rmRingRight=o+"px"y")
oop&&tn(n(playLitextX=e.rseFloat(n).scale&&rt.(eshHoitextY=e.rseFloat(r))
<t.la]sf314ight=o+"px"dx")r
0ofut[:fuight=o+"px"dy")r
0,tenle:i
is.scalDai=s(oO(t,sstshHoilefsate.sca,textX+=a,eshHoitextY+=otsayphap(t,e){var n,a=!1,o=t0t[:fuight=o+"px"d")r
""
i=v(ne
is.scalDai=i(oO(t,istshHoilefsatia},k={t0,cargradt"][:t,e){var nhis._opte.rseInt(RingRight=o+"px"x1")r
0,10),ene.rseInt(RingRight=o+"px"y1")r
0,10),ite.rseInt(RingRight=o+"px"x2")r
10e10).dee.rseInt(RingRight=o+"px"y2")r
0,10),aenle:d(i r=e,ra
&&(!!t t,e,n){van,i,r=0;n<t.lennLfirstChild;n;,rCon1._dnLtoUption,is._di]nggftight=o+"px"ol=a.s")
 gifostarOfa"%")>0?e.rseInt(i,10)/100:i?e.rseFloat(ir:0e=(s=r=nggftight=o+"px"stop-nuansp)r
"#000000"
=faddCuansStop(e,ra}ntextlearibt0,g" n!,ac,a},radtalgradt"][:t,e){var nhi}} s(){returD n=MtL=Brnde_inheritedctionighcde_inheritedction||hcde_inheritedction={}lexhcde_inheritedction,nde_inheritedctionr)hs(){returI n e=this._hovw n }indet(S),enhisength;e}+){var i]=2.ctx,aree.rseFloat(e[ia),aee.rseFloat(e[i+1]urne.delR[r,a]c.wxa&&r.n(=(s=A=ifillr"filltmtypokx:"typokxtmetypokx-+"px"i:=:0,c=Math"+(!a||a[:=(!a||a[i,"fill-(!a||a[ir"fillO!a||a[i,"typokx-(!a||a[ir"typokxO!a||a[i,"typokx-dasharraui:=:0,cDashi,"typokx-dashol=a.s":=:0,cDash,l=a.si,"typokx-:0,ccap":=:0,cCadowntypokx-:0,cjohi":=:0,cJohi"wntypokx-miterlimid":=miterLimid"k"font-familyir"fot.Family"k"font-sionir"fot.tion"k"font-stion"r"fot.ttionck"font-w],i=["r"fot.W+"px""t"t,n|-align":itleaAlign","align,o=1-basc:0,cs:itleaBasc:0,cs} s(){returO n,i r=e.ctx,arecde_inheritedction||{aya="t,n|"n
=efstru
eng1._dtLtoUptionpart,e){var n,a=!1,o=t0t[:fuight=o+"px"
if((e.__")
 d=o.antexerplaxOf/,/g," "}
n.ctx..__s,r=[]
exerplaxOfEn(t,e,n){var i=n(2&e.delRi=n(})&&=0;n<t.laerf+){var-1 a>0;a-=2.ctx,afure(t,sure(-1]
swient( gi||gf,isMod(ats){casc"
if((lMod":ovw o }indet(S),g.
if((lMod(e,i,[e.rseFloat(o[s]use.rseFloat(o[1]||0)]ur i,r=
casc"s,i.c":ovw o }indet(S),g.s,i.c(e,i,[e.rseFloat(o[s]use.rseFloat(o[1]||o[s]u]ur i,r=
casc"rotMod":ovw o }indet(S),g.rotMod(e,i,e.rseFloat(o[s]uur i,r=
casc"skew":ovw o }indet(S),or:go:0.warn("Skew 
if((e.__ is not supfunced y.s")
 i,r=
casc"maht=x":ovw o }indet(S),i[0]=e.rseFloat(o[s]usi[oi=e.rseFloat(o[1]usi[2i=e.rseFloat(o[2]usi[3i=e.rseFloat(o[3]usi[4i=e.rseFloat(o[4]usi[5i=e.rseFloat(o[5]fnhu(e),"only(),t&&t.brit" n!ae),y(r,t,e){var nhis._opts.gftight=o+"px"stion"ren={} e[n!e
return n
n.ctx:e},}&=0;nR.las[_draw]gthop&&tei=R.execae) ;)r[i[oi]=i[2i&=0;n<t.la ih=A)Aoperty(f)&&(nullsuBrcale&&re(tt(tn[Ae(t]&re(ta
&&(!!t olni).s!iic=0;i<thio ih=A)e[nAoperty(f)&&(nullo).animasts.gftight=o+"pxo)
oop&&tsdInr[Aeie]=sr(=(s=l=a?"tleaFill"r"filltmu=a?"tleaSypokxt:"typokxt
=fhtion==fhtion||nle:pe=(s=h==fhtion
]&&"aun.fill&&f(e),(l,L(n.fill,n).scale&&r.typokx&&f(e),(u,L(n.typokx,n).sb([=:0,c=Math"+t(!a||a[i,"fillO!a||a[i,"typokxO!a||a[i,"miterLimid"k"fonttion"].(e){t.on&&t,r],a=ee=:0,c=Math"._dt&&a?"tleaSypokx=Math":t
]&&"aun[t]&&f(e),(e,e.rseFloat(n[t]ear:f,r.tleaBasc:0,c&&e[n])r!==r.tleaBasc:0,c||(t.tleaBasc:0,c="alphabetic"re"alphabetic"===r.tleaBasc:0,cdInd.tleaBasc:0,c="dt
if(n)}"this."===r.tleaAligndInd.tleaAlign=tlsetsta"ent)===r.tleaAligndInd.tleaAlign=tripx"stab([=:0,cDash,l=a.si,":0,cCadown:0,cJohi"wnfot.W+"px""t"fot.Family"k"fontttionck"tleaAlign","tleaBasc:0,cs].(e){t.on&&t,r]&&"aun[t]&&f(e),(t,n[t]er:f,r.:0,cDashighcdtiy:0.t0,cDashLw(r.:0,cDash }indet(S))ee[u]&&"none"!==e[u]&&(e[u]=!0),cde_inheritedction=r(=(s=P=/url\(\s*#(.*?)\)/ s(){returL n,i,r,a=thu:BrnBrndmment(Pa
&&(!!t o?e[w(ns1]i]:t(=(s=E=/(
if((lMod|s,i.c|rotMod|skewX|skewY|maht=x)\(([\-\s0-9\.e,]*)\)/g,R=/([^\s:;]+)\s*:\s*([^:;]+)/g s(){returBar i=n(312)
fu:/tr+"px",r=n/trt],i=[ya=(t-e)m(2*e,ra
&&(!!t{s,i.c:[a,a],pabsolut:[-(Rix+tr+"px"/2)*a+e/2,-(Riy+trt],i=[/2)*a+n/2]nhu(e.rseXML=T,e.mmkmViewBox(),t&&t.b=B,u(e.rseSVG=t,e,n){var i nth.sqrenle:M)xe.rsear i Hovt,e,n){var i=n(312)
funcn13)i,n||{}),ch",tael|ipsc),hape,z{cma0,c:n}}rma0,r:n}},buildPhap(t,e){var n,a=!1,o=t0.5522848,i==fcx,recdcy,a]htrx,ightru,sea*non=o*n
!3moveTo(i-a==a,ndbezierCurveTo(i-a==-l,i-s==-o=e,r-oa,ndbezierCurveTo(i+s==-o=e+a==-l,i+a==a,ndbezierCurveTo(i+a==+l,i+s==+o=e,r+oa,ndbezierCurveTo(i-s==+o=e-a==+l,i-a==a,ndcloseshapet" nu=a},function(t,e,n){var i=n(234).devic57)
=fzrnvas:=ie=(s=r=n(221g
e.mmet=x=r
<t.la]ncn12g
e.v,thor=a)nch:funcn34).l=n(229g
e.nuans=sis.scl,vic09trh=n(214g
e.numbs:=ue=(s=h=n(216t
e}e.__at=he=(s=c=vic53)
cethrotton,eethrotton=cethrottonositif=n(356t
e}helpun=t)nch:dun(363t
e}e.rseGeoJSON=dinch:p=n(288t
e}=thispositig=n(218t
e}Model=g
p
v&o|n(295t
e}Axth=vositim=n(211g
e.env=mositi_=d,y},}&o(ick"(["madownick"i,"filter","ostarOf","osherithck"reducei,"filter","bint),"",dry"k"o=Arrau"k"o=Shpeof"k"o=i.map
"k"o=F,e,n){vownin||{}own,a&&s!=s),""lone"o"[t],!s].(e){t.on&&t,ry[t]=o[t]n)eositix},}&o(ick"(["in||{}tape,ownin||{}shap"o"[mkmshap"o"[mkmom,0,"o"[t],!shap"o"ersionshap"o",isModIc{vowne),H:funttionck"e),"tblittionck"e),Tleareturck"e),Tleat="getFont"t"upformP)&&s","ositP)&&s","t("Tif((e.__",""lipPtoucsByRap
"k""lipRap
ByRap
"k"regescertape,owng),tape,ClassownGroupownom,0,"o"Tleat="Circle","S,thor","Reof"k"Polygma"k"Poly:0,cs,"Rap
"k"L0,cs,"BezierCurves,"Arctme_d=!0,o=1):DeSortFunc)t="Cyleuu{}shap"o"L0,carGradt"][s,"RadtalGradt"][s,"ect(),a=t.sts].(e){t.on&&t,rx[t]=l[t]n)e,e}e.rseGeoJson=_,e}util=y,eaurap"ic=xn(t,e,n){var i=n(234).devic34).devic87traevi226)
fun(294),l=n(218t,u=n(224g
l[:fuLayoutt.st,eauncLayoutt.st=l[:fuLayoutt.strs.scu=n(225)
h=u.enunc)Dr.sShick,c=uaisDhisnsetuShicked,f|ueossShickedDhisnsetu.,=n(291g
e.numpleteDhisnsetus=dinch:p=n(290g
e.nisModDhisnsetus=positig=n(256t
e}nisModSymbol=g}nisModSymbol
p
v&o|{isDhisnsetuShicked:c,enunc)Dr.sShick:h,ossShickedDhisnsetu:f}
e}nisMod=thist,e){var n nth.sqrtr(RingRSource(Re=avee.,r.sShick=v,e}nisModS,i.c=t,e){var n,i,r,a=thu:
saisIna&&t.d(hesfoomnle:s(eCon)m(x(2*n,o))e=(s=r=a}nisModS,i.cByModel(ne
is.scalibeftEn||{,(t[s],t[1]usa.nicdS,i.cEn||{,(r=n(orvee.m(x(2AxthModelCylmonMethodtit,e){var nhin)m(x(2*t,or}n(t,e,n){var i){s(){returr nhiis.scalehs(){returigtLeay,is,trs,n=["wldheight=e.alwhayers[n"wldKeyGcttergi||night=e.alwKeyGcttergr||night=eer:tlea=ahs(){returr n,i r=e,ral=1;n<t.la]g;a<t}+){var a=t[n]
i.o="_ec_"+r[i](ge(t,a,,l=elie
eturn
s?(ne.delRoa,e[otLaf:(.}+){var||hc[otLs=[s])s+e.delRa!r}ni)o{constructor:g,getTypei,add:t,e){var n nth.sqrttlayLiaddheight=},upform:t,e){var n nth.sqrttlayLiupformheight=},re",ve:t,e){var n nth.sqrttlayLire",veheight=},execurm:t,e){var ths.getLvelLisolnzpts,n=["alwen={},fu[dia=[]
=1;nr n,{},f,""wldKeyGctter"splay)nr(enn,a,""alwKeyGctter"splay)no]gto<t}+){var l=r[etur!=nls.[tioeie])?(rh(leturn!0
?g1._dht(tn[sts._hofoaflr(hif.(ic:n[sts._ho,tlayLiupformpaarLayeupform(l,o)o:arLayere",vepaarLayere",vexo)
=0;i<thio]gto<a}+){var l=r[animastalie
 d=o3perty(f)&&(nulls)(222),l=e[n]&&"_dnls.[t]eaer:tinuu
engleturn!0
=0;n<t.lu=0,h(leturn!0;u<0;u=r[tlayLiaddpaarLayeadd(l[u].functitlayLiaddpaarLayeadd(l)}}un
<t.la]is=r},function(t,e){var n={=n(2vi210)t__DEV__
12)
funcn34).deif,isModHashMadrae(i,e)trievee.s._pr) s(){returon t<ght=eerordcysZimeheight=eerordcysDhi._discrLayuxthMap=rtHeght=eeormgoryAxthMap=rtHeght=efirstCormgoryDhi_draw]Rendenimast{cis.rsian2d:t,e,n){var i=n,e.ctx,arevt:fuReferpeoftyleun"][s(ixAxthc)[s],aevt:fuReferpeoftyleun"][s(iyAxthc)[s]
e.nuordcysDhi._d"xtmey"ion(e),("xtmr)on(e),("u"ka,,lirndIni(e),("xtmr)oeefirstCormgoryDhi_draw]0,,liandIni(e),("u"ka,,eefirstCormgoryDhi_drawoeefirstCormgoryDhi_draw]hfunvas&&!Axth:t,e,n){var i=n,e.ctx,arevt:fuReferpeoftyleun"][s(ivas&&!Axthc)[s]
e.nuordcysDhi._d"sas&&!"ion(e),("sas&&!"mr)olirndIni(e),("sas&&!"mr)oeefirstCormgoryDhi_draw]0,aypolar:t,e,n){var i=n,e.ctx,arevt:fuReferpeoftyleun"][s(ipolarc)[s],aen.findAxthModel("radtusAxthc)tfur}eindAxthModel("as&&!Axthc)
e.nuordcysDhi._d"radtus"k"as&&!"ion(e),("radtus"ka)on(e),("as&&!",o),liandIni(e),("radtus"ka)oeefirstCormgoryDhi_draw]0,,liondIni(e),("as&&!",o),]&&"_dSefirstCormgoryDhi_drawighcdfirstCormgoryDhi_draw]hfPa,geo:t,e,n){var i=n,e.ce.nuordcysDhi._d"lof"k"lat"]},ttre)}li:t,e,n){var i=n,e.ctx,arevtecModel,oerft("tyleun"][("ttre)}licksf314(t,tre)}li_draw"r,,l=e.nuordcysDhi._o.dhisnsetus.sdexOfR
a(otttre)}liAxth_drawo(t,e,n){var a.a12)
furft("tyleun"][("ttre)}liAxthck!!e(=se(t
ibeft(u,o),liouBrcale_dSefirstCormgoryDhi_drawighibeft(u,o),cdfirstCormgoryDhi_draw]aar:funss(){returl nhistyle."eormgorys._dsf314(tstru")rant("tyordcysInfoBySeriesit,e){var nhis._optdf314(tnuordinModSyscem"ren=nle:o(eConts[SttConinstyle.ci,d,n[0[uxthMap[0[eormgoryAxthMapoveHovt,e,n){var i=n(312)
funcn34).deni239traevi292)tfur}o{construs++r.,n||{}),ch",taordinMlpsinia:){return rUL,itcomthisArrauartsfot)nle:a({rormgories:trefrers[n_ordinMlMetaheight=e.,n||{tdpr
[0,g.rormgories)+){var-1]},e.rse:t,e){var n nth.sqr"typeof r?i[r]:r,t?ers[n_ordinMlMetaf314OrdinMl n :Math.raunt(=aveer:tain:t,e){var n nth.sqrttts,n=[e.rseartro,er:tains,e)},dispotnBrcale&&ers[n_ordinMlMetafrormgories[t]n,(t),this.:t,e){var n nth.sqrton(t),this.s,e)},dispot,n=[e.rseartfunv,i.c:t,e){var n nth.sqrtMath.raunt(o.),i.c.,e)},dispotnPa,getTicks:t,e){var th=0;n<t.lt_dispts,n=[",n||{tohu:[s];n<=c[1];)te.delRnr,n++his.scale},g),"tbli:t,e){var n ne[n!ggingisBlank(t
return ers[n_ordinMlMetafrormgories[t]n,nu(t.:t,e){var threturn ers[n_,n||{t[1]-ers[n_,n||{t[0]+1},unvarEn||{,FromDr.s:){return rUL,itrs[nunvarEn||{,(RingRipo{cxctionEn||{,(enPa,getOrdinMlMeta:t,e){var threturn ers[n_ordinMlMetan,(exOTicks:i}ange,(exOEn||{,:i}ange}eosxeisMod=t,e){var threturn nle:s}is.scl,ss=r},functilovt,e,n){var i=n(312)
funcn34).deni214)xe.rsePercentraevi225)aisDhisnsetuShicked,fun(252r,l="t()ef0,cLa&ti[r]:r,Float32Arrau?Float32Arrau:Arrau s(){returl n nth.sqrtt(314("shick")||"__ec_shick_"+tgseries_drawhs(){returuar!t&&(!!t ct,im+tfostarhs(){returhn! i ns._dom[].length=0,}ck"SeriesBytionog,(t,e,n){var!tg.get(!v(c)dIni.delR=avc)snhs(){returc nhis._optt,e){var nhis._opt{} es._prog.(e){t.on&&t,r],a=t0t[nuordinModSyscemft("eas!Axthfr
eng=shiss._dn.tion||"valu!"._dn.tion
=0;n<t.lntRingRDr.satutLn(,im+"_"+nfostarEo=i}+opDhisnsetu(n(,im)no]grseif,u(t.(i;o<s ++o){nch:loixt("aa,o)
!(f(?!(f(i.delRl):!(f(=[li" neositiioRi&=0;n<t.lr ih=0)Contuperty(f)&&(nullr)sl<t.la]!(f(hacha(2a.sunc((e){t.on&&t_sin&&(!!t c-e})&&=0;n<t.los._horse1;s<a}+){var ++s){nch:loa[t]-a[t-1]
l>0t((os._ho._do?l:(t-e)m(2*o.lef}n(f(=o}}&&(!!t olni),om[].length=es._prog.(e){t.on&&t,r],a=i,aevtnuordinModSyscemft("eas!Axthfrno]af314En||{,(r
eng=eormgorys._da.tion
i]af314Band=e.getHfunctieng=valu!"._da.tion||"shiss._da.tion
animasta(,im+"_"+afostarEh]!(s],c=(t-e)abs(o[1]-o[s]usfta(),i.c.314En||{,(r,d=(t-e)abs(f[1]-f[0])
 gh?c/d*h:c}ull==nch:p=RingRDr.sat
i=(t-e)abs(o[1]-o[s]u/pfru(t.(ihsitig=r(RingR("barW"px"i)eigtv=r(RingR("barMaxW"px"i)eigtm=r(RingR("barMinW"px"i)sf1eigt_=RingR("barGapstay=RingR("barCormgoryGapstrne.delR{band=e.ge:i,barW"px":g,barMaxW"px":v,barMinW"px":m,barGap:_,barCormgoryGap:y,axthKey:u(a,,lhickId:lR=avcvc)sd=o.hs(){returf nhis._opt{} es._prog.(e){t.on&&t=n(312)
fu!.axthKey
rmRiband=e.ge,a]h[i]||{band=e.ge:r,remained=e.ge:r,[n])=e.ge&&(t.:0,rormgoryGap:"20%",gap:"30%",lhicks:{Hovo]aflhicks
h[i]=a)nch:sts.lhickId
o(s]||a.[n])=e.ge&&(t.++,o(s]=o(s]||{.join(0,maxW"px":0}is.scl,RibarW"px"
lli!o(s]r+"px"t((o(s]r+"px"=l,l=(t-e)m(2*a.re"ained=e.ge,l),a.re"ained=e.ge-=l rs.scu=RibarMaxW"px"
ut((o(s]rmaxW"px"=u)e=(s=h=RibarMinW"px"
"t((o(s]rminW"px"=hse=(s=c=t[barGap
]&&"auct((af3ap=crositif=t[barCormgoryGap
]&&"auft((afrormgoryGap=f) neositiio{} (o,s)| is._proen(t,e,n){var i nn[St={n
<t.la]s.lhicksofut[band=e.ge,s=r(RirormgoryGap,o),l=r(Rinap,1)
uut[re"ained=e.ge,h=Ri[n])=e.ge&&(t.,c=(u-s)/(h+(r-1)*l rc=(t-e)max(c,0),is._proa.(e){t.on&&t,r],a=eevimaxW"px",ennrminW"px"
Contt+"px")fu!.+"px",=dIni=(t-e)m(2*e,ec)sndIni=(t-e)max(i,n).s!.+"px"=i,u-=i+l*i,e--
ull==nch:i=cir()}<idIni=(t-e)m(2*e,uc)sndIn>idIni=ueon!=uct((!.+"px"=i,u-=i+l*i,e--funreBc=(u-s)/(h+(r-1)*l ,c=(t-e)max(c,0)ositif,d=0
is._proa.(e){t.on&&t i n=t+"px"sfotf+"px"=cusftt,d+u!.+"px"*(1+lcvc)sdt((d-=f.+"px"*l rs.scp=-d/2
is._proa.(e){t.on&&t i nn[St[i]=n[St[i]||{band=e.ge:o,ol=a.s:p}.join(a(wMath},p+u!.+"px"*(1+lcvc)vc)snhs(){returdar i=n(3Cont()}(312)
fu![u(en].length=]&&"auit.oop&&tn(n(i=i[l(ne]atia}s.scp={leriestion:"bar",ortn:oatuteeft(){return r(3Cong.get(v(c)his._optdf314Dr.satut0t[nuordinModSyscemontextridt:fuRec.(iutLn(t("eas!Axthfrna]nggftOtherAxthfr),ight+opDhisnsetu(a(,im)nlght+opDhisnsetu(r(,im)nu=a}.sHorizo=1):fr
h=u?0:1sftd(c([t]e,ist).+"px"
&&(!!t t>.5sfof=.5),{,eLayers:){return rUL,i=0;r<e;)e,d0t[nu(t.,pmnle:s(2*d),g=nle:s(2*d),v=nle:s(dgt_=disy=disx]grw]gthop&&techi.nlea() ;)y[h]u:[:fu(o,c),y[1-h]u:[:fu(l,c),_uni,r.sToPtouc(ys.__s,_),g[x]=u?i.x+i.+"px":_[s],p[x++]=_[s],g[x]=u?_[1]:i}y+i.t],i=[yp[x++]=_[1],v[w++]=c
u(e),"ayout({l"droPtoucs:p}l"droDr.s_drexOs:v,l"droBColgrauntPtoucs:g,barW"px":f,valu!AxthShis.:m(rpa,!1)
dColgrauntShis.:u?i.x:i}y,valu!AxthHorizo=1)::u})}}unnss(){returgar!t&&(!!t ctnuordinModSyscem&&"cis.rsian2ds._dsfnuordinModSyscemftionhs(){returvn!!t&&(!!t ctpipst0,cCr:tleat.cttipst0,cCr:tlea.l"drohs(){returmar i=n(2&ength=0,toGlobalCuord(ei,r.sToCuord("log"n
=efstru?1:0))rant(""ayoutO2Axthtt,e){var nhis._optdisnu!.axth
eng=eormgorys._dn.tion
i=0;r<e;)tLn(t("eand=e.getH,a]g;a<t}nu(t. a=t[ee.delRnu,a&&s!=st{band=e.ge:r,axthKey:"axth0",lhickId:"__ec_shick_"+an,t)a)nch:fuf(eCosoRi&=0;na]g;a<t}nu(t. a=t[{nch:loo.axth0["__ec_shick_"+a]
l.ol=a.sCeucer=l.ol=a.s+lr+"px"/2s+e.delRlc.wxa&&r.s}vee.prettrfLayoutBarSeriesih,e.mmkmColumnLayout=c,e,e)trieveColumnLayout=d,e,layout=t,e){var n,i,r,a=thuh(t.mi,tLcRnr,o={},st{} es._pron.(e){t.on&&t,r],a=eevi314Dr.satut0t[nuordinModSyscemontext("eas!Axthfrnh=l(p),c=r[u(i)][h]ar=c.ol=a.s,d0c.+"px",p]nggftOtherAxthfi),g=RingR("barMinH],i=[")sfa
o(h]=o(h]||hi,s(h]=s(h]||hi,u(e),"ayout({band=e.ge:c[band=e.ge,ol=a.s:f,sion:d})&=0;n<t.lvght+opDhisnsetu(p(,im)n_ght+opDhisnsetu(i(,im)ny=s(e,v)sx]p}.sHorizo=1):fr
w=m(0,p)
d]grS=e.nu(t.(i;b<S;b=t[{nch:T,M,C,k,D,Iu:[:fu(v,b),Au:[:fu(_,b),O=I>=0?"p":=n",P=w
yt((o(h][A]._(o(h][A]={p:w,n:wvi,P=o(h][A][O]e,x?(T=P,M=(Duni,r.sToPtouc([I,A]))[1]+f,C=D[s]-w,k=d,(t-e)abs(C)<gt((C=(C<0?-1:1)*gfoesNaN(C)sfyt((o(h][A][O]+=C)):(T=(Duni,r.sToPtouc([A,I]))[0]+f,M=P,C=d,k=D[1]-w,(t-e)abs(k)<gt((k=(k<=0?-1:1)*gfoesNaN(k)sfyt((o(h][A][O]+=k)e,e}eftIten"ayout(b,{x:T,y:M}.join(Cee+"px",k}t" n=play)},e.l"droLayout=povt,e,n){var i=n(312)
funcn34).deni214)raevi216)
fun(293),l=n(255)nlgs}o{construsu=Math.Peileh=(t-e)fluor,c=864e5ar=s.,n||{}),ch",tashiss,g),"tbli:t,e){var n n],a=eevelLisa&epLvlen=nle:Dorm(te
is.scala}e.__atThis(:[s],nstshHoropSetteofn"useUTC"nPa,(exOEn||{,:t,e){var n n],a=eevelLis,n||{t
eng:[s]n
=e[1]&&(e[s]-=c,e[1]+=cuse[1]n
=-1/0()}[s]n
=1/0,is._domnle:Dorm
e[1]n+nle:Dorm(nggftF__sYeartHen[:fuMongetH,ni314Dr.er (=}[s]ne[1]-c}velLi(exOTicks(t}indetNumbs:,nrminIucerval,vimaxIucervala
s._ontRshHoitucerval
nLfixMin||hc[s]nr.raunt(hhc[s]/i)*i).s!.fixMax||hc[1]nr.raunt(uhc[1]/i)*i).n,(exOTicks:t,e,n){var i=n(3t=tr
10
s._ontRshHoi,n||{toa=i[oi-i[0],sea/t
]&&"aur()s<=dIns.eReoop&&tn(ns>ndIns.nlis.scl,d}+){var,c=t,e,n){var i=n i n=0;n;n<i;.ctx,aren+i>>>1
t[r][oi<e?n=r+1:i=r}&&(!!t olnd,s,0,l),ftd[(t-e)m(2*c,l-1)],p=f[1]
eng=years._df[0]){sitig=a/p
p*nr.(exO(g/t,=n&}<t.lvgtshHoropSetteofn"useUTC"n?0:60*nle:Dorm(+i[0]||+i[oitnt("Thiszo=e,l=a.s()*1e3,m=[Math.raunt(u((i[0]-v)/p)*p+v)sMath.raunt(h((i[1]-v)/p)*p+v)]
o.fixEn||{,(m,iRevelLisa&epLvl=f,RshHoitucerval=pight=e.aexOEn||{,=m},e.rse:t,e){var n nth.sqr+rxe.rseDorm(te" nui(ick"(["er:tain","(t),this.s].(e){t.on&&t,rf}o{constru[t]=t,e,n){vai(2&ength=l[t]s,e)},dispot,n=[e.rseae:funre)nch:du[["hh:mm:ssow1e3a,Rihh:mm:ssow5e3a,Rihh:mm:ssow1e4a,Rihh:mm:ssow15e3a,Rihh:mm:ssow3e4a,Rihh:mm\nMM-dd",6e4a,Rihh:mm\nMM-dd",3e5a,Rihh:mm\nMM-dd",6e5a,Rihh:mm\nMM-dd",9e5a,Rihh:mm\nMM-dd",18e5a,Rihh:mm\nMM-dd",36e5a,Rihh:mm\nMM-dd",72e5a,Rihh:mm\nMM-dd",216e5a,Rihh:mm\nMM-dd",432e5a,RiMM-dd\nyyyy",ca,RiMM-dd\nyyyy",2*ca,RiMM-dd\nyyyy",3*ca,RiMM-dd\nyyyy",4*ca,RiMM-dd\nyyyy",5*ca,RiMM-dd\nyyyy",6*ca,Riweek",7*ca,RiMM-dd\nyyyy",10*ca,Riweek",14*ca,Riweek",21*ca,Rimonge",31*ca,Riweek",42*ca,Rimonge",62*ca,Riweek",70*ca,Riquis.rr",95*ca,Rimonge",31*c*4a,Rimonge",31*c*5a,Rihalf-years,380*c/2a,Rimonge",31*c*8a,Rimonge",31*c*10a,Riyears,380*c]i&=xeisMod=t,e){var tthreturn nle:f({useUTC:vtecModelingR("useUTC"n}n}ositip=fs=r},functipovt,e,n){var i=n(312)
funcn34).deni239traevi214)ro=n(255)nsur}o{construsloo.o{construsu=aingRPeecisetuSafeeh=a.raunt,c=(t-e)fluor,f=Math.Peiled=(t-e)pow,p=(t-e)log,g=r.,n||{}),ch",talog",basc:10e$or:g,getTypet,e){var thr.apply,dispo"dru,o=1sfrers[n_originMlS,i.c=nle:oa,getTicks:t,e){var n n],a=eevelLisoriginMlS,i.c,ennize(m,n||{tor=c.314En||{,(r (o,s)| is+op(l.getTickss,e)},dispotn,(t){var e=this._onta.raunt(d(eshHobasc,t)a)(o,s)| i=t._dn[0]dr=f__fixMin?v*e,r[0]):i,t._dn[1]dr=f__fixMax?v*e,r[1]):i})splay)},gfuMi(t)Ticks:l.getMi(t)Ticks,g),"tbli:l[:fuLablinv,i.c:t,e){var n nth.sqrtt=s.),i.c.,e)},dispotn,d(eshHobasc,t)rssetEn||{,:t,e){var n,i,r,a=thuRoot
basc
t=p n /pRnr,e=p i,/pRnr,lbeftEn||{,e,e)},dispotae)},gfuEn||{,:t,e){var ths.getLvelLibasc,e=s.314En||{,e,e)},disp)
!(s]ndar i[s]usc[1]ndar i[1]ur,a=thuRoot
soriginMlS,i.c,ntext("En||{,(r (o,s)| nf__fixMin&&(e[s]=v(:[s],i[s]uu,nf__fixMax&&(e[1]=v(:[1]si[oi (=}},unvarEn||{,:t,e){var nhitoot
soriginMlS,i.cnunvarEn||{,(R&&],a=eevoot
basc
t[0]=e(t[s],/pReRev[oi=e(t[1]u/pReRe[nunvarEn||{,.,e)},dispotn},unvarEn||{,FromDr.s:){return rUL,itrs[nunvarEn||{,(RingRipo{cxctionEn||{,(enPa,(exOTicks:t,e,n){var(3t=tr
10
s._opts,n=[",n||{tohu:[1]-:[s] e[n!(nn
=1/0||n<=0)his._onta.quintity(ne
=0;nt/n*i<=.5(n(i*=10);!esNaN(i)&&(t-e)abs(i)<1&&(t-e)abs(i)>0;)i*=10e=(s=r=[a.raunt(fhc[s]/i)*i),a.raunt(chc[1]/i)*i)]
RshHoitucerval=iight=e.aexOEn||{,=r}a,(exOEn||{,:t,e){var n nl.(exOEn||{,.,e)},dispotn
],a=eevelLisoriginMlS,i.c
=f__fixMin=nLfixMin,=f__fixMax=!.fixMax" nus(){returvn!_sin&&(!!t h(t.u(enPai(ick"(["er:tain","(t),this.s].(e){t.on&&t,rg}o{constru[t]=t,e,n){vai(2&ength=e=p i,/pRvoot
bascRe[[t]s,e)},dispoefunreBgxeisMod=t,e){var threturn nle:g}ositim=gs=r},functimovt,e,n){var i=n(312)
funcn34).deni364nus(){returaar i=n(3=0;n<t.lnt[]or=c[s],ae:[1]so]gto<t}+){var l==2.ctx,asts.charCodeAt(o)-64,lts.charCodeAt(o+1)-64
s=s>>1^-(1&sfoafl>>1^-(1&l).des+=r,ael+=a,ie.delR[s/n,l/n]c.wxa&&r.i}},},functit,e){var n,i,r&&(!!t t,e,n){van ne[n!g.UTF8Enco),a=
return e&],a=eeviUTF8S,i.c
cale_dSighc=1024g
=0;n<t.lennLfea=r,tssength;n}+){var i]+)=0;r<e;)tLn[i]igeometrytfur}nuordinModss++r.,nco)e,l=a.ssoaf0;l<o}+){var l=t[{nch:u=o[l]
eng=Polygma"===r.tion
o[l]=a(ue[[l],i,functieng=MultiPolygma"===r.tion
=0;r<e;)hf0;h<u}+){var h=t[{nch:c=u[h]
u[h]=a(ce[[l][h]aefung.UTF8Enco),a==!1}(p),is+op(i.filter(nLfea=r,tss(t,e){var n nth.sqrttigeometryt.cttr&&(nuies()tigeometry}nuordinMods)t){var>0nreB(e){t.on&&t,r],a=t0t[tr&&(nuies,aevt:fometrytfua}nuordinModss++[]
=Polygma"===a.tion(nse.delR{ch",tapolygma"k,n||riypeo[s],in||riyps:o.sdexOf1)fit=MultiPolygma"===a.tion(ni(ick"(oB(e){t.on&&t,rt[0]drse.delR{ch",tapolygma"k,n||riypet[s],in||riyps:t.sdexOf1)finre)nch:lmnle:r(n[n||"nam.s].s[0[epr (o,s)| l[tr&&(nuies=n,lr:funvt,e,n){var i=n(312)
funcn15).devic46traevi212)ro=n(365)
s(){returs=tar=n(3ContelLi(imeheight=e:fometries=r=n(n=[n[s],n[oi]
ull==nch:i=tshHoropect(),a=t.stylhn=[i.x+i.+"px"/2,i}y+i.t],i=[/2]nght=eeeucer=n}s)o{constructor:g,getTypes,tr&&(nuies:Rend,ropect(),a=t.st:t,e){var ths.getLvelLisr.st
Cont
return e&=this._hovNumbs:.MAX_VALUE,om[c,e]so][-e,-e]s++[]oaf[]ou=ght=e:fometries,hf0;h<u}+){var h=t[eng=polygma"===u[h].tion
animac=u[h].,n||riyp
r.fromPtoucs(ce[,l),a.m(2*n,rgs),a.max(oBo.le.wxa&&r.0._dht(tn[0]dn[1]=o[s]=o[1]=0),eshHoir.stenle:i(n[s],n[oi,o[s]-n[s],o[1]-ns1]iveer:tain:t,e){var n n],a=eevelLiropect(),a=t.styl,ennize(:fometries e[n!e,er:tain(t[s],t[1]u
return!1
t:t0;n<t.lnt0utLn(+){var i<r i]+)eng=polygma"===n[i]ition
animaa=n[i]i,n||riyp,l=n[i]iin||riyps e[no,er:tainsa,e[s],t[1]u
3=0;n<t.laf0;l<(s?s)t){var:0);l]+)engo,er:tains[[l]eaer:tinuu ..style.!0}}&&(!!t!1},
if((e.__To:t,e,n){var i=n,r.a12)
fuvelLiropect(),a=t.styl,._o.+"px"/o.t],i=[
n?r||(t=n/s):n=s*r
=0;n<t.lafnle:i(r i=n,r.ou=os,e)culMod(),t&&t.brlrnh=ght=e:fometries,cf0;c<h(+){var c]+)eng=polygma"===h[c].tion
i=0;r<e;)f=h[c].,n||riyp,d=h[c].in||riyps,p=0;p<f)t){var;p]+)a.apply(),t&&t.brf[p],f[p],ug
=0;n<t.lg=0;g<(d?d)t){var:0);g]+)=0;rp=0;p<d[g])t){var;p]+)a.apply(),t&&t.brd[g][p],d[g][p],u)}(oLvelLisr.stt.nupyrlrnght=eeeucer=[o.x+o.+"px"/2,o}y+o.t],i=[/2]n,"loneShe)}ow:t,e){var n ncale_dtpartdtelLi(imen
],a=eenle:s(eight=e:fometriesnght=eeeucern.length=0,ir.stevelLisr.st,eetif((e.__Tos._hore}}is.scl,ss=r},functilovt,e,n){var i=n(312)
funcn73)
s(){returrar i nth.sqrt(t-e)abs(t-e)<1e-8}e,er:tain_){return n,i=n(31t.la]gofut[s] e[n!o
return!1
=0;n<t.lsd1;s<t}+){var s=t[{nch:lot[s]
a+=i(o[s],o[1],l[s],l[1],i=n(oo=denimauut[s] th.sqrtr(o[s],u[s],&&r(o[1],u[1]u||(a+=i(o[s],o[1],u[s],u[1],i=n(),0!==aHovt,e,n){var i=n(312)
funcn34).deni217traevi208).mmkmInnerro=n(226)
._o.mmkmLabliFo__atcersloo.gftOpretuCormgoryIucerval,u=osshouldShowAllLablis,hfsat
s(){returc n,i,r,a=thir,aefn!t"lablihc)tful i, th.sqrtdaa,o)his..o=F,e,n){v(o)?n=v*t,or:(t=e[n])r._do?t,e){var n n],a=eelR=ai[n])Iucerval.length=]&&"aue?e:lR=ai[n])Iucerval=ts,e)culModCormgoryIucerval(n}is):o,enfn!tr(),paa,o,{lablih:n,labliCormgoryIucerval:r}).hs(){returf n_sin&&(!!t h(t)[e]._(h(t)[e]f[])hs(){returdar i,r=0;n<t.len0;n<t}+){var n]+)engvel
.keyn
=e
return eel
.valu!hs(){returpar i=n(2&ength=te.delR{key:e,valu!:n})snhs(){returgar i=n(312)
fus(p),rmRi),i.c,aen.314En||{,(r,fut[:fuLabliModel(),af[]oh=(t-e)max((e||0)+1,1)
c=a[s],ferfer(t.at
0!=uct(h>1&&f/h>2parc=(t-e)raunt(Math.Peil(c/h)*hre)nch:duuar!,poo.gft("haowMinLabli")sfd,goo.gft("haowMaxLabli")sfd
p&&c!==a[0]drm(a[0])
=0;n<t.lvgc;v<=a[1];v+=h)m(vt
s(){returm n nl..delRn?t:{fo__atced"tbli:i(p),raw"tbli:r[:fuLabli(p),tickValu!:t}e.wxa&&r.g&&v-h!==a[1]drm(a[1]usl}s(){returvn!_s=n(312)
rmRi),i.c,aes(p),om[].length=es._pror.getTicks(n,(t){var e=this._ontr[:fuLabli(p)
e&t i &&o..delRn?t:{fo__atced"tbli:a(p),raw"tbli:i,tickValu!:t}e.ic,oraneisModAxthctblis=t,e){var tthreturn"eormgorys._dsfstru?e){t.on&&t,r],a=eevi314LabliModel(),n=c n,i,.style.!e.gft("haow"e._t.s,i.cnisBlank(t?{lablih:[]oaabliCormgoryIucerval:n(+abliCormgoryIucerval}:olni):t,e){var nhis._opts.h,i.c.314Ticks(n,nes(p)
&&(!!t{lablih:is+op(en(t,e,n){vai=i(hreturn{fo__atced"tbli:vai=i(,raw"tbli:s.h,i.c.314Labli(e),tickValu!:e}r:fun(=avee.eisModAxthTicksit,e){var n,i,r&&(!!t"eormgorys._dsfstru?e){t.on&&t,i,r,a=thir,aefn!t"tickhc)tful i,,s=dna,o)
engs
return s e[ne.gft("haow"e&&!t.s,i.cnisBlank(tsfoom[]ati.o=F,e,n){v(o))n=v*t,o,=n&&unctieng=[n])r._do[{nch:u=c n,vi314LabliModel())
&=u(+abliCormgoryIucerval,n=i}+op(u(+abliss(t,e){var n nth.sqrttitickValu!r:fuunctienfn!tr=o,=n&&th.sqrtpaa,o,{tickh:n,tickCormgoryIucerval:r}) n!ae):{tickh:s.h,i.c.314Ticks(n}vee.,e)culModCormgoryIucervaltt,e){var nhis._opte){t.on&&t,r],a=eevi314LabliModel()
&&(!!t{axthRotMod,a[:fuRotMod?a[:fuRotMod(),a[.sHorizo=1):&&!t..sHorizo=1):fr?90:0oaabliRotMod,e.gft("rotMod")r
0,font,e.gftFont(fun(=a,nes(p),i=ne.axthRotMod-e.aabliRotMod)/180*Math.PI,aevt),i.c,o]af314En||{,(r,afsfru(t.(i e[no[1]-o[s]<1
return 0rs.scu=1
l>40bkiu=(t-e)max(1,(t-e)fluor(l/40))&&=0;n<t.lc=o[s]sftti,r.sToCuord(c+1)-ti,r.sToCuord(cr,d=(t-e)abs(f*Math.cos(ic)sp=(t-e)abs(f*Math.s(2*ereBg]govf0;c<=o[1] c]=u,r],a=m,_,yerft("ect(),a=t.styn(cr,0.fot.,"eeucer","topstrm=1.3*y.+"px",_=1.3*y.t],i=[yg=(t-e)max(g,m,7),v=(t-e)max(v,_,7&}<t.lx=g/d,w=v/p=esNaN(xndInx=1/0,oesNaN(wndInw=1/0,rs.scb=(t-e)max(0,(t-e)fluor((t-e)m(2*x,w))&,SelR=3model),Tevi314En||{,(r,M=S.las[An])Iucerval,C=S.las[Tick&&(t..length=]&&"auMt.oop&&tC&&(t-e)abs(M-b)<=1&&(t-e)abs(C-l)<=1&&(>b&&S.axthEn||{d0._dT[0]drS.axthEn||{d1._dT[1]?b=(:(S.las[Tick&&(t.=l,S.las[An])Iucerval=b,S.axthEn||{d0.T[0],S.axthEn||{d1.T[1]usb}}]u]ur
//# sourceMapp,a=URL=chunk.0.1adadf1cd386743